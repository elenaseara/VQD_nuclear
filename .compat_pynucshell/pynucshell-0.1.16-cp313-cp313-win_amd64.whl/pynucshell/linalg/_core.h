#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <complex.h>
#include <math.h>

// Removed OPENMP support for the moment.
// #ifdef _OPENMP
//     #include <omp.h>
// #else
//     // Stub out OpenMP functions for serial execution
//     #define omp_get_thread_num() 0
//     #define omp_get_num_threads() 1
//     #define omp_set_num_threads(n)
// #endif

#ifdef _MSC_VER
#include <intrin.h>

// MSVC equivalent for __builtin_popcountll (64-bit)
static inline int __builtin_popcountll(unsigned __int64 x) {
    return (int)__popcnt64(x);
}

// MSVC equivalent for __builtin_ctzll (Count Trailing Zeros, 64-bit)
static inline int __builtin_ctzll(unsigned __int64 x) {
    unsigned long index;
    if (_BitScanForward64(&index, x)) {
        return (int)index;
    }
    return 64; // GCC behavior for ctz(0) is undefined, but 64 is common for 64-bit
}
#endif

#define SWAP(a, b) if (a > b) { int temp = a; a = b; b = temp; }

typedef struct {
    double real;
    double imag;
} complex128_t;

// This defines an internal _Pair structure
// Will live with Cython
typedef struct {
    int n_states;
    uint64_t *states;
    int * sl_ind;
    int * two_body;
    int sector_value;
} Sector;

typedef struct{
    Sector * sectors;
    int is_ascending;
    int n_specie;
    int * m_values;
    int n_sectors;
    int n_states;
    int number_m_values;
} Slaters;

typedef struct{
    Slaters p_slaters;
    Slaters n_slaters;
    int mb_basis;
    FILE * fptr;  // File pointer to be closed later
} _Basis;

void free_basis(_Basis basis);

typedef struct{
    // int in;
    // int out;
    int in_two;
    int out_two;
} Pair;

typedef struct{
    Pair * pairs;
    int * parities;
    int n_pairs;
    int initial_m;
} SectorJump;

typedef struct {
    SectorJump * jumps;
    int delta_m;
    int n_sectors;
} OperatorSlater;

typedef struct 
{
    OperatorSlater *op_n;
    OperatorSlater *op_p;
    int order_parity;
    double coefficient;
} _C_operator;

typedef struct
{
    _C_operator * ops;
    int n_terms; 
} OperatorSum;

void compute_full_op2(int i, int j, _Basis basis, OperatorSlater * op_p, OperatorSlater * op_n, int * ord_parity);

void compute_full_op(int i, int j, int k, int l, _Basis basis, OperatorSlater * op_p, OperatorSlater * op_n, int *ord_parity);

void free_opsum(OperatorSum op_sum);

void free_op_sl(OperatorSlater *op_sl);

void multiply_state2(OperatorSum *opsum, int size_state, double * state_in, double * state_out);

void complex_multiply_state2(OperatorSum *opsum, int size_state, complex128_t * state_in, complex128_t * state_out);

void multiply_state3(OperatorSum *opsum, int size_state, double * state_in, double * state_out);

void complex_multiply_state3(OperatorSum *opsum, int size_state, complex128_t * state_in, complex128_t * state_out);

//void multiply_state4(OperatorSum *opsum, int size_state, double * state_in, double * state_out, int out_p_max);

void expand_CSR(OperatorSum * opsum,int dim, int *n_values, uint32_t ** rows, uint32_t ** columns, double ** values);

void multiply_state_qubit(OperatorSum *opsum, int size_state, double * state_in, double * state_out);

void complex_multiply_state_qubit(OperatorSum *opsum, int size_state, complex128_t * state_in, complex128_t * state_out);

void expand_CSR_qubit(OperatorSum * opsum,int dim, int *n_values, uint32_t ** rows, uint32_t ** columns, double ** values);

void inner_prod(OperatorSum *opsum, int size_state, double * state_in_left, double * state_in_right, double * inner_prod);

void op_exp_state(OperatorSum *opsum, int size_state, double * state_in, double * state_out, double theta);

void trace_op(OperatorSum *opsum, int size_state, double * trace_A);

OperatorSlater compute_op(int i, int j, Slaters* slaters_iso);

OperatorSlater compute_op_ident(Slaters* slaters_iso);

OperatorSlater compute_op_n(int i, Slaters* slaters_iso);

OperatorSlater compute_op4(int i, int j,int k,int l, Slaters* slaters_iso);

int _binary_search_c_lexicographical(uint64_t n, uint64_t *arr, uint64_t target);

int _compare_bitmasks_same_size(uint64_t ma, uint64_t mb);
