from libc.stdlib cimport malloc, free
from libc.stdio  cimport FILE
from libc.stdint cimport uint64_t, uint32_t

import  scipy.sparse as sp
cimport numpy as cnp
from itertools import combinations
import numpy as np
from cython.parallel import prange
from cython cimport boundscheck, wraparound
import io
from itertools import product

cnp.import_array()

ctypedef fused vec_or_mat:
    double[::1]
    double[:, ::1]

cdef extern from "_core.h":

    ctypedef struct complex128_t:
        double real
        double imag

    # This is the same as in C
    # We use the struct to save data
    ctypedef struct Sector:
        int       n_states
        uint64_t *states
        int      *sl_ind
        int      *two_body
        int       sector_value

    ctypedef struct Slaters:
        Sector *sectors
        int     is_ascending
        int     n_specie
        int    *m_values
        int     n_sectors
        int     n_states
        int     number_m_values

    ctypedef struct _Basis:
        Slaters  p_slaters
        Slaters  n_slaters
        int      mb_basis
        FILE    *fptr

    ctypedef struct Pair:
        # int in_ "in"
        # int out
        int in_two
        int out_two

    ctypedef struct SectorJump:
        Pair * pairs
        int * parities
        int n_pairs
        int initial_m

    ctypedef struct OperatorSlater:
        SectorJump *jumps
        int         delta_m
        int         n_sectors   

    ctypedef struct _C_operator:
        OperatorSlater*op_n
        OperatorSlater*op_p
        int            order_parity
        double         coefficient

    ctypedef struct OperatorSum:
        _C_operator *ops
        int       n_terms

    void free_basis(_Basis basis)

    void compute_full_op2(int i, int j, _Basis basis, OperatorSlater * op_p, OperatorSlater * op_n, int * ord_parity) nogil

    void compute_full_op(int i, int j, int k, int l, _Basis basis, OperatorSlater * op_p, OperatorSlater * op_n, int *ord_parity) nogil

    void free_opsum(OperatorSum op_sum)

    void free_op_sl(OperatorSlater *op_sl)

    void multiply_state2(OperatorSum *opsum, int size_state, double * state_in, double * state_out) 

    void complex_multiply_state2(OperatorSum *opsum, int size_state, complex128_t * state_in, complex128_t * state_out)

    void multiply_state3(OperatorSum *opsum, int size_state, double * state_in, double * state_out) 

    void complex_multiply_state3(OperatorSum *opsum, int size_state, complex128_t * state_in, complex128_t * state_out)

    #void multiply_state4(OperatorSum *opsum, int size_state, double * state_in, double * state_out, int out_p_max) 

    void expand_CSR(OperatorSum * opsum,int dim, int *n_values, uint32_t ** rows, uint32_t ** columns, double ** values)

    void multiply_state_qubit(OperatorSum *opsum, int size_state, double * state_in, double * state_out)

    void complex_multiply_state_qubit(OperatorSum *opsum, int size_state, complex128_t * state_in, complex128_t * state_out)

    void expand_CSR_qubit(OperatorSum * opsum,int dim, int *n_values, uint32_t ** rows, uint32_t ** columns, double ** values)

    void inner_prod(OperatorSum *opsum, int size_state, double * state_in_left, double * state_in_right, double * inner_prod)

    void op_exp_state(OperatorSum *opsum, int size_state, double * state_in, double * state_out, double theta)

    void trace_op(OperatorSum *opsum, int size_state, double * trace_A)

    OperatorSlater compute_op(int i, int j, Slaters* slaters_iso)

    OperatorSlater compute_op_ident(Slaters* slaters_iso)

    OperatorSlater compute_op_n(int i, Slaters* slaters_iso)

    OperatorSlater compute_op4(int i, int j,int k,int l, Slaters* slaters_iso)

    int _binary_search_c_lexicographical(uint64_t n, uint64_t *arr, uint64_t target)

    int _compare_bitmasks_same_size(uint64_t ma, uint64_t mb)


cdef extern from "_uncouple.h":

    void decouple_to_arrays(int ** array_M, int space_size, int total_space,
             const char *input2,
             double ** coeffs, int ** indices, int * n_one_bodies, int * mapping)

    void decouple_to_arrays_from_arrays(int ** array_M, int space_size, int total_space,
                int * ind_coupled, double * values_coupled, int n_terms, 
                double ** coeffs, int ** indices, int * n_one_bodies, int * mapping)

    void decouple_to_arrays_np(int ** array_M, int space_size, int total_space,
             const char *input2,
             double ** coeffs, int ** indices, int * n_one_bodies, int * mapping)

    void decouple_to_arrays_from_arrays_np(int ** array_M, int space_size, int total_space,
                int * ind_coupled, double * values_coupled, int n_terms, 
                double ** coeffs, int ** indices, int * n_one_bodies, int * mapping)

# To make it accessible form python
# we define this class, which is basically
# the same. It also has the function from c

cdef extern from *:
    int __builtin_ctzll(unsigned long long x) nogil

from pynucshell.formatting import SUB
SUB_2 = '2'.translate(SUB)

def J_to_fraction(J):
    """Convert a half-integer J to a fraction."""
    if int(J) == J:
        return J
    return f"{str(int(2 * J)).translate(SUB)}/{SUB_2}"


class Space:
    """
    Single-particle valence space definition.

    Parameters
    ----------
    n_ar : list[int]
        Principal quantum numbers for each sub-shell.
    L_ar : list[int]
        Orbital angular momentum for each sub-shell.
    J_ar : list[float]
        Total angular momentum j for each sub-shell (half-integer values).

    Example
    -------
    sd-shell (:math:`1d_{\\frac{5}{2}}, 2s_{\\frac{1}{2}}, 1d_{\\frac{3}{2}}`)::

        sd = Space([0  , 1  , 0  ],  # n
                   [2  , 0  , 2  ],  # l
                   [2.5, 0.5, 1.5])  # j

    Attributes
    ----------
    half_space : int
        Number of single-particle states per isospin species.
    array_M : list[int]
        2*m values for all states (protons then neutrons).
    isospin : list[int]
        +1 for proton states, -1 for neutron states.
    array_J, array_N, array_L : list[int]
        Quantum numbers for every single-particle state.
        Note array_J holds 2*J
    """

    def __init__(self, n_ar: list, L_ar: list, J_ar: list):
        self.n_ar = list(n_ar)
        self.L_ar = list(L_ar)
        self.J_ar = list(J_ar)

        array_M  = []
        isospin  = []
        array_J  = []
        array_N  = []
        array_L  = []
        mapping = []

        # ── proton half ──────────────────────────────────────────────────────
        space_counter = 0
        for i in range(len(J_ar)):
            for m in range(+int(J_ar[i] * 2), -int(J_ar[i] * 2) - 1, -2):
                array_M.append(m)
                isospin.append(1)
                array_J.append(int(J_ar[i] * 2))
                array_N.append(int(n_ar[i]))
                array_L.append(int(L_ar[i]))
                mapping.append(space_counter)
                space_counter += 1
        self.half_space = space_counter

        # ── neutron half (identical quantum numbers, different isospin) ──────
        for i in range(len(J_ar)):
            for m in range(+int(J_ar[i] * 2), -int(J_ar[i] * 2) - 1, -2):
                array_M.append(m)
                isospin.append(-1)
                array_J.append(int(J_ar[i] * 2))
                array_N.append(int(n_ar[i]))
                array_L.append(int(L_ar[i]))
                mapping.append(space_counter)
                space_counter += 1

        self.array_M  = array_M
        self.isospin   = isospin
        self.array_J   = array_J
        self.array_N   = array_N
        self.array_L   = array_L
        self.mapping = mapping

    def __repr__(self):
        return (f"Space(n_ar={self.n_ar}, L_ar={self.L_ar}, "
                f"J_ar={self.J_ar}, half_space={self.half_space})")

    def set_mapping(self,mapping: list):
        """
        Sets a new mapping for the orbitals in the space. The input are the 
        new labels, and the index of the array is the old label.

        Example
        -------
            Space.set_mapping([5,4,3,2,1,0])

        will set the labels "5" to the old orbital 0, "4" to the old orbital 2,
        and so on.

        .. note::

            Proton and neutron indices are not allowed to mix or swap.

        Parameters
        ----------
        mapping : list
            A list of indices representing the mapping.

        Raises
        ------
        RuntimeError
            If there is a repeated index or if the mapping is not one to one.
        """
        if len(set(mapping)) != len(mapping):
            raise RuntimeError("There is a repeated index")
        if set(mapping) != set(list(range(len(self.array_M)))):
            raise RuntimeError("The mapping is not one to one")

        self.mapping = mapping

    def print_space(self, order=None):
        """
        Print a representation of the space, showing all shells and single particle states
        of the valence space, protons on the left, and the corresponding
        indices for each.

        .. tip::
            
            Use it in conjunction with :py:func:`set_mapping` to assign your
            desired indexing to single particle states.

        Parameters
        ----------
        order : list, optional
            A list of indices representing the order in which to print the space.
        """
        mapping = self.mapping
        ar = self.J_ar
        ar_L = self.L_ar
        ar_N = self.n_ar
        maximum_length = max(ar)
        temporal_indices = [int(2*i + 1) for i in ar]
        
        starting_index = [0]
        for i in range(len(temporal_indices) - 1):
            starting_index.append(starting_index[i] + temporal_indices[i])

        # This list will store the string chunks for each row (couple)
        couples = []
        strings_for_l = ['s','p','d','f','g','h','i']
        # We iterate through the data to build the strings first
        # Using zip(reversed...) to match your original logic
        for J, L, n, st_ind in zip(reversed(ar), reversed(ar_L), reversed(ar_N), reversed(starting_index)):
            buffer = io.StringIO()
            white = int(maximum_length * 2 + 1) - int(2 * J + 1)
            
            # --- LINE 1: The Indices Row ---
            label_str = f"  {n}{strings_for_l[L]}{J_to_fraction(J)}"
            buffer.write(f"{label_str:<10}")
            #buffer.write(f" J: {i}   ")
            
            # First half of the couple
            for _ in range(white // 2): buffer.write("      ")
            indices_1 = range(st_ind, int(2 * J + 1) + st_ind + 1)
            for j in reversed(range(int(2 * J + 1))):
                val = mapping.index(indices_1[j])
                end_str = ' ' if len(str(val)) == 1 else ''
                buffer.write(f" {end_str}{val}   ")
            for _ in range(white // 2): buffer.write("      ")
            
            buffer.write("    ")
            
            # Second half of the couple
            indices_2 = range(st_ind + self.half_space, int(2 * J + 1) + st_ind + 1 + self.half_space)
            for _ in range(white // 2): buffer.write("      ")
            for j in reversed(range(int(2 * J + 1))):
                val = mapping.index(indices_2[j])
                end_str = ' ' if len(str(val)) == 1 else ''
                buffer.write(f" {end_str}{val}   ")
            for _ in range(white // 2): buffer.write("      ")
            buffer.write("\n")
            
            # --- LINE 2: The Separator Row (-----) ---
            buffer.write("        " + "  ")
            for _ in range(white // 2): buffer.write("      ")
            for _ in range(int(2 * J + 1)): buffer.write("----- ")
            for _ in range(white // 2): buffer.write("      ")
            
            buffer.write("    ")
            
            for _ in range(white // 2): buffer.write("      ")
            for _ in range(int(2 * J + 1)): buffer.write("----- ")
            for _ in range(white // 2): buffer.write("      ")
            buffer.write("\n\n")
            
            couples.append(buffer.getvalue())
            buffer.close()

        # --- REORDERING STEP ---
        # Since we used reversed(ar) in the loop, couples[0] is the last element of ar.
        # If order is provided, we rearrange the blocks.
        if order is not None:
            # Example: order = [2, 0, 1] picks the 3rd couple, then 1st, then 2nd.
            try:
                couples = [couples[len(order)-idx-1] for idx in order]
                couples = [i for i in reversed(couples)]
            except IndexError:
                print("Error: Order index out of range.")
        #print(max(ar))
        final_append_str = list(range(int(-1*max(ar)/0.5),int(max(ar)/0.5)+1,2))
        final_append_str = [str(i) for i in final_append_str]
        # Join everything into the final output
        buffer2 = io.StringIO()
        # --- LINE 1: The Indices Row ---
        buffer2.write(f"          ")
            
        # First half of the couple
        #for _ in range(white // 2): buffer2.write("      ")
        indices_1 = range(st_ind, int(2 * J + 1) + st_ind + 1)
        for j in range(len(final_append_str)): #int(2 * i + 1)):
            val = final_append_str[j]
            end_str = ' ' if len(str(val)) == 1 else ''
            buffer2.write(f" {end_str}{val}   ")
        #for _ in range(white // 2): buffer2.write("      ")
        indices_1 = range(st_ind, int(2 * J + 1) + st_ind + 1)
        buffer2.write(f"    ")
        for j in range(len(final_append_str)): #
            val = final_append_str[j]
            end_str = ' ' if len(str(val)) == 1 else ''
            buffer2.write(f" {end_str}{val}   ")
        for _ in range(white // 2): buffer2.write("      ")
        final_output = "\n" + "".join(couples) + buffer2.getvalue() + "\n"
        print( final_output )   

cdef void _build_c_slaters(Slaters *sl, int *m_values, int total_sp,
                            int n_specie, int ascending,
                            list sector_values, int half_space,
                            list half_m) except *:
    """
    Allocate and populate a C ``Slaters`` struct.

    This replicates the data that ``read_slaters()`` in evalf.c would create
    from the file generated by the notebook's ``Basis.create_file()``.

    Parameters
    ----------
    sl            : pointer to the Slaters struct to fill
    m_values      : full 2*m array for *all* single-particle levels (p + n)
    total_sp      : len(m_values)  (= 2 × half_space)
    n_specie      : number of particles of this species
    ascending     : +1 for protons, −1 for neutrons
    sector_values : list of 2*Mz values for the compatible sectors
    half_space    : number of single-particle states per isospin species
    half_m        : m_values[:half_space]  (one isospin copy)
    """
    cdef int n_sectors = len(sector_values)
    cdef int i, j, ns
    cdef uint64_t bitstring

    # Bit-position offset: protons occupy bits [0, half_space),
    #                      neutrons occupy bits [half_space, 2*half_space).
    cdef int bit_offset = 0 if ascending == 1 else half_space

    sl.n_sectors        = n_sectors
    sl.is_ascending     = ascending
    sl.n_specie         = n_specie
    sl.number_m_values  = total_sp

    # Copy m_values (each Slaters owns its own copy, freed by free_basis)
    sl.m_values = <int *>malloc(sizeof(int) * total_sp)
    if sl.m_values == NULL:
        raise MemoryError("Failed to allocate m_values")
    for i in range(total_sp):
        sl.m_values[i] = m_values[i]

    # Allocate sector array
    sl.sectors = <Sector *>malloc(sizeof(Sector) * n_sectors)
    if sl.sectors == NULL:
        raise MemoryError("Failed to allocate sectors")

    # ── enumerate Slater determinants per sector ─────────────────────────────
    #    (same order as itertools.combinations, matching create_file)
    cdef list sector_states = [[] for _ in range(n_sectors)]
    cdef int total_states = 0
    cdef int mz, idx

    # Build a dict for O(1) sector-value → index lookup
    cdef dict sv_index = {}
    for i in range(n_sectors):
        sv_index[sector_values[i]] = i

    for combo in combinations(range(half_space), n_specie):
        mz = 0
        for c in combo:
            mz += <int>half_m[c]
        idx_val = sv_index.get(mz, -1)
        if idx_val >= 0:
            sector_states[idx_val].append(combo)
            total_states += 1

    sl.n_states = total_states

    # ── fill each Sector struct ──────────────────────────────────────────────
    for i in range(n_sectors):
        states_list = sector_states[i]
        ns = len(states_list)
        sl.sectors[i].sector_value = <int>sector_values[i]
        sl.sectors[i].n_states     = ns

        # Allocate per-sector arrays (use max(ns,1) to avoid malloc(0) issues)
        sl.sectors[i].states   = <uint64_t *>malloc(sizeof(uint64_t) * (ns if ns > 0 else 1))
        sl.sectors[i].sl_ind   = <int *>malloc(sizeof(int) * (ns if ns > 0 else 1))
        sl.sectors[i].two_body = <int *>malloc(sizeof(int) * (ns if ns > 0 else 1))

        for j in range(ns):
            # Convert tuple of orbital indices → occupation bitstring
            bitstring = 0
            for k_val in states_list[j]:
                bitstring |= (1ULL << (<int>k_val + bit_offset))
            sl.sectors[i].states[j] = bitstring


cdef _Basis _build_c_basis(object space, int N_protons, int N_neutrons,
                           int total_J) except *:
    """
    Build a C ``Basis`` struct directly from a ``Space`` object.
    """
    cdef _Basis basis
    cdef int half_space = <int>space.half_space
    cdef int total_sp   = 2 * half_space
    cdef int i, j

    # ── m-values ─────────────────────────────────────────────────────────────
    cdef list array_M = list(space.array_M)
    cdef list half_m  = array_M[:half_space]       # one-isospin copy

    # ── sector ranges ────────────────────────────────────────────────────────
    cdef list sorted_m = sorted(half_m)
    cdef int min_p = 0
    cdef int min_n = 0
    for i in range(N_protons):
        min_p += <int>sorted_m[i]
    for i in range(N_neutrons):
        min_n += <int>sorted_m[i]

    cdef list sectors_p = list(range(min_p, -min_p + 1, 2))
    cdef list sectors_n = list(range(min_n, -min_n + 1, 2))

    # a = proton sector values (ascending)
    # b = −(neutron sector values) (descending)
    cdef list a = sectors_p
    cdef list b = [-sectors_n[i] for i in range(len(sectors_n))]

    # ── find compatible sector window ────────────────────────────────────────
    cdef int initial_p = 0
    cdef int initial_n = 0
    cdef bint found = False

    while not found:
        if initial_n >= len(b):
            raise ValueError(
                f"Cannot find compatible sectors for total_J={total_J}")
        for i in range(len(a)):
            if <int>a[i] + <int>b[initial_n] == total_J:
                initial_p = i
                found = True
                break
        if not found:
            initial_n += 1

    cdef int max_p  = len(a) - initial_p
    cdef int max_n  = len(b) - initial_n
    cdef int compat = min(max_p, max_n)

    cdef list p_sec_vals = a[initial_p : initial_p + compat]
    cdef list n_sec_vals = b[initial_n : initial_n + compat]

    # ── allocate full m_values C array (temporary) ───────────────────────────
    cdef int * mapping = <int *>malloc(sizeof(int) * total_sp)
    for i in range(total_sp):
        mapping[i] = space.mapping[i]

    cdef int *c_m = <int *>malloc(sizeof(int) * total_sp)
    if c_m == NULL:
        raise MemoryError("Failed to allocate c_m")
    for i in range(total_sp):
        c_m[i] = <int>array_M[mapping[i]]
    for i in range(half_space):
        half_m[i] = array_M[mapping[i]]

    # ── build proton and neutron Slaters ─────────────────────────────────────
    _build_c_slaters(&basis.p_slaters, c_m, total_sp,
                     N_protons, 1, p_sec_vals, half_space, half_m)

    for i in range(half_space,half_space*2):
        half_m[i-half_space] = array_M[mapping[i]]
    _build_c_slaters(&basis.n_slaters, c_m, total_sp,
                     N_neutrons, -1, n_sec_vals, half_space, half_m)
    free(c_m)          # each Slaters already has its own copy
    free(mapping)

    # ── assign sl_ind (sequential, 1-indexed, per species) ───────────────────
    cdef int counter = 1
    for i in range(basis.p_slaters.n_sectors):
        for j in range(basis.p_slaters.sectors[i].n_states):
            basis.p_slaters.sectors[i].sl_ind[j] = counter
            counter += 1

    counter = 1
    for i in range(basis.n_slaters.n_sectors):
        for j in range(basis.n_slaters.sectors[i].n_states):
            basis.n_slaters.sectors[i].sl_ind[j] = counter
            counter += 1

    # ── assign two_body offsets ──────────────────────────────────────────────
    #    Neutron: [1, 2, …, n_n]  within each sector  (1-indexed)
    #    Proton:  [offset, offset+n_n, offset+2·n_n, …]  (0-based start)
    #    Combined 1-indexed index: p_two_body + n_two_body
    cdef int offset = 0
    cdef int n_n
    for i in range(compat):
        n_n = basis.n_slaters.sectors[i].n_states
        for j in range(n_n):
            basis.n_slaters.sectors[i].two_body[j] = j + 1
        for j in range(basis.p_slaters.sectors[i].n_states):
            basis.p_slaters.sectors[i].two_body[j] = offset + n_n * j
        offset += n_n * basis.p_slaters.sectors[i].n_states

    basis.mb_basis = offset
    basis.fptr     = NULL

    return basis

cdef class Basis:
    """
    Creates a many-body basis with the given particle number and angular momentum.

    Parameters
    -------------
    space : Space
        Space to construct the many-body system
    N_protons:  int
        Number of protons
    N_neutrons: int
        Number of neutrons
    total_J : int
        Twice the total angular momentum projection of the system.
    """
    cdef _Basis _c_basis
    cdef readonly object _space          # keep Space for create_file()
    cdef readonly int _N_protons
    cdef readonly int _N_neutrons
    cdef readonly int _total_J
    cdef readonly object _mb

    def __cinit__(self, first_arg, N_protons=None, N_neutrons=None,
                  total_J=None):
        cdef bytes _b

        self._mb = None

        if isinstance(first_arg, Space):
            # ── direct construction from Space ───────────────────────────────
            if N_protons is None or N_neutrons is None or total_J is None:
                raise ValueError(
                    "Space-based construction requires "
                    "N_protons, N_neutrons, and total_J")
            self._c_basis = _build_c_basis(
                first_arg, <int>N_protons, <int>N_neutrons, <int>total_J)
            self._space      = first_arg
            self._N_protons  = <int>N_protons
            self._N_neutrons = <int>N_neutrons
            self._total_J    = <int>total_J
        else:
            raise TypeError(
                f"Expected str/bytes or Space, got {type(first_arg)}")

    def __dealloc__(self):
        free_basis(self._c_basis)

    # ── properties ───────────────────────────────────────────────────────────

    @property
    def mb_basis(self):
        """Total many-body basis dimension."""
        return self._c_basis.mb_basis

    def mb(self) -> np.ndarray:
        """
        Return a numpy array with the basis with shape (N_states, N_particles)
        """
        if self._mb is not None:
            return self._mb
            
        cdef cnp.ndarray[int, ndim = 2] basis = np.zeros((self._c_basis.mb_basis, self._N_protons+self._N_neutrons), dtype=np.int32)
        ### RELLENAR ESTA FUNCTION CON LOS ELEMENTOS DE LA BASE EN ENTEROS
        cdef int counter = 0
        cdef int n_sectors = self._c_basis.p_slaters.n_sectors
        cdef uint64_t temp_n
        # cdef int count = self._N_protons+self._N_neutrons
        
        for sect in range(n_sectors):
            for p_sl in range(self._c_basis.p_slaters.sectors[sect].n_states):
                p_slater = self._c_basis.p_slaters.sectors[sect].states[p_sl]
                for n_sl in range(self._c_basis.n_slaters.sectors[sect].n_states):
                    n_slater = self._c_basis.n_slaters.sectors[sect].states[n_sl]
                    temp_n = p_slater ^ n_slater
                    i = 0
                    while temp_n > 0:
                        # Find the index of the least significant set bit
                        pos = __builtin_ctzll(temp_n)

                        basis[counter, i] = pos
                        # Clear the least significant set bit: n & (n - 1)
                        temp_n &= (temp_n - 1)
                        i += 1

                    counter += 1
        return basis

    def set_state(self, slater_det) -> np.ndarray:
        """Returns statevector array representing a slater determinant initial state, 
        with corresponding single particle states occupied.

        Parameters
        ----------
        slater_det : tuple
            tuple containing the indices of the occupied states

        Returns
        -------
        initial_state : np.ndarray
            Array representing the statevector initial state, indicating the coefficients
            of each slater determinant. Here all 0 except for the chosen initial
            slater state.
        """
        # Using knowledge of mb to infer index without creating mb
        # cdef int total_M = 0
        # cdef int sector_M = 0
        # cdef int sect_num = 0
        # cdef int num_states_p = 0
        # cdef int num_states_n = 0
        # cdef uint64_t p_state_uint_rep = 0
        # cdef uint64_t n_state_uint_rep = 0
        # cdef int proton_index = 0
        # cdef int neutron_index = 0
        # cdef int occupied_index = 0

        # # Check if slater determinant is valid for Basis
        # if len(slater_det) != self._N_protons + self._N_neutrons:
        #     raise ValueError(f"Initial state does not match the number of particles: Expected {len(slater_det)}, got {self._N_protons + self._N_neutrons}")
        
        # slater_det = sorted(slater_det)
        # if self._N_neutrons and slater_det[self._N_protons] < self._space.half_space:
        #     raise ValueError(f"Initial state has more protons than basis, which has {self._N_protons}")
        # if self._N_protons and slater_det[self._N_protons-1] >= self._space.half_space:
        #     raise ValueError(f"Initial state has more neutrons than basis, which has {self._N_neutrons}")
        
        # # Find M and thus sector
        # for ind in slater_det[:self._space.half_space]:
        #     total_M += self._space.array_M[ind]
        # sector_M = total_M

        # for ind in slater_det[self._space.half_space:]:
        #     total_M += self._space.array_M[ind]
        # if total_M != self._total_J:
        #     raise ValueError(f"Initial state does not have the correct total M. Expected {self._total_J}, got {total_M}")
        

        # # reminder p sectors are in ascending 2xM order
        # cdef int first_p_sector
        # cdef int last_p_sector
        # first_p_sector = self._c_basis.p_slaters.sectors[0].sector_value
        # last_p_sector = self._c_basis.p_slaters.sectors[self._c_basis.p_slaters.n_sectors-1].sector_value

        # if sector_M < first_p_sector or sector_M > last_p_sector or (last_p_sector-sector_M)%2 != 0:
        #     sector_type = "odd" if first_p_sector%2 == 1 else "even"
        #     raise ValueError(
        #            f"Initial state is not in a valid sector. Expected proton 2xM between \
        #            {first_p_sector} and {last_p_sector} ({sector_type}), got {sector_M}")

        # sect_num = ( last_p_sector - sector_M )//2

        # # We skip other sectors
        # for i in range(sect_num):
        #     occupied_index += self._c_basis.p_slaters.sectors[i].n_states * \
        #                         self._c_basis.n_slaters.sectors[i].n_states

        # # Trick: As states are ordered, we can binary search within sector
        # for state in slater_det[:self._N_protons]:
        #         p_state_uint_rep |= (1ULL << state)
        
        # for state in slater_det[self._N_protons:]:
        #         n_state_uint_rep |= (1ULL << state)

        # num_states_p = self._c_basis.p_slaters.sectors[sect_num].n_states
        # proton_index = _binary_search_c_lexicographical(
        #                                num_states_p,
        #                                self._c_basis.p_slaters.sectors[sect_num].states,
        #                                p_state_uint_rep)

        # num_states_n = self._c_basis.n_slaters.sectors[sect_num].n_states
        # neutron_index = _binary_search_c_lexicographical(
        #                                num_states_n,
        #                                self._c_basis.n_slaters.sectors[sect_num].states,
        #                                n_state_uint_rep)

        # if proton_index < 0 or neutron_index < 0:
        #     raise ValueError("Initial state is not in a valid sector.")

        # occupied_index += proton_index*num_states_p + neutron_index

        # initial_state = np.zeros(self.mb_basis)
        # initial_state[occupied_index] = 1.0

        # Manual way, not exploiting knowledge of mb. But much much shorter :)
        mb = self.mb()
        slater_det_ar = np.array(list(slater_det),dtype=np.int32)
        initial_state = np.zeros(mb.shape[0])
        for i in range(len(mb)):
            if np.allclose(slater_det_ar, mb[i,:]):
                initial_state[i] = 1.0
                break
        return initial_state

    def __repr__(self):
        return (f"Basis(N_protons={self._N_protons}, N_neutrons={self._N_neutrons})")

cdef class Simulator:
    cdef int N_protons, N_neutrons, space_size
    cdef OperatorSlater * ops_sl
    cdef Basis basis
    cdef _Basis _c_basis
    cdef OperatorSum op_sum
    cdef object ops_2_body_p
    cdef object ops_2_body_n
    cdef object ops_1_body_p
    cdef object ops_1_body_n
    cdef int size_ops_sl

    def __init__(self, space : Space, basis : Basis):
        self.basis = basis
        self._c_basis = basis._c_basis
        cdef _Basis _c_basis = basis._c_basis
        if space != None:
            mapping = space.mapping
            half_sp = len(space.mapping)//2
            for m in range(half_sp):
                if mapping[m] >= half_sp:
                    raise RuntimeError("The Simulator class is not supported for reordering between neutrons and protons, proceed with Quantum Circuit simulations or handle mapping by hand")
        
        N_protons = basis._N_protons
        N_neutrons= basis._N_neutrons
        self.N_protons = N_protons
        self.N_neutrons = N_neutrons
        space_size = len(space.array_M)
        self.space_size = space_size

        ops_p = product(range(space_size//2), range(space_size//2), range(space_size//2), range(space_size//2))
        ops_n = product(range(space_size//2, space_size), range(space_size//2, space_size), range(space_size//2, space_size), range(space_size//2, space_size))

        M_array = space.array_M
        T_array = [1] * (space_size//2)  + [-1] * (space_size//2)

        def compute_m(i,j,k,l):
            # res = M_array[i] + M_array[j] - M_array[k] - M_array[l]
            res = M_array[mapping[i]] + M_array[mapping[j]] - M_array[mapping[k]] - M_array[mapping[l]]
            return res

        def compute_t(i,j,k,l):
            #res = T_array[i] + T_array[j] - T_array[k] - T_array[l]
            res = T_array[mapping[i]] + T_array[mapping[j]] - T_array[mapping[k]] - T_array[mapping[l]]
            return res

        ops_2_body_p = {}
        counter = 4
        for op in ops_p:
            i,j,k,l = op[0], op[1], op[2], op[3]
            if i < j and k < l:
                if compute_m(i,j,k,l) == 0 and compute_t(i,j,k,l) == 0:
                    ops_2_body_p[(i,j,k,l)] = counter
                    counter += 1
        ops_p = product(range(space_size//2), range(space_size//2),)

        ops_1_body_p = {}
        for op in ops_p:
            i,j = op[0], op[1]
            ops_1_body_p[(i,j)] = counter
            counter += 1

        ops_2_body_n = {}
        for op in ops_n:
            i,j,k,l = op[0], op[1], op[2], op[3]
            if i < j and k < l:
                if compute_m(i,j,k,l) == 0 and compute_t(i,j,k,l) == 0:
                    ops_2_body_n[(i,j,k,l)] = counter
                    counter += 1

        ops_1_body_n = {}
        ops_n = product(range(space_size//2, space_size), range(space_size//2, space_size))
        for op in ops_n:
            i,j = op[0], op[1]
            ops_1_body_n[(i,j)] = counter
            counter += 1
        #counter+=4
        #print(counter)

        self.ops_sl = <OperatorSlater * > malloc(sizeof(OperatorSlater) * counter)
        self.size_ops_sl = counter
        for op in ops_2_body_p.keys():
            i = ops_2_body_p.get(op)
            self.ops_sl[i] = compute_op4(op[0], op[1], op[2], op[3], &_c_basis.p_slaters)
        self.ops_sl[0] = compute_op_ident(&_c_basis.p_slaters)
        ops_2_body_p[()] = 0

        for op in ops_2_body_n.keys():
            i = ops_2_body_n.get(op)
            self.ops_sl[i] = compute_op4(op[0], op[1], op[2], op[3], &_c_basis.n_slaters)
        self.ops_sl[1] = compute_op_ident(&_c_basis.n_slaters)
        ops_2_body_n[()] = 1

        for op in ops_1_body_p.keys():
            i = ops_1_body_p.get(op)
            if op[0] == op[1]:
                self.ops_sl[i] = compute_op_n(op[0], &_c_basis.p_slaters)
            else:
                self.ops_sl[i] = compute_op(op[0], op[1], &_c_basis.p_slaters)
        self.ops_sl[2] = compute_op_ident(&_c_basis.p_slaters)
        ops_1_body_p[()] = 2

        for op in ops_1_body_n.keys():
            i = ops_1_body_n.get(op)
            if op[0] == op[1]:
                self.ops_sl[i] = compute_op_n(op[0], &_c_basis.n_slaters)
            else:
                self.ops_sl[i] = compute_op(op[0], op[1], &_c_basis.n_slaters)
        self.ops_sl[3] = compute_op_ident(&_c_basis.n_slaters)
        ops_1_body_n[()] = 3

        self.ops_2_body_p = ops_2_body_p
        self.ops_2_body_n = ops_2_body_n
        self.ops_1_body_p = ops_1_body_p
        self.ops_1_body_n = ops_1_body_n

    def to_lin_op(self, object operator, exc_op = False):
        if not exc_op:
            return LinOp(CoreLinOP(operator, self, self.basis))
        else:
            return LinExcOp(CoreLinExcOP(operator, self, self.basis))

    def to_csr(self, object operator):
        return CoreLinOP(operator, self, self.basis).to_csr()

    def __dealloc__(self):
        if self.ops_sl != NULL:
            for i in range(self.size_ops_sl):
                free_op_sl(&self.ops_sl[i])  # Pass address of the struct
            free(self.ops_sl)
            self.ops_sl = NULL

cdef class CoreLinOP:
    
    cdef OperatorSum op_sum
    cdef Simulator sim
    cdef Basis basis
    cdef int space_size
    cdef int is_fermionic

    def __init__(self, object operator, sim : Simulator, basis : Basis):
        self.sim = sim
        self.basis = basis
        self.space_size = sim.space_size
        if operator.is_fermionic == True:
            self.is_fermionic = 1
        else: 
            self.is_fermionic = 0
        ops_dict = operator.ops
        func = operator.func
        N = self.sim.N_neutrons + self.sim.N_protons
        n = len(ops_dict)

        self.op_sum.ops = <_C_operator*>malloc(n * sizeof(_C_operator))
        self.op_sum.n_terms = n
        counter = 0
        for key, (coeff, func_ind) in ops_dict.items():
            if func is not None:
                scaled_coeff = coeff*(func[1]/(func[0]+N))**func[2] if func_ind else coeff
            else:
                scaled_coeff = coeff
            ar = np.array(key)
            #print(ar)
            #print("Space")
            #print(self.space_size)
            op_p = tuple(ar[ar<(self.space_size//2)].tolist())
            op_n = tuple(ar[ar>(self.space_size//2-1)].tolist())
            #print("Operators are")
            #print(op_p)
            #print(op_n)
            if len(op_p) ==  0:
                #print("should be here")
                ind = self.sim.ops_1_body_p.get(op_p)
                #print(ind)
                self.op_sum.ops[counter].op_p = &self.sim.ops_sl[ind]
                self.op_sum.ops[counter].order_parity = 1
            elif len(op_p) == 2:
                ind = self.sim.ops_1_body_p.get(op_p)
                #print(ind)
                self.op_sum.ops[counter].op_p = &self.sim.ops_sl[ind]
                if len(key) == 4:
                    self.op_sum.ops[counter].order_parity = -1
            elif len(op_p) ==  4:
                ind = self.sim.ops_2_body_p.get(op_p)
                self.op_sum.ops[counter].op_p = &self.sim.ops_sl[ind]
                self.op_sum.ops[counter].order_parity = 1

            if len(op_n) ==  0 :
                ind = self.sim.ops_1_body_n.get(op_n)
                self.op_sum.ops[counter].op_n = &self.sim.ops_sl[ind]
                self.op_sum.ops[counter].order_parity = 1
            elif len(op_n) ==  2:
                ind = self.sim.ops_1_body_n.get(op_n)
                self.op_sum.ops[counter].op_n = &self.sim.ops_sl[ind]
                if len(key) == 4:
                    self.op_sum.ops[counter].order_parity = -1
            elif len(op_n) ==  4:
                ind = self.sim.ops_2_body_n.get(op_n)
                self.op_sum.ops[counter].op_n = &self.sim.ops_sl[ind]
                self.op_sum.ops[counter].order_parity = 1
            self.op_sum.ops[counter].coefficient = scaled_coeff
            counter += 1

    def matvec(self, v): # Remove the double[:] type hint here
        """
        Applies the operator to a given states
        Parameters
        ----------
            v :  ndarray
                The state on which the operator is applied
        """
        # Convert input to a 1D contiguous array safely
        # This handles both (N,) and (N, 1) shapes
        cdef double[::1] inp = np.ascontiguousarray(v, dtype=np.float64).ravel()
        
        cdef int n = inp.shape[0]
        cdef double[::1] out = np.zeros(n, dtype=np.float64)

        # Call your C function
        if self.is_fermionic == 1:
            #multiply_state2(&self.op_sum, n, &inp[0], &out[0])
            multiply_state3(&self.op_sum, n, &inp[0], &out[0])
        else:
            multiply_state_qubit(&self.op_sum, n, &inp[0], &out[0])    
        # Return as a 1D array (SciPy's matvec expects 1D output)
        return np.asarray(out)

    def complex_matvec(self, v): # Remove the double[:] type hint here
        """
        Applies the operator to a given states
        Parameters
        ----------
            v :  ndarray
                The state on which the operator is applied
        """
        # Convert input to a 1D contiguous array safely
        # This handles both (N,) and (N, 1) shapes
        cdef complex[::1] inp = np.ascontiguousarray(v, dtype=np.complex128).ravel()
        
        cdef int n = inp.shape[0]
        cdef complex[::1] out = np.zeros(n, dtype=np.complex128)

        # Call your C function
        if self.is_fermionic == 1:
            #complex_multiply_state2(&self.op_sum, n, &inp[0], &out[0])
            complex_multiply_state3(&self.op_sum, n, <complex128_t*> &inp[0], <complex128_t*> &out[0])
            #multiply_state3(&self.op_sum, n, &inp[0], &out[0])
        else:
            complex_multiply_state_qubit(&self.op_sum, n, <complex128_t*> &inp[0], <complex128_t*> &out[0])    
        # Return as a 1D array (SciPy's matvec expects 1D output)
        return np.asarray(out)

    def linear_op(self):
        return sp.linalg.LinearOperator(
            dtype=np.float64,
            shape=(self.basis.mb_basis, self.basis.mb_basis),
            matvec=self.matvec,
            rmatvec=self.matvec,
        )

    def complex_linear_op(self):
        return sp.linalg.LinearOperator(
            dtype=np.float64,
            shape=(self.basis.mb_basis, self.basis.mb_basis),
            matvec=self.complex_matvec,
            rmatvec=self.complex_matvec,
        )

    def trace(self):
        cdef int mb_dim
        mb_dim = self.basis.mb_basis
        cdef double res
        trace_op(&self.op_sum, mb_dim, &res )
        return res

    def inner_product(self, a, b):
        cdef double[::1] in_a = np.ascontiguousarray(a, dtype = np.float64).ravel()
        cdef double[::1] in_b = np.ascontiguousarray(b, dtype = np.float64).ravel()

        cdef int n_a = in_a.shape[0]
        cdef double out = 0

        inner_prod(&self.op_sum, n_a, &in_a[0], &in_b[0], &out)

        return out

    def to_csr(self):
    
        cdef int nvalues
        cdef uint32_t * rows
        cdef uint32_t * cols
        cdef double * data
        cdef int dim = self.basis.mb_basis

        if self.is_fermionic == 1:
            expand_CSR(&self.op_sum, dim, &nvalues, &rows, &cols, &data)
        else:
            expand_CSR_qubit(&self.op_sum, dim, &nvalues, &rows, &cols, &data)
        
        cdef cnp.ndarray rows_cy
        cdef cnp.ndarray cols_cy
        cdef cnp.ndarray data_cy 

        if nvalues > 0:    
            rows_cy = np.asarray(<unsigned int[:nvalues]> rows)
            cols_cy = np.asarray(<unsigned int[:nvalues]> cols)
            data_cy = np.asarray(<double [:nvalues]> data)

            return sp.coo_matrix((data_cy, (rows_cy, cols_cy)), shape=(dim, dim)).tocsr()
        else:
            return None

    def __dealloc__(self):
        free(self.op_sum.ops)

cdef class CoreLinExcOP(CoreLinOP):
    def exp(self, a, theta):
        """
        Applies the inner product <a|OP|b> efficiently
        Parameters
        ----------
            a : ndarray
                The a state
            b : ndarray
                The other state
        """
        cdef double[::1] in_a = np.ascontiguousarray(a, dtype = np.float64).ravel()

        cdef int n = in_a.shape[0]
        cdef double _theta = theta
        cdef double[::1] out = np.zeros(n, dtype=np.float64)

        op_exp_state(&self.op_sum, n, &in_a[0], &out[0], _theta)

        return np.asarray(out)

class LinOp(sp.linalg.LinearOperator):
    def __init__(self, corelin: CoreLinOP, dtype=np.float64):
        shape = (corelin.basis.mb_basis, corelin.basis.mb_basis)
        self.corelin = corelin
        super().__init__(dtype, shape)

    def _matvec(self, v):
        if np.iscomplexobj(v):
            return self.corelin.complex_matvec(v)
        return self.corelin.matvec(v)

    def _rmatvec(self, v):
        if np.iscomplexobj(v):
            return self.corelin.complex_matvec(v)
        return self.corelin.matvec(v)

    def trace(self):
        return self.corelin.trace()

    def inner_product(self, a, b):
        return self.corelin.inner_product(a,b)

class LinExcOp(LinOp):
    def exp(self, state : np.ndarray, theta : float):
        return self.corelin.exp(state, theta)

# cdef class OldSimulator:
#     """
#     This is a simulator for computing many-body calculations without 
#     the construction of circuits. Provides a matrix-free operator acting
#     on the many-body basis

#     Parameters
#     ----------
#     op : Operator
#         Operator which will act on states
#     basis : Basis
#         Basis in which the operator will act on.
#     """
#     cdef OperatorSum op_sum
#     cdef int n_terms
#     cdef _Basis basis
#     cdef Basis pyBasis
#     cdef int is_fermionic # 1 is true, 0 false

#     def __cinit__(self):
#         self.op_sum.ops = NULL
#         self.op_sum.n_terms = 0
        
#     def __init__(self, object operator, Basis basis):
#         #print(operator.space.array_M)
#         if operator.space != None:
#             mapping = operator.space.mapping
#             half_sp = len(operator.space.mapping)//2
#             for m in range(half_sp):
#                 if mapping[m] >= half_sp:
#                     raise RuntimeError("The Simulator class is not supported for reordering between neutrons and protons, proceed with Quantum Circuit simulations or handle mapping by hand")
#         """offsets = [0]
#         original_order = list(range(len(operator.space.array_M)))
#         for m in range(len(operator.space.J_ar)):
#             offsets.append(offsets[-1]+int(2*operator.space.J_ar[m]+1))
#         for m in range(len(operator.space.J_ar)):
#             offsets.append(offsets[-1]+int(2*operator.space.J_ar[m]+1))
#         for m in range(len(operator.space.J_ar)*2):
#             if set(mapping[offsets[m]:offsets[m+1]]) != set(original_order[offsets[m]:offsets[m+1]]):
#                 raise RuntimeError("Changing between orbitals is not supported for Simulator Class, proceed with Quantum Circuit simulations or handle mapping by hand")"""

#         cdef int n, idx, i, j, k, l, n2, n4
#         cdef double scaled_coeff
#         cdef double N
        
#         if operator.is_fermionic == True:
#             self.is_fermionic = 1
#         else: 
#             self.is_fermionic = 0

#         ops_dict = operator.ops
#         func = operator.func
#         self.basis = basis._c_basis
#         self.pyBasis = basis
#         N = self.pyBasis._N_protons + self.pyBasis._N_neutrons

#         n = len(ops_dict)
#         self.op_sum.ops = <_C_operator*> malloc(n * sizeof(_C_operator))
#         if not self.op_sum.ops:
#             raise MemoryError()
#         self.op_sum.n_terms = n

#         # --- Pre-partition and scale coefficients (Python-level) ---
#         two_body = []
#         four_body = []
#         #  lambda x, A: -x/4*(scalings[1]/(scalings[0] + A))**scalings[2]
#         for key, (coeff, func_ind) in ops_dict.items():
#             if func is not None:
#                 scaled_coeff = coeff*(func[1]/(func[0]+N))**func[2] if func_ind else coeff
#             else:
#                 scaled_coeff = coeff
#             if len(key) == 2:
#                 two_body.append((key, scaled_coeff))
#             elif len(key) == 4:
#                 four_body.append((key, scaled_coeff))

#         n2 = len(two_body)
#         n4 = len(four_body)
#         #print("First part is worse")
#         # --- Raw C arrays (nogil-safe, no Python buffer protocol) ---
#         cdef int* two_i_arr = <int*> malloc(n2 * sizeof(int))
#         cdef int* two_j_arr = <int*> malloc(n2 * sizeof(int))
#         cdef double* two_coeffs_arr = <double*> malloc(n2 * sizeof(double))

#         cdef int* four_i_arr = <int*> malloc(n4 * sizeof(int))
#         cdef int* four_j_arr = <int*> malloc(n4 * sizeof(int))
#         cdef int* four_k_arr = <int*> malloc(n4 * sizeof(int))
#         cdef int* four_l_arr = <int*> malloc(n4 * sizeof(int))
#         cdef double* four_coeffs_arr = <double*> malloc(n4 * sizeof(double))

#         if not (two_i_arr and two_j_arr and two_coeffs_arr and
#                 four_i_arr and four_j_arr and four_k_arr and four_l_arr and four_coeffs_arr):
#             raise MemoryError()

#         # --- Populate C arrays (Python-level, runs once) ---
#         for idx in range(n2):
#             key, scaled_coeff = two_body[idx]
#             two_i_arr[idx] = key[0]
#             two_j_arr[idx] = key[1]
#             two_coeffs_arr[idx] = scaled_coeff

#         for idx in range(n4):
#             key, scaled_coeff = four_body[idx]
#             four_i_arr[idx] = key[0]
#             four_j_arr[idx] = key[1]
#             four_k_arr[idx] = key[2]
#             four_l_arr[idx] = key[3]
#             four_coeffs_arr[idx] = scaled_coeff

#         # --- Cache C-level basis pointer (nogil-safe, avoids self.basis access) ---
#         cdef _Basis c_basis = self.basis

#         # --- Hot loops: truly pure C, GIL released ---
#         with nogil:
#             for idx in prange(n2, schedule='dynamic'):
#                 self.op_sum.ops[idx].coefficient = two_coeffs_arr[idx]
#                 compute_full_op2(
#                     two_i_arr[idx], two_j_arr[idx],
#                     c_basis,
#                     &self.op_sum.ops[idx].op_p,
#                     &self.op_sum.ops[idx].op_n,
#                     &self.op_sum.ops[idx].order_parity
#                 )

#             for idx in prange(n4, schedule='dynamic'):
#                 self.op_sum.ops[n2 + idx].coefficient = four_coeffs_arr[idx]
#                 compute_full_op(
#                     four_i_arr[idx], four_j_arr[idx],
#                     four_k_arr[idx], four_l_arr[idx],
#                     c_basis,
#                     &self.op_sum.ops[n2 + idx].op_p,
#                     &self.op_sum.ops[n2 + idx].op_n,
#                     &self.op_sum.ops[n2 + idx].order_parity
#                 )

#         # --- Free temporary C arrays ---
#         free(two_i_arr)
#         free(two_j_arr)
#         free(two_coeffs_arr)
#         free(four_i_arr)
#         free(four_j_arr)
#         free(four_k_arr)
#         free(four_l_arr)
#         free(four_coeffs_arr)

#     def old_init(self, object operator, Basis basis):
#         ops_dict = operator.ops
#         func = operator.func
#         self.basis = basis._c_basis
#         self.pyBasis = basis

#         n = len(ops_dict)
#         self.op_sum.ops = <_C_operator*> malloc(n*sizeof(_C_operator))
#         if not self.op_sum.ops:
#             raise MemoryError()
#         self.op_sum.n_terms = n

#         cdef int idx = 0
#         for key, (coeff, func_ind) in ops_dict.items():

#             scaled_coeff = coeff
#             if func_ind:
#                 scaled_coeff = func(coeff, self.pyBasis._N_protons + self.pyBasis._N_neutrons)

#             if len(key) == 2:
#                 i, j = key
#                 compute_full_op2(i, j, basis._c_basis, 
#                                  &self.op_sum.ops[idx].op_p,
#                                  &self.op_sum.ops[idx].op_n,
#                                  &self.op_sum.ops[idx].order_parity)
#             elif len(key) == 4:
#                 i, j, k, l = key
#                 compute_full_op(i, j, k, l, basis._c_basis,
#                                 &self.op_sum.ops[idx].op_p,
#                                 &self.op_sum.ops[idx].op_n,
#                                 &self.op_sum.ops[idx].order_parity)
#             self.op_sum.ops[idx].coefficient = scaled_coeff
#             idx+=1
            
#     def apply(self, double[::1] state_in, double[::1] state_out):
#         multiply_state2(&self.op_sum, state_in.shape[0],
#                         &state_in[0], &state_out[0])
#         #multiply_state3(&self.op_sum, state_in.shape[0],
#         #                &state_in[0], &state_out[0])

#     def matvec(self, v): # Remove the double[:] type hint here
#         """
#         Applies the operator to a given states
#         Parameters
#         ----------
#             v :  ndarray
#                 The state on which the operator is applied
#         """
#         # Convert input to a 1D contiguous array safely
#         # This handles both (N,) and (N, 1) shapes
#         cdef double[::1] inp = np.ascontiguousarray(v, dtype=np.float64).ravel()
        
#         cdef int n = inp.shape[0]
#         cdef double[::1] out = np.zeros(n, dtype=np.float64)

#         # Call your C function
#         if self.is_fermionic == 1:
#             multiply_state2(&self.op_sum, n, &inp[0], &out[0])
#             #multiply_state3(&self.op_sum, n, &inp[0], &out[0])
#         else:
#             multiply_state_qubit(&self.op_sum, n, &inp[0], &out[0])    
#         # Return as a 1D array (SciPy's matvec expects 1D output)
#         return np.asarray(out)

#     # def matvec2(self, v): # Remove the double[:] type hint here
#     #     """
#     #     Applies the operator to a given states
#     #     Parameters
#     #     ----------
#     #         v :  ndarray
#     #             The state on which the operator is applied
#     #     """
#     #     # Convert input to a 1D contiguous array safely
#     #     # This handles both (N,) and (N, 1) shapes
#     #     cdef double[::1] inp = np.ascontiguousarray(v, dtype=np.float64).ravel()
        
#     #     cdef int n = inp.shape[0]
#     #     cdef double[::1] out = np.zeros(n, dtype=np.float64)

#     #     # Call your C function
#     #     if self.is_fermionic == 1:
#     #         multiply_state4(&self.op_sum, n, &inp[0], &out[0], self.basis.p_slaters.n_states)
#     #     else:
#     #         multiply_state_qubit(&self.op_sum, n, &inp[0], &out[0])    
#     #     # Return as a 1D array (SciPy's matvec expects 1D output)
#     #     return np.asarray(out)

#     def inner_product(self, a, b):
#         """
#         Applies the inner product <a|OP|b> efficiently
#         Parameters
#         ----------
#             a : ndarray
#                 The a state
#             b : ndarray
#                 The other state
#         """
#         cdef double[::1] in_a = np.ascontiguousarray(a, dtype = np.float64).ravel()
#         cdef double[::1] in_b = np.ascontiguousarray(b, dtype = np.float64).ravel()

#         cdef int n_a = in_a.shape[0]
#         cdef double out = 0

#         inner_prod(&self.op_sum, n_a, &in_a[0], &in_b[0], &out)

#         return out

#     def linear_op(self):
#         return sp.linalg.LinearOperator(
#             dtype=np.float64,
#             shape=(self.basis.mb_basis, self.basis.mb_basis),
#             matvec=self.matvec,
#             rmatvec=self.matvec,
#         )

#     def complex_linear_op(self):

#         def complex_matvec(v_complex):

#             re = np.array(v_complex.real, dtype=np.float64, order='C', copy=True).reshape(-1)
#             im = np.array(v_complex.imag, dtype=np.float64, order='C', copy=True).reshape(-1)

#             return self.matvec(re) + 1j * self.matvec(im)

#         return sp.linalg.LinearOperator(
#             dtype=np.float64,
#             shape=(self.basis.mb_basis, self.basis.mb_basis),
#             matvec=complex_matvec,
#             rmatvec=complex_matvec,
#         )

#     def to_csr(self):
    
#         cdef int nvalues
#         cdef uint32_t * rows
#         cdef uint32_t * cols
#         cdef double * data
#         cdef int dim = self.basis.mb_basis

#         if self.is_fermionic == 1:
#             expand_CSR(&self.op_sum, dim, &nvalues, &rows, &cols, &data)
#         else:
#             expand_CSR_qubit(&self.op_sum, dim, &nvalues, &rows, &cols, &data)
        
#         cdef cnp.ndarray rows_cy
#         cdef cnp.ndarray cols_cy
#         cdef cnp.ndarray data_cy 

#         if nvalues > 0:    
#             rows_cy = np.asarray(<unsigned int[:nvalues]> rows)
#             cols_cy = np.asarray(<unsigned int[:nvalues]> cols)
#             data_cy = np.asarray(<double [:nvalues]> data)

#             return sp.coo_matrix((data_cy, (rows_cy, cols_cy)), shape=(dim, dim)).tocsr()
#         else:
#             return None

#     def analyze_structure(self):
#         res = []
#         cdef OperatorSum opsum = self.op_sum
#         cdef int n = opsum.n_terms
#         cdef _C_operator cop
#         cdef OperatorSlater opslater
#         cdef int n_sectors 
#         cdef SectorJump secJump 
#         cdef int temp_sum
        
#         for i in range(n):
#             cop = opsum.ops[i]    
#             opslater =  cop.op_p
#             n_sectors = opslater.n_sectors
#             temp_sum = 0
#             for j in range(n_sectors):
#                 secJump = opslater.jumps[j]
#                 temp_sum += secJump.n_pairs
#             res.append(temp_sum)
#         return res

#     def __dealloc__(self):
#         if self.op_sum.ops != NULL:
#             free_opsum(self.op_sum)


def decouple(array_M, total_space_, input_file, mapping_):

    cdef int[::1] array_m = np.ascontiguousarray(array_M, dtype=np.int32)
    cdef int space_size = len(array_M)
    cdef int total_space = <int>total_space_
    cdef double * coeffs = NULL
    cdef int * indices = NULL
    cdef int n_one_bodies
    cdef int * mapping

    mapping = <int * > malloc(sizeof(int)*total_space*2)

    for i in range(total_space*2):
        mapping[i] = <int>mapping_[i]

    py_byte_string = input_file.encode('UTF-8')
    cdef const char* input2 = py_byte_string 
    cdef int * ptr_to_array_M = &array_m[0]

    decouple_to_arrays(&ptr_to_array_M, space_size, total_space,
            input2,
            &coeffs,  &indices, &n_one_bodies, mapping)

    free(mapping)
    cdef double[::1] coeffs_view = <double [:n_one_bodies]> coeffs
    cdef int[::1] indices_view = <int [:n_one_bodies*4]> indices

    py_coeffs = np.array(coeffs_view, copy=True)
    py_indices = np.array(indices_view, copy=True)

    free(coeffs)
    free(indices)

    return py_coeffs, py_indices

def decouple_np(array_M, total_space_, input_file, mapping_):

    cdef int[::1] array_m = np.ascontiguousarray(array_M, dtype=np.int32)
    cdef int space_size = len(array_M)//2
    cdef int total_space = <int>total_space_
    cdef double * coeffs = NULL
    cdef int * indices = NULL
    cdef int n_one_bodies
    cdef int * mapping

    mapping = <int * > malloc(sizeof(int)*total_space*2)

    for i in range(total_space*2):
        mapping[i] = <int>mapping_[i]

    py_byte_string = input_file.encode('UTF-8')
    cdef const char* input2 = py_byte_string 
    cdef int * ptr_to_array_M = &array_m[0]
    print("Size of space")
    print(space_size)
    decouple_to_arrays_np(&ptr_to_array_M, space_size, total_space,
            input2,
            &coeffs,  &indices, &n_one_bodies, mapping)

    free(mapping)
    cdef double[::1] coeffs_view = <double [:n_one_bodies]> coeffs
    cdef int[::1] indices_view = <int [:n_one_bodies*4]> indices

    py_coeffs = np.array(coeffs_view, copy=True)
    py_indices = np.array(indices_view, copy=True)

    free(coeffs)
    free(indices)

    return py_coeffs, py_indices

def decouple_from_list(array_M, total_space_, ind_coupled_, val_coupled_, n_terms_,mapping_):

    cdef int[::1] array_m = np.ascontiguousarray(array_M, dtype=np.int32)
    cdef int[::1] ind_coupled = np.ascontiguousarray(ind_coupled_, dtype=np.int32)
    cdef double[::1] val_coupled = np.ascontiguousarray(val_coupled_, dtype=np.float64)
    cdef int space_size = len(array_M)
    cdef int total_space = <int>total_space_
    cdef double * coeffs = NULL
    cdef int * indices = NULL
    cdef int n_one_bodies
    cdef int n_terms = <int>n_terms_

    cdef int * ptr_to_array_M = &array_m[0]

    cdef int * mapping

    mapping = <int * > malloc(sizeof(int)*total_space*2)

    for i in range(total_space*2):
        mapping[i] = <int>mapping_[i]
    
    decouple_to_arrays_from_arrays(&ptr_to_array_M, space_size, total_space,
            &ind_coupled[0], &val_coupled[0], n_terms,
            &coeffs,  &indices, &n_one_bodies, mapping)

    free(mapping)
    cdef double[::1] coeffs_view = <double [:n_one_bodies]> coeffs
    cdef int[::1] indices_view = <int [:n_one_bodies*4]> indices

    py_coeffs = np.array(coeffs_view, copy=True)
    py_indices = np.array(indices_view, copy=True)

    free(coeffs)
    free(indices)

    return py_coeffs, py_indices


def compute_phase(indices):
    cdef int ind
    cdef int a,b,c,d
    cdef int ass, bs, cs, ds
    if len(indices) != 4 and len(indices) != 2:
        return 0
    elif len(indices) == 4:
        ind = 1
        a,b,c,d = indices[0], indices[1], indices[2], indices[3]
        if a>b: 
            ind*=-1
            ass = b
            bs = a
        else:
            ass = a
            bs = b
        if c>d: 
            ind*=-1
            cs = d
            ds = c
        else:
            cs = c
            ds = d
        return ind, (ass, bs, cs, ds)
    elif len(indices) == 2:
        return 1, indices
        ind = 1
        a,b = indices[0], indices[1]
        if a>b: 
            ind*=-1
            ass = b
            bs = a
        else:
            ass = a
            bs = b
        return ind, (ass, bs)

