from scipy.sparse.linalg import LinearOperator
from scipy.sparse import csr_matrix
from pynucshell import Operator
from numpy import ndarray

class Space:
    def __init__(self, n_ar : list[int], L_ar : list[int], J_ar : list[int]):
        """
        Single-particle valence space definition.

        Parameters
        ----------
        n_ar : list[int]
            Principal quantum numbers for each sub-shell.
        L_ar : list[int]
            Orbital angular momentum for each sub-shell.
        J_ar : list[float]
            Total angular momentum j for each sub-shell (half-integer values).

        Example
        -------
        sd-shell::

            sd = Space([0, 1, 0], [2, 0, 2], [2.5, 0.5, 1.5])

        Attributes
        ----------
        half_space : int
            Number of single-particle states per isospin species.
        array_M : list[int]
            2*m values for all states (protons then neutrons).
        isospin : list[int]
            +1 for proton states, -1 for neutron states.
        array_J, array_N, array_L : list[int]
            Quantum numbers for every single-particle state.
        """
        ...
    def print_space(self):
        """
        Print a presentation of the orbitals in the space for the M-scheme
        """
    def set_mapping(self,mapping):
        """
        Sets a new mapping for the orbitals in the space. The input are the 
        new labels, and the index of the array is the old label.

        Example
        -------

            Space.set_mapping([5,4,3,2,1,0])

        will set the labels "5" to the old orbital 0, "4" to the old orbital 2,
        and so on.
        
        Parameters
        ----------
        maping : list[int]
            Order of the new orbitals.
        """

class Basis:
    """
    Creates a many-body basis with the given particle number and angular momentum.

    Parameters
    -------------
    space : Space
        Space to construct the many-body system
    N_protons:  int
        Number of protons
    N_neutrons: int
        Number of neutrons
    total_J : int
        Total angular momentum of the system.
    
    Methods
    ----------
    mb   : int
        Returns a numpy array with the slaters determinants of the basis
    """
    def __init__(self, space : Space, N_protons :  int, N_neutrons: int, total_J : int):
        ...
    
    def mb(self):
        """
        Return a numpy array with the basis with shape (N_states, N_particles)
        """
        ...
    def set_state(self, slater_det) -> ndarray:
        """
        Returns a numpy array with coefficient 1 in fron of the provided slater 
        determinant

        Parameters
        ----------
        slater_det : Tuple(int)
            A tuple representing the labels of the slater determinants
        """

class Simulator:
    """
    This is a simulator for computing many-body calculations without 
    the construction of circuits. Provides a matrix-free operator acting
    on the many-body basis

    Parameters
    ----------
    op : Operator
        Operator which will act on states
    basis : Basis
        Basis in which the operator will act on.
    """
    def __init__(self, space : Space, basis : Basis ):
        ...
    
    def mb(self):
        """
        Return a numpy array with the basis with shape (N_states, N_particles)
        """
        ...

    def linear_op(self) -> LinearOperator:
        """
        Returns a scipy LinearOperator. Useful for matrix-free operations
        """
        ...
    def to_csr(self) -> csr_matrix:
        """
        Returns the csr matrix
        """
        ...

    def to_lin_op(self, operator : Operator) -> LinOp:
        """
        Returns a Linear Operator from SciPy
        """
        ...
        return LinOp(CoreLinOP(operator, self, self.basis))

class CoreLinOP:

    def __init__(self, operator : Operator, sim : Simulator, basis : Basis):
        """
        Bridge between simulator and linear operator in cython
        """
        ...

    def matvec(self, v): # Remove the double[:] type hint here
        """
        Applies the operator to a given states
        Parameters
        ----------
            v :  ndarray
                The state on which the operator is applied
        """

    def complex_matvec(self, v): # Remove the double[:] type hint here
        """
        Applies the operator to a given states
        Parameters
        ----------
            v :  ndarray
                The state on which the operator is applied
        """
        ...

    def linear_op(self):
        """
        Returns the linear operator in SciPy format without additional functions
        """

    def complex_linear_op(self):
        """
        Returns the linear operator in SciPy format without additional functions
        """

    def trace(self):
        """
        Computes the trace of the linear operator efficiently
        """
        ...

    def inner_product(self, a, b):
        """
        Computes inner product of the operator with the vectors efficiently
        """
        ...

    def __dealloc__(self):
        """
        Deallocates the operator
        """
        ...

class LinOp(LinearOperator):
    """
    
    """

    def __init__(self, corelin: CoreLinOP, ):
        """
        Returns the linear operator in SciPy format with additional functions
        """

    def _matvec(self, v):
        """
        Applies the operator to a given states
        Parameters
        ----------
            v :  ndarray
                The state on which the operator is applied
        """

    def _rmatvec(self, v):
        """
        Applies the operator to a given states
        Parameters
        ----------
            v :  ndarray
                The state on which the operator is applied
        """

    def trace(self):
        """
        Computes the trace of the linear operator efficiently
        """
        ...

    def inner_product(self, a, b):
        """
        Computes inner product of the operator with the vectors efficiently
        """
        ...

class LinExcOp(LinOp):
    def exp(self, a, theta):
        """
        Computes exponential of an operator with an angle efficiently
        """
        ...
        
class SimulatorExcOp:
    """
    This is a simulator for computing many-body calculations without 
    the construction of circuits. Provides a matrix-free operator acting
    on the many-body basis. It is only used for Excitation Operators

    Parameters
    ----------
    op : Operator
        Operator which will act on states
    basis : Basis
        Basis in which the operator will act on.
    """

