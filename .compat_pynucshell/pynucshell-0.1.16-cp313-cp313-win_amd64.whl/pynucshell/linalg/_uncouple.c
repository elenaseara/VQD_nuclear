#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "_uncouple.h"

double factorial(int n) {
    if (n < 0) return 0;
    double res = 1.0;
    for (int i = 2; i <= n; i++) res *= i;
    return res;
}

double CG(int j1x2, int m1x2, int j2x2, int m2x2, int Jx2, int Mx2) {
    // 1. Selection Rules
    if (m1x2 + m2x2 != Mx2) return 0.0;
    if (Jx2 < abs(j1x2 - j2x2) || Jx2 > (j1x2 + j2x2)) return 0.0;
    if (abs(m1x2) > j1x2 || abs(m2x2) > j2x2 || abs(Mx2) > Jx2) return 0.0;
    // Parity check: (j + m) must be even (since 2j and 2m have same parity)
    if ((j1x2 + m1x2) % 2 != 0 || (j2x2 + m2x2) % 2 != 0 || (Jx2 + Mx2) % 2 != 0) return 0.0;

    // 2. Prefactor calculation
    double prefactor = sqrt((double)(Jx2 + 1) * factorial((Jx2 + j1x2 - j2x2) / 2) * factorial((Jx2 - j1x2 + j2x2) / 2) * factorial((j1x2 + j2x2 - Jx2) / 2) / 
        factorial((j1x2 + j2x2 + Jx2 + 2) / 2));

    double sums_factor = sqrt(factorial((Jx2 + Mx2) / 2) * factorial((Jx2 - Mx2) / 2) * factorial((j1x2 - m1x2) / 2) * factorial((j1x2 + m1x2) / 2) * factorial((j2x2 - m2x2) / 2) * factorial((j2x2 + m2x2) / 2));

    // 3. Summation (Racah Formula)
    double sum = 0.0;
    // We iterate through k such that all factorial arguments are >= 0
    for (int k = 0; ; k++) {
        int d1 = (j1x2 + j2x2 - Jx2) / 2 - k;
        int d2 = (j1x2 - m1x2) / 2 - k;
        int d3 = (j2x2 + m2x2) / 2 - k;
        int d4 = (Jx2 - j2x2 + m1x2) / 2 + k;
        int d5 = (Jx2 - j1x2 - m2x2) / 2 + k;

        if (d1 < 0 || d2 < 0 || d3 < 0) {
            if (k > 0) break; else continue; 
        }
        if (d4 < 0 || d5 < 0) {
            continue; // Skip until k makes these positive
        }

        double term = pow(-1, k) / (factorial(k) * factorial(d1) * factorial(d2) * factorial(d3) * factorial(d4) * factorial(d5));
        sum += term;
        
        // Safety break for loop
        if (k > (j1x2 + j2x2 + Jx2)) break; 
    }

    return prefactor * sums_factor * sum;
}

int* get_product_range_4(int D, long *total_elements) {
    long num_combinations = (long)pow(D, 4);
    *total_elements = num_combinations * 4;
    
    // Allocate memory for the flattened array
    int *combinations = (int *)malloc((*total_elements) * sizeof(int));
    if (combinations == NULL) {
        fprintf(stderr, "Memory allocation failed!\n");
        return NULL;
    }

    long index = 0;

    // Nested loops representing repeat=4
    for (int i = 0; i < D; i++) {
        for (int j = 0; j < D; j++) {
            for (int k = 0; k < D; k++) {
                for (int l = 0; l < D; l++) {
                    combinations[index++] = i;
                    combinations[index++] = j;
                    combinations[index++] = k;
                    combinations[index++] = l;
                }
            }
        }
    }

    return combinations;
}

static inline size_t idx6(const abcdTJV *a,
                          size_t i1, size_t i2, size_t i3,
                          size_t i4, size_t i5, size_t i6)
{
    return (((((i1 * a->d2 + i2)
               * a->d3 + i3)
               * a->d4 + i4)
               * a->d5 + i5)
               * a->d6 + i6);
}

static inline size_t idx5(const abcdJV *a,
                          size_t i1, size_t i2, size_t i3,
                          size_t i4, size_t i5)
{
    return ((((i1 * a->d2 + i2)
               * a->d3 + i3)
               * a->d4 + i4)
               * a->d5 + i5);
}

void define_M_space(int total_orbital, int J_orbital, int * space_J, int **MZ, int **MTOT, int **MT, int **J_or){

    int counter = 0;

    *MZ = (int*)malloc(total_orbital*2 * sizeof(int));

    *MT = (int*)malloc(total_orbital*2 * sizeof(int));

    *MTOT = (int*)malloc(total_orbital*2 * sizeof(int));

    *J_or = (int*)malloc(total_orbital*2 * sizeof(int));

    for( int i = 0; i < J_orbital; i++){
        for (int j = space_J[i] -1 ; j >= -space_J[i] + 1; j-=2) {
            (*J_or)[counter] = i + 1;       // TODO[REINDEXING]
            (*MTOT)[counter] = space_J[i] - 1;
            (*MT)[counter] = 1;
            (*MZ)[counter] = j;
            counter +=1;
        }
    }

    for( int i = 0; i < J_orbital; i++){
        for (int j = space_J[i] -1 ; j >= -space_J[i] + 1; j-=2) {
            (*J_or)[counter] = i + 1;
            (*MTOT)[counter] = space_J[i] - 1;
            (*MT)[counter] = -1;
            (*MZ)[counter] = j;
            counter +=1;
        }
    }
}

void define_M_space_np(int total_orbital, int J_orbital, int * space_J, int **MZ, int **MTOT, int **MT, int **J_or){

    int counter = 0;

    *MZ = (int*)malloc(total_orbital*2 * sizeof(int));

    *MT = (int*)malloc(total_orbital*2 * sizeof(int));

    *MTOT = (int*)malloc(total_orbital*2 * sizeof(int));

    *J_or = (int*)malloc(total_orbital*2 * sizeof(int));

    for( int i = 0; i < J_orbital; i++){
        for (int j = space_J[i] -1 ; j >= -space_J[i] + 1; j-=2) {
            (*J_or)[counter] = i + 1;       // TODO[REINDEXING]
            (*MTOT)[counter] = space_J[i] - 1;
            (*MT)[counter] = 1;
            (*MZ)[counter] = j;
            counter +=1;
        }
    }

    for( int i = 0; i < J_orbital; i++){
        for (int j = space_J[i] -1 ; j >= -space_J[i] + 1; j-=2) {
            (*J_or)[counter] = i + 1 + J_orbital;
            (*MTOT)[counter] = space_J[i] - 1;
            (*MT)[counter] = -1;
            (*MZ)[counter] = j;
            counter +=1;
        }
    }
}

// Function to check if string `name` ends with extension `ext`
static inline int extension_match(const char *name, const char *ext){
	size_t len_name = strlen(name), len_ext = strlen(ext);
    if(len_name <= len_ext){ return 0;}
	return !strcmp(name + len_name - len_ext, ext); //strcmp 0 if equal
}


static inline int find_index(int *shells, int shell_size, int state){
    for(int i = 0; i < shell_size; i++){
        if(shells[i] == state){ return i;}
    }
    return -1;
}

// Saves all permutations of interactions, with corresponding phase, for ease of access later, 
// as there is no consistent preferred ordering. It also unnormalizes them when necessary,
// so when decoupling there is no need to take sqrt(2) factors into account
static inline void renorm_and_permute_interaction(abcdTJV V_int, int a, int b, int c, int d, int J, int T, \
                                       double strength, int ** array_M){
    // Normalization factor of coupled basis is taken here (relevant for decoupling)
    if(a == b && (J+T)%2!=0 ){
        strength *= sqrt(2);// 2/sqrt(1-pow((-1),(J+T)));
    }
    if( d == c && (J+T)%2!=0){
        strength *= sqrt(2); // 2/sqrt(1-pow((-1),(J+T)));
    }
    if (strength != 0.0){
        int ja = (*array_M)[a-1] - 1;        // TODO[REINDEXING]: -1 artifact of indexing starting with 1 in C
        int jb = (*array_M)[b-1] - 1;
        int jc = (*array_M)[c-1] - 1;
        int jd = (*array_M)[d-1] - 1;

        V_int.data[idx6(&V_int, a, b, c, d, J, T)] = strength;
        V_int.data[idx6(&V_int, c, d, a, b, J, T)] = strength;

        int phase_AB = ((ja+jb)/2+J+T)%2 == 0 ? 1 : -1; // (-1)^(j_a + j_b + J + T)

        V_int.data[idx6(&V_int, b, a, c, d, J, T)] = strength*phase_AB;
        V_int.data[idx6(&V_int, c, d, b, a, J, T)] = strength*phase_AB;

        int phase_CD = ((jc+jd)/2+J+T)%2 == 0 ? 1 : -1;

        V_int.data[idx6(&V_int, a, b, d, c, J, T)] = strength*phase_CD;
        V_int.data[idx6(&V_int, d, c, a, b, J, T)] = strength*phase_CD;

        V_int.data[idx6(&V_int, b, a, d, c, J, T)] = strength*phase_AB*phase_CD;
        V_int.data[idx6(&V_int, d, c, b, a, J, T)] = strength*phase_AB*phase_CD;
        
    }
}

static inline void renorm_and_permute_interaction_np(abcdJV V_int, int a, int b, int c, int d, int J, \
                                       double strength, int ** array_M, int half_space){
    //  Half state denotes np- orbital partition
    // Normalization factor of coupled basis is taken here (relevant for decoupling)
    if(a == b && (J)%2==0 ){
        strength *= sqrt(2);// 2/sqrt(1-pow((-1),(J)));
    }
    if( d == c && (J)%2==0){
        strength *= sqrt(2); // 2/sqrt(1-pow((-1),(J)));
    }

    int is_np;

    if ( a <= half_space && b <= half_space && c <= half_space && d <= half_space ){
        is_np = 0;
    } else if (a > half_space && b > half_space && c > half_space && d > half_space){
        is_np = 0;
    } else {
        is_np = 1;
    }

    if (strength != 0.0){
        int ja = (*array_M)[a-1] - 1;        // TODO[REINDEXING]: -1 artifact of indexing starting with 1 in C
        int jb = (*array_M)[b-1] - 1;
        int jc = (*array_M)[c-1] - 1;
        int jd = (*array_M)[d-1] - 1;

        V_int.data[idx5(&V_int, a, b, c, d, J)] = strength;
        V_int.data[idx5(&V_int, c, d, a, b, J)] = strength;

        if ( is_np == 0){
            int phase_AB = ((ja+jb)/2+J+1)%2 == 0 ? 1 : -1; // (-1)^(j_a + j_b + J + T)

            V_int.data[idx5(&V_int, b, a, c, d, J)] = strength*phase_AB;
            V_int.data[idx5(&V_int, c, d, b, a, J)] = strength*phase_AB;

            int phase_CD = ((jc+jd)/2+J+1)%2 == 0 ? 1 : -1;

            V_int.data[idx5(&V_int, a, b, d, c, J)] = strength*phase_CD;
            V_int.data[idx5(&V_int, d, c, a, b, J)] = strength*phase_CD;

            V_int.data[idx5(&V_int, b, a, d, c, J)] = strength*phase_AB*phase_CD;
            V_int.data[idx5(&V_int, d, c, b, a, J)] = strength*phase_AB*phase_CD;
        }
    }
}

// Takes coupled interaction file (in BIGSTICK or ANTOINE format) and reads TBME
// TODO: Does not gracefuly carry errors to python, exit() clauses will crash interpreter.
//       option: return abcdTJV with NULL data as error indicator, to be caught by Cython down the road.
abcdTJV read_data(const char*file_name, int size, int ** array_M){
    FILE * fptr;
    fptr = fopen(file_name,"r");
    if (fptr == NULL) {
        printf("Problem while opening: \"%s\"\n", file_name);
        perror("Error opening file");
        exit(EXIT_FAILURE);
    }

    abcdTJV V_int;

    V_int.d1 = size + 1;    // TODO[REINDEXING]: Optimize (remove + 1) by reindexing from 0
    V_int.d2 = size + 1;
    V_int.d3 = size + 1;
    V_int.d4 = size + 1;
    V_int.d5 = 2*size + 1;
    V_int.d6 = 2;

    V_int.data = calloc(V_int.d1 * V_int.d2 * V_int.d3 * V_int.d4 * V_int.d5 * V_int.d6, sizeof(double));

    if (V_int.data == NULL) {
        printf("Memory allocation failed while trying to read: \"%s\"\n", file_name);
        perror("Error allocating memory");
        exit(EXIT_FAILURE);
    }

    char line[256]; // Temp variable to hold lines read
    int size_int;   // number of interactions

    char *token;    // Tokens to iterate over values in lines

    if (extension_match(file_name, ".int")){
        fgets(line, sizeof(line), fptr);
        
        // lines starting with ! are comments, ignored
        while(line[0]=='!'){
            fgets(line, sizeof(line), fptr);
        }

        // Read number of tbme
        token = strtok(line, " ");
        size_int = atoi(token);

        if(size_int < 0){
            size_int = size_int*-1;
        }

        //printf("%d", size_int);

        // Reading TBMEs
        for(int i = 0; i<size_int; i++){
            fgets(line, sizeof(line), fptr);
            token = strtok(line, " ");

            int a = atoi(token);
            token = strtok(NULL, " "); // NULL tells strtok to continue splitting previous input (line)
            int b = atoi(token);
            token = strtok(NULL, " ");
            int c = atoi(token);
            token = strtok(NULL, " ");
            int d = atoi(token);
            token = strtok(NULL, " ");
            int J = atoi(token);
            token = strtok(NULL, " ");
            int T = atoi(token);
            token = strtok(NULL, " ");

            double strength = atof(token);
            renorm_and_permute_interaction(V_int, a, b, c, d, J, T, strength, array_M);
        }
    }
    else{
        // Assuming extension is none: ANTOINE Format
        // first line is header / comment
        fgets(line, sizeof(line), fptr);

        // read shell space, eg:  1 3 205  1001  203
        // WE ASSUME FIRST PARAM IS 1: QMAX = 1 --> Same energy for neutrons and protons
        fgets(line, sizeof(line), fptr);
        
        token = strtok(line, " ");
        int qmax = atoi(token);

        if (qmax != 1){
            printf("WARNING: Got qmax value of: %d, but only qmax=1 is supported (same energy for neutrons and protons)", qmax);
            exit(EXIT_FAILURE); // File cleanup is expected to be handled by OS
        }
        
        token = strtok(NULL, " "); // Read next token
        int size_shell_int = atoi(token);
        if(size != size_shell_int){
            printf("WARNING: provided shell dimension %d does not match dimension specified in interaction file %d", size, size_shell_int);
            exit(EXIT_FAILURE);
        }

        int *shell_space = malloc(sizeof(int)*size_shell_int);
        for(int i = 0; i < size_shell_int; i++){
            token = strtok(NULL, " ");
            shell_space[i] = atoi(token);
        }

        fgets(line, sizeof(line), fptr); // Read Single particle energies line
        fgets(line, sizeof(line), fptr); // Read N, Z, shell and mass dependence line
        
        int Tmin, Tmax, Jmin, Jmax;
        int a,b,c,d;
        double V;

        while(fgets(line, sizeof(line), fptr) != NULL){
            // First line of the form `TMIN, TMAX, (NLJ( k ), k= 1, 4), JMIN, JMAX`
            if(strlen(line) < 5){break;} // Empty line check 
            token = strtok(line, " ");
            Tmin = atoi(token);
            token = strtok(NULL, " ");
            Tmax = atoi(token);
            
            token = strtok(NULL, " ");
            a = find_index(shell_space, size_shell_int, atoi(token)) + 1;
            token = strtok(NULL, " ");
            b = find_index(shell_space, size_shell_int, atoi(token)) + 1;
            token = strtok(NULL, " ");
            c = find_index(shell_space, size_shell_int, atoi(token)) + 1;
            token = strtok(NULL, " ");
            d = find_index(shell_space, size_shell_int, atoi(token)) + 1;

            // CAREFUL, WE ARE NOT CHECKING IF indexes WERE FOUND (CHECKING IF THEY ARE == -1)
            // DANGEROUS FOR MODIFIED FILES

            token = strtok(NULL, " ");
            Jmin = atoi(token);
            token = strtok(NULL, " ");
            Jmax = atoi(token);
            
            for(int t = Tmin; t<=Tmax; ++t){
                fgets(line, sizeof(line), fptr);
                token = strtok(line, " ");
                for(int j = Jmin; j<=Jmax; ++j){
                    V = atof(token);
                    renorm_and_permute_interaction(V_int, a, b, c, d, j, t, V, array_M);
                    token = strtok(NULL, " ");
                }
            }
            
        }
    }

    fclose(fptr);
    return V_int;
}

abcdJV read_data_np(const char*file_name, int size, int ** array_M){
    FILE * fptr;
    fptr = fopen(file_name,"r");
    if (fptr == NULL) {
        printf("Problem while opening: \"%s\"\n", file_name);
        perror("Error opening file");
        exit(EXIT_FAILURE);
    }

    abcdJV V_int;

    V_int.d1 = 2*size + 1;    // TODO[REINDEXING]: Optimize (remove + 1) by reindexing from 0
    V_int.d2 = 2*size + 1;
    V_int.d3 = 2*size + 1;
    V_int.d4 = 2*size + 1;
    V_int.d5 = 2*size + 1;

    V_int.data = calloc(V_int.d1 * V_int.d2 * V_int.d3 * V_int.d4 * V_int.d5, sizeof(double));

    if (V_int.data == NULL) {
        printf("Memory allocation failed while trying to read: \"%s\"\n", file_name);
        perror("Error allocating memory");
        exit(EXIT_FAILURE);
    }

    char line[256]; // Temp variable to hold lines read
    int size_int;   // number of interactions

    char *token;    // Tokens to iterate over values in lines

    if (extension_match(file_name, ".int")){
        fgets(line, sizeof(line), fptr);
        
        // lines starting with ! are comments, ignored
        while(line[0]=='!'){
            fgets(line, sizeof(line), fptr);
        }

        // Read number of tbme
        token = strtok(line, " ");
        size_int = atoi(token);

        if(size_int < 0){
            size_int = size_int*-1;
        }

        //printf("%d", size_int);

        // Reading TBMEs
        for(int i = 0; i<size_int; i++){
            fgets(line, sizeof(line), fptr);
            token = strtok(line, " ");

            int a = atoi(token);
            token = strtok(NULL, " "); // NULL tells strtok to continue splitting previous input (line)
            int b = atoi(token);
            token = strtok(NULL, " ");
            int c = atoi(token);
            token = strtok(NULL, " ");
            int d = atoi(token);
            token = strtok(NULL, " ");
            int J = atoi(token);
            token = strtok(NULL, " ");
            int T = atoi(token);
            token = strtok(NULL, " ");

            double strength = atof(token);
            renorm_and_permute_interaction_np(V_int, a, b, c, d, J, strength, array_M, size);
        }
    }
    fclose(fptr);
    return V_int;
}

int check_Pauli(int a, int b, int c, int d){
    if ((a == b) || (c == d)) {
        return 0;
    } else {
        return 1;
    }
}

int conserve_mz(int a, int b, int c, int d, int **MZ){
    int mz_val = 0;
    mz_val += (*MZ)[a];
    mz_val += (*MZ)[b];
    mz_val -= (*MZ)[c];
    mz_val -= (*MZ)[d];

    if (mz_val == 0){
        return 1;
    }
    else{
        return 0;
    }
}

int conserve_isospin(int a, int b, int c, int d, int **MT){
    int mt_val = 0;
    mt_val += (*MT)[a];
    mt_val += (*MT)[b];
    mt_val -= (*MT)[c];
    mt_val -= (*MT)[d];

    if (mt_val == 0){
        return 1;
    }
    else{
        return 0;
    }
}

double coefficient(int i1, int i2, int i3, int i4, int **MZ, int **MTOT, int **MT, int **J_or, abcdTJV *interaction){
    int M = (*MZ)[i1]+(*MZ)[i2];
    int TM = (*MT)[i1] + (*MT)[i2];
    int ja = (*MTOT)[i1];
    int jb = (*MTOT)[i2];
    int jc = (*MTOT)[i3];
    int jd = (*MTOT)[i4];
    int a = (*J_or)[i1];
    int b = (*J_or)[i2];
    int c = (*J_or)[i3];
    int d = (*J_or)[i4];
    double result = 0;
    for( int J = 0; J < MAX(ja+jb,jc+jd)/2+1; J++){
        for(int T = 0; T < 2; T++){

            double prefactor;

            prefactor = interaction->data[idx6(interaction, a, b, c, d, J, T)];

            result += ((prefactor * CG(ja,(*MZ)[i1],jb,(*MZ)[i2],2*J,M)*CG(jc,(*MZ)[i3],jd,(*MZ)[i4],2*J,M)*CG(1,(*MT)[i1],1,(*MT)[i2],2*T,TM)*CG(1,(*MT)[i3],1,(*MT)[i4],2*T,TM)));
        }
    }
    return result;
}

double coefficient_np(int i1, int i2, int i3, int i4, int **MZ, int **MTOT, int **J_or, abcdJV *interaction, int half_space){
    int is_np, phase;
    if ( i1 < half_space && i2 < half_space && i3< half_space && i4 < half_space ){
        is_np = 0;
    } else if (i1 >= half_space && i2 >= half_space && i3>= half_space && i4 >= half_space){
        is_np = 0;
    } else {
        is_np = 1;
    }
    phase = 1;
    if (is_np == 1 && i1 >= half_space && i2 < half_space ){
        int temp = i1;
        i1 = i2;
        i2 = temp;
        phase *= -1;
    } 
    if ( is_np == 1 && i3 >= half_space && i4 < half_space){
        int temp = i3;
        i3 = i4;
        i4 = temp;
        phase *= -1;
    }

    int M = (*MZ)[i1]+(*MZ)[i2];
    int ja = (*MTOT)[i1];
    int jb = (*MTOT)[i2];
    int jc = (*MTOT)[i3];
    int jd = (*MTOT)[i4];
    int a = (*J_or)[i1];
    int b = (*J_or)[i2];
    int c = (*J_or)[i3];
    int d = (*J_or)[i4];
    double result = 0;

    for( int J = 0; J < MAX(ja+jb,jc+jd)/2+1; J++){

        double prefactor;

        prefactor = interaction->data[idx5(interaction, a, b, c, d, J)];

        result += (prefactor * CG(ja,(*MZ)[i1],jb,(*MZ)[i2],2*J,M)*CG(jc,(*MZ)[i3],jd,(*MZ)[i4],2*J,M));
    }

    return result * phase;
}


int run_task(int ** array_M, int space_size, int total_space,
             const char *input2,
             const char *output){

    int *MZ, *MTOT, *MT, *J_or;
    printf("The total space %d\n", total_space);

    define_M_space(total_space, space_size, *array_M, &MZ, &MTOT, &MT, &J_or);
    int counter = total_space*2;
    
    for(int i = 0; i < counter; i++){
        printf("%d ", MZ[i]);
    }
    printf("\n");
    for(int i = 0; i < counter; i++){
        printf("%d ", MTOT[i]);
    }
    printf("\n");
    for(int i = 0; i < counter; i++){
        printf("%d ", MT[i]);
    }

    abcdTJV interaction = read_data(input2,space_size, array_M);
    long total_size;
    int * ar = get_product_range_4(total_space*2, &total_size);
    double coeff;
    int i1, i2, i3, i4;

    FILE *output_file = fopen(output, "w");
    if (output_file == NULL) {
        printf("Failed to open output file\n");
        return 1;
    }

    for (int i = 0; i < total_size/4; i++){
        i1 = ar[i*4 + 0];
        i2 = ar[i*4 + 1];
        i3 = ar[i*4 + 2];
        i4 = ar[i*4 + 3];
        if (check_Pauli(i1,i2,i3,i4) == 1 && conserve_mz(i1,i2,i3,i4, &MZ) == 1 && conserve_isospin(i1,i2,i3,i4, &MT) == 1){
            coeff = coefficient(i1,i2,i3,i4,&MZ,&MTOT,&MT, &J_or, &interaction);
            if (coeff != 0.0) {
                fprintf(output_file, "%f %d %d %d %d\n", coeff, i1, i2, i3, i4);
            }
        }
    }
    
    fclose(output_file);

    free(MZ);
    free(MTOT);
    free(MT);
    free(J_or);
    free(interaction.data);
    free(ar);
}

int run_task_np(int ** array_M, int space_size, int total_space,
             const char *input2,
             const char *output){

    int *MZ, *MTOT, *MT, *J_or;
    printf("The total space %d\n", total_space);

    define_M_space_np(total_space, space_size, *array_M, &MZ, &MTOT, &MT, &J_or);
    int counter = total_space*2;
    
    for(int i = 0; i < counter; i++){
        printf("%d ", MZ[i]);
    }
    printf("\n");
    for(int i = 0; i < counter; i++){
        printf("%d ", MTOT[i]);
    }
    printf("\n");
    for(int i = 0; i < counter; i++){
        printf("%d ", MT[i]);
    }

    abcdJV interaction = read_data_np(input2,space_size, array_M);
    long total_size;
    int * ar = get_product_range_4(total_space*2, &total_size);
    double coeff;
    int i1, i2, i3, i4;

    FILE *output_file = fopen(output, "w");
    if (output_file == NULL) {
        printf("Failed to open output file\n");
        return 1;
    }

    for (int i = 0; i < total_size/4; i++){
        i1 = ar[i*4 + 0];
        i2 = ar[i*4 + 1];
        i3 = ar[i*4 + 2];
        i4 = ar[i*4 + 3];
        if (check_Pauli(i1,i2,i3,i4) == 1 && conserve_mz(i1,i2,i3,i4, &MZ) == 1 && conserve_isospin(i1,i2,i3,i4, &MT) == 1){
            coeff = coefficient_np(i1,i2,i3,i4,&MZ,&MTOT, &J_or, &interaction, total_space);
            if (coeff != 0.0) {
                fprintf(output_file, "%f %d %d %d %d\n", coeff, i1, i2, i3, i4);
            }
        }
    }
    
    fclose(output_file);

    free(MZ);
    free(MTOT);
    free(MT);
    free(J_or);
    free(interaction.data);
    free(ar);
}

void decouple_to_arrays(int ** array_M, int space_size, int total_space,
             const char *input2,
             double ** coeffs, int ** indices, int * n_one_bodies, int * mapping){

    int *MZ_temp, *MTOT_temp, *MT_temp, *J_or_temp;
    //printf("The total space %d\n", total_space);

    define_M_space(total_space, space_size, *array_M, &MZ_temp, &MTOT_temp, &MT_temp, &J_or_temp);
    int counter = total_space*2;

    int *MZ, *MTOT, *MT, *J_or;
    MZ = (int*)malloc(sizeof(int)*total_space*2);
    MT = (int*)malloc(sizeof(int)*total_space*2);
    MTOT = (int*)malloc(sizeof(int)*total_space*2);
    J_or = (int*)malloc(sizeof(int)*total_space*2);

    // for (int i = 0; i< total_space*2; i++){
    //     printf("The mapping index %d %d\n", i, mapping[i]);
    // }

    for (int i = 0; i < total_space*2; i++){
        MZ[i] = MZ_temp[mapping[i]];
        MT[i] = MT_temp[mapping[i]];
        MTOT[i] = MTOT_temp[mapping[i]];
        J_or[i] = J_or_temp[mapping[i]];
    }

    free(MZ_temp);
    free(MTOT_temp);
    free(MT_temp);
    free(J_or_temp);

    for(int i = 0; i < counter; i++){
        //printf("%d ", MZ[i]);
    }
    //printf("\n");
    for(int i = 0; i < counter; i++){
        //printf("%d ", MTOT[i]);
    }
    //printf("\n");
    for(int i = 0; i < counter; i++){
        //printf("%d ", MT[i]);
    }

    abcdTJV interaction = read_data(input2,space_size, array_M);
    long total_size;
    int * ar = get_product_range_4(total_space*2, &total_size);
    double coeff;
    int i1, i2, i3, i4;

    int capacity = 16384;
    (*coeffs) = (double*)malloc(sizeof(double)*capacity);
    (*indices) = (int *)malloc(sizeof(int)*capacity*4);
    counter = 0;

    for (int i = 0; i < total_size/4; i++){
        i1 = ar[i*4 + 0];
        i2 = ar[i*4 + 1];
        i3 = ar[i*4 + 2];
        i4 = ar[i*4 + 3];
        if (check_Pauli(i1,i2,i3,i4) == 1 && conserve_mz(i1,i2,i3,i4, &MZ) == 1 && conserve_isospin(i1,i2,i3,i4, &MT) == 1){
            coeff = coefficient(i1,i2,i3,i4,&MZ,&MTOT,&MT, &J_or, &interaction);
            if (coeff != 0.0 && counter < capacity) {
                (*coeffs)[counter] = coeff;
                (*indices)[4*counter] = i1;
                (*indices)[4*counter + 1] = i2;
                (*indices)[4*counter + 2] = i3;
                (*indices)[4*counter + 3] = i4;
                counter++;
                //fprintf(output_file, "%f %d %d %d %d\n", coeff, i1, i2, i3, i4);
            } else if (coeff != 0.0) {
                capacity *= 2;
                *coeffs = realloc(*coeffs, sizeof(double) * capacity);
                *indices = realloc(*indices, sizeof(int) * capacity * 4);
                (*coeffs)[counter] = coeff;
                (*indices)[4*counter] = i1;
                (*indices)[4*counter + 1] = i2;
                (*indices)[4*counter + 2] = i3;
                (*indices)[4*counter + 3] = i4;
                counter++;
            }
        }
    }
    
    *coeffs = realloc(*coeffs, sizeof(double) * counter);
    *indices = realloc(*indices, sizeof(int) * counter * 4);

    *n_one_bodies = counter;

    free(MZ);
    free(MTOT);
    free(MT);
    free(J_or);
    free(interaction.data);
    free(ar);
}

void decouple_to_arrays_np(int ** array_M, int space_size, int total_space,
             const char *input2,
             double ** coeffs, int ** indices, int * n_one_bodies, int * mapping){

    int *MZ_temp, *MTOT_temp, *MT_temp, *J_or_temp;
    //printf("The total space %d\n", total_space);

    define_M_space_np(total_space, space_size, *array_M, &MZ_temp, &MTOT_temp, &MT_temp, &J_or_temp);
    int counter = total_space*2;

    int *MZ, *MTOT, *MT, *J_or;
    MZ = (int*)malloc(sizeof(int)*total_space*2);
    MT = (int*)malloc(sizeof(int)*total_space*2);
    MTOT = (int*)malloc(sizeof(int)*total_space*2);
    J_or = (int*)malloc(sizeof(int)*total_space*2);

    // for (int i = 0; i< total_space*2; i++){
    //     printf("The mapping index %d %d\n", i, mapping[i]);
    // }

    for (int i = 0; i < total_space*2; i++){
        MZ[i] = MZ_temp[mapping[i]];
        MT[i] = MT_temp[mapping[i]];
        MTOT[i] = MTOT_temp[mapping[i]];
        J_or[i] = J_or_temp[mapping[i]];
    }

    free(MZ_temp);
    free(MTOT_temp);
    free(MT_temp);
    free(J_or_temp);

    abcdJV interaction = read_data_np(input2,space_size, array_M);
    long total_size;
    int * ar = get_product_range_4(total_space*2, &total_size);
    double coeff;
    int i1, i2, i3, i4;

    int capacity = 16384;
    (*coeffs) = (double*)malloc(sizeof(double)*capacity);
    (*indices) = (int *)malloc(sizeof(int)*capacity*4);
    counter = 0;

    for (int i = 0; i < total_size/4; i++){
        i1 = ar[i*4 + 0];
        i2 = ar[i*4 + 1];
        i3 = ar[i*4 + 2];
        i4 = ar[i*4 + 3];
        if (check_Pauli(i1,i2,i3,i4) == 1 && conserve_mz(i1,i2,i3,i4, &MZ) == 1 && conserve_isospin(i1,i2,i3,i4, &MT) == 1){
            coeff = coefficient_np(i1,i2,i3,i4,&MZ,&MTOT, &J_or, &interaction, total_space);
            if (coeff != 0.0 && counter < capacity) {
                (*coeffs)[counter] = coeff;
                (*indices)[4*counter] = i1;
                (*indices)[4*counter + 1] = i2;
                (*indices)[4*counter + 2] = i3;
                (*indices)[4*counter + 3] = i4;
                counter++;
                //fprintf(output_file, "%f %d %d %d %d\n", coeff, i1, i2, i3, i4);
            } else if (coeff != 0.0) {
                capacity *= 2;
                *coeffs = realloc(*coeffs, sizeof(double) * capacity);
                *indices = realloc(*indices, sizeof(int) * capacity * 4);
                (*coeffs)[counter] = coeff;
                (*indices)[4*counter] = i1;
                (*indices)[4*counter + 1] = i2;
                (*indices)[4*counter + 2] = i3;
                (*indices)[4*counter + 3] = i4;
                counter++;
            }
        }
    }
    
    *coeffs = realloc(*coeffs, sizeof(double) * counter);
    *indices = realloc(*indices, sizeof(int) * counter * 4);

    *n_one_bodies = counter;

    free(MZ);
    free(MTOT);
    free(MT);
    free(J_or);
    free(interaction.data);
    free(ar);
}

abcdTJV read_data_from_ar(int * ind_coupled, double * val_coupled, int n_terms, int size, int ** array_M){

    int size_int = n_terms;


    abcdTJV V_int;

    V_int.d1 = size + 1;
    V_int.d2 = size + 1;
    V_int.d3 = size + 1;
    V_int.d4 = size + 1;
    V_int.d5 = 2*size + 1;
    V_int.d6 = 2 +1;

    V_int.data = calloc(V_int.d1 * V_int.d2 * V_int.d3 * V_int.d4 * V_int.d5 * V_int.d6, sizeof(double));

    for(int i = 0; i<size_int; i++){

        int a = ind_coupled[i*6];
        int b = ind_coupled[i*6+1];
        int c = ind_coupled[i*6+2];
        int d = ind_coupled[i*6+3];
        int J = ind_coupled[i*6+4];
        int T = ind_coupled[i*6+5];

        double strength = val_coupled[i];

        if(a == b && (J+T)%2!=0 ){
            strength *= 2/sqrt(1-pow((-1),(J+T)));
        }
        if( d == c && (J+T)%2!=0){
            strength *= 2/sqrt(1-pow((-1),(J+T)));
        }

        if (strength != 0.0){
            double ja = (*array_M)[a-1] - 1;
            double jb = (*array_M)[b-1] - 1;
            double jc = (*array_M)[c-1] - 1;
            double jd = (*array_M)[d-1] - 1;

            V_int.data[idx6(&V_int, a, b, c, d, J, T)] = strength;
            V_int.data[idx6(&V_int, c, d, a, b, J, T)] = strength;

            double phase_AB = pow((-1),(ja/2.0+jb/2.0+J+T));

            V_int.data[idx6(&V_int, b, a, c, d, J, T)] = strength*phase_AB;
            V_int.data[idx6(&V_int, c, d, b, a, J, T)] = strength*phase_AB;

            double phase_CD = pow((-1),(jc/2.0+jd/2.0+J+T));

            V_int.data[idx6(&V_int, a, b, d, c, J, T)] = strength*phase_CD;
            V_int.data[idx6(&V_int, d, c, a, b, J, T)] = strength*phase_CD;

            V_int.data[idx6(&V_int, b, a, d, c, J, T)] = strength*phase_AB*phase_CD;
            V_int.data[idx6(&V_int, d, c, b, a, J, T)] = strength*phase_AB*phase_CD;
            
        }
    }

    //double x = V_int.data[idx6(&V_int, 2, 2, 2, 2, 3, 0)];
    //printf("%f\n", x);

    return V_int;
}

abcdJV read_data_from_ar_np(int * ind_coupled, double * val_coupled, int n_terms, int size, int ** array_M){

    int size_int = n_terms;


    abcdJV V_int;

    V_int.d1 = 2*size + 1;
    V_int.d2 = 2*size + 1;
    V_int.d3 = 2*size + 1;
    V_int.d4 = 2*size + 1;
    V_int.d5 = 2*size + 1;

    V_int.data = calloc(V_int.d1 * V_int.d2 * V_int.d3 * V_int.d4 * V_int.d5, sizeof(double));

    for(int i = 0; i<size_int; i++){

        int a = ind_coupled[i*6];
        int b = ind_coupled[i*6+1];
        int c = ind_coupled[i*6+2];
        int d = ind_coupled[i*6+3];
        int J = ind_coupled[i*6+4];
        int T = ind_coupled[i*6+5];

        double strength = val_coupled[i];

        renorm_and_permute_interaction_np(V_int, a, b, c, d, J, strength, array_M, size);
        
    }

    //double x = V_int.data[idx6(&V_int, 2, 2, 2, 2, 3, 0)];
    //printf("%f\n", x);

    return V_int;
}

void decouple_to_arrays_from_arrays(int ** array_M, int space_size, int total_space,
             int * ind_coupled, double * values_coupled, int n_terms, 
             double ** coeffs, int ** indices, int * n_one_bodies, int * mapping){

    int *MZ_temp, *MTOT_temp, *MT_temp, *J_or_temp;
    //printf("The total space %d\n", total_space);

    define_M_space(total_space, space_size, *array_M, &MZ_temp, &MTOT_temp, &MT_temp, &J_or_temp);
    int counter = total_space*2;

    int *MZ, *MTOT, *MT, *J_or;
    MZ = (int*)malloc(total_space*2 * sizeof(int));
    MT = (int*)malloc(total_space*2 * sizeof(int));
    MTOT = (int*)malloc(total_space*2 * sizeof(int));
    J_or = (int*)malloc(total_space*2 * sizeof(int));

    // for (int i = 0; i< total_space*2; i++){
    //     printf("The mapping index %d %d\n", i, mapping[i]);
    // }

    for (int i = 0; i < total_space*2; i++){
        MZ[i] = MZ_temp[mapping[i]];
        MT[i] = MT_temp[mapping[i]];
        MTOT[i] = MTOT_temp[mapping[i]];
        J_or[i] = J_or_temp[mapping[i]];
    }

    free(MZ_temp);
    free(MTOT_temp);
    free(MT_temp);
    free(J_or_temp);

    abcdTJV interaction = read_data_from_ar(ind_coupled, values_coupled,n_terms,space_size, array_M);
    long total_size;
    int * ar = get_product_range_4(total_space*2, &total_size);
    double coeff;
    int i1, i2, i3, i4;

    int capacity = 16384;
    (*coeffs) = (double*)malloc(sizeof(double)*capacity);
    (*indices) = (int *)malloc(sizeof(int)*capacity*4);
    counter = 0;

    for (int i = 0; i < total_size/4; i++){
        i1 = ar[i*4 + 0];
        i2 = ar[i*4 + 1];
        i3 = ar[i*4 + 2];
        i4 = ar[i*4 + 3];
        if (check_Pauli(i1,i2,i3,i4) == 1 && conserve_mz(i1,i2,i3,i4, &MZ) == 1 && conserve_isospin(i1,i2,i3,i4, &MT) == 1){
            coeff = coefficient(i1,i2,i3,i4,&MZ,&MTOT,&MT, &J_or, &interaction);
            if (coeff != 0.0 && counter < capacity) {
                (*coeffs)[counter] = coeff;
                (*indices)[4*counter] = i1;
                (*indices)[4*counter + 1] = i2;
                (*indices)[4*counter + 2] = i3;
                (*indices)[4*counter + 3] = i4;
                counter++;
                //fprintf(output_file, "%f %d %d %d %d\n", coeff, i1, i2, i3, i4);
            } else if (coeff != 0.0) {
                capacity *= 2;
                *coeffs = realloc(*coeffs, sizeof(double) * capacity);
                *indices = realloc(*indices, sizeof(int) * capacity * 4);
                (*coeffs)[counter] = coeff;
                (*indices)[4*counter] = i1;
                (*indices)[4*counter + 1] = i2;
                (*indices)[4*counter + 2] = i3;
                (*indices)[4*counter + 3] = i4;
                counter++;
            }
        }
    }
    
    *coeffs = realloc(*coeffs, sizeof(double) * counter);
    *indices = realloc(*indices, sizeof(int) * counter * 4);

    *n_one_bodies = counter;

    free(MZ);
    free(MTOT);
    free(MT);
    free(J_or);
    free(interaction.data);
    free(ar);
}

void decouple_to_arrays_from_arrays_np(int ** array_M, int space_size, int total_space,
             int * ind_coupled, double * values_coupled, int n_terms, 
             double ** coeffs, int ** indices, int * n_one_bodies, int * mapping){

    int *MZ_temp, *MTOT_temp, *MT_temp, *J_or_temp;
    //printf("The total space %d\n", total_space);

    define_M_space_np(total_space, space_size, *array_M, &MZ_temp, &MTOT_temp, &MT_temp, &J_or_temp);
    int counter = total_space*2;

    int *MZ, *MTOT, *MT, *J_or;
    MZ = (int*)malloc(total_space*2 * sizeof(int));
    MT = (int*)malloc(total_space*2 * sizeof(int));
    MTOT = (int*)malloc(total_space*2 * sizeof(int));
    J_or = (int*)malloc(total_space*2 * sizeof(int));

    // for (int i = 0; i< total_space*2; i++){
    //     printf("The mapping index %d %d\n", i, mapping[i]);
    // }

    for (int i = 0; i < total_space*2; i++){
        MZ[i] = MZ_temp[mapping[i]];
        MT[i] = MT_temp[mapping[i]];
        MTOT[i] = MTOT_temp[mapping[i]];
        J_or[i] = J_or_temp[mapping[i]];
    }

    free(MZ_temp);
    free(MTOT_temp);
    free(MT_temp);
    free(J_or_temp);

    abcdJV interaction = read_data_from_ar_np(ind_coupled, values_coupled,n_terms,space_size, array_M);
    long total_size;
    int * ar = get_product_range_4(total_space*2, &total_size);
    double coeff;
    int i1, i2, i3, i4;

    int capacity = 16384;
    (*coeffs) = (double*)malloc(sizeof(double)*capacity);
    (*indices) = (int *)malloc(sizeof(int)*capacity*4);
    counter = 0;

    for (int i = 0; i < total_size/4; i++){
        i1 = ar[i*4 + 0];
        i2 = ar[i*4 + 1];
        i3 = ar[i*4 + 2];
        i4 = ar[i*4 + 3];
        if (check_Pauli(i1,i2,i3,i4) == 1 && conserve_mz(i1,i2,i3,i4, &MZ) == 1 && conserve_isospin(i1,i2,i3,i4, &MT) == 1){
            coeff = coefficient_np(i1,i2,i3,i4,&MZ,&MTOT, &J_or, &interaction, total_space);
            if (coeff != 0.0 && counter < capacity) {
                (*coeffs)[counter] = coeff;
                (*indices)[4*counter] = i1;
                (*indices)[4*counter + 1] = i2;
                (*indices)[4*counter + 2] = i3;
                (*indices)[4*counter + 3] = i4;
                counter++;
                //fprintf(output_file, "%f %d %d %d %d\n", coeff, i1, i2, i3, i4);
            } else if (coeff != 0.0) {
                capacity *= 2;
                *coeffs = realloc(*coeffs, sizeof(double) * capacity);
                *indices = realloc(*indices, sizeof(int) * capacity * 4);
                (*coeffs)[counter] = coeff;
                (*indices)[4*counter] = i1;
                (*indices)[4*counter + 1] = i2;
                (*indices)[4*counter + 2] = i3;
                (*indices)[4*counter + 3] = i4;
                counter++;
            }
        }
    }
    
    *coeffs = realloc(*coeffs, sizeof(double) * counter);
    *indices = realloc(*indices, sizeof(int) * counter * 4);

    *n_one_bodies = counter;

    free(MZ);
    free(MTOT);
    free(MT);
    free(J_or);
    free(interaction.data);
    free(ar);
}


int main(){
    int * array_m = (int*)malloc(sizeof(int)*12);
    int counter = 0;
    array_m[0] = 8;
    array_m[1] = 4;
    array_m[2] = 6;
    array_m[3] = 2;
    //run_task(&array_m, 4, 20, "../data/kb3g.int","test.out");
    //return 0 ;

    //int * array_m = (int*)malloc(sizeof(int)*12);
    //int counter = 0;

    array_m[0] = 4;
    array_m[1] = 6;
    array_m[2] = 2;
    run_task(&array_m, 3, 12, "../data/usdb_canonical.int","test.out");
    array_m[0] = 4;
    array_m[1] = 6;
    array_m[2] = 2;
    array_m[3] = 4;
    array_m[4] = 6;
    array_m[5] = 2;
    run_task_np(&array_m, 3, 12, "../data/usdb_np_mine.int","test2.out");
    double *coeffs;
    int *indices;
    int n_one_bodies;
    int mapping[24] = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23};  
    decouple_to_arrays_np(&array_m, 3, 12,
              "../data/usdb_np_mine.int",
             &coeffs, &indices, &n_one_bodies, mapping);
            
    for (int i = 0; i < 10; i++){
        printf("coeff %f %d %d %d %d \n", coeffs[i], indices[4*i], indices[4*i+1],indices[4*i+2], indices[4*i+3]);
    }

    return 0 ;

    array_m[0] = 6;
    array_m[1] = 2;
    array_m[2] = 4;
    // double *coeffs;
    // int *indices;
    // int n_one_bodies;
    // //int mapping[24] = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23};
    // int mapping[24] = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23};

    decouple_to_arrays(&array_m, 3, 12,
              "../data/usdb.int",
             &coeffs, &indices, &n_one_bodies, mapping);
            
    for (int i = 0; i < 10; i++){
        printf("coeff %f %d %d %d %d \n", coeffs[i], indices[4*i], indices[4*i+1],indices[4*i+2], indices[4*i+3]);
    }

    free(array_m);

}