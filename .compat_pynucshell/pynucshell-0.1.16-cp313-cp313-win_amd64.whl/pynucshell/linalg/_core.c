#include <stdio.h>
#include <stdlib.h>
#include "_core.h"
#include <omp.h>

void free_basis(_Basis basis) {
    if (basis.fptr != NULL) {
        fclose(basis.fptr);
        basis.fptr = NULL;
    }
    // Free proton slaters
    for (int i = 0; i < basis.p_slaters.n_sectors; i++) {
        free(basis.p_slaters.sectors[i].states);
        free(basis.p_slaters.sectors[i].sl_ind);
        free(basis.p_slaters.sectors[i].two_body);
    }
    free(basis.p_slaters.sectors);
    free(basis.p_slaters.m_values);
    
    // Free neutron slaters
    for (int i = 0; i < basis.n_slaters.n_sectors; i++) {
        free(basis.n_slaters.sectors[i].states);
        free(basis.n_slaters.sectors[i].sl_ind);
        free(basis.n_slaters.sectors[i].two_body);
    }
    free(basis.n_slaters.sectors);
    free(basis.n_slaters.m_values);
}

// Returns mask for parity of a_i† a_j† a_l a_k as if ordered: i < j, k < l. Sites with 1 indicate phase shift if occupied
static inline uint64_t get_dual_mask(int i, int j, int k, int l) {

    int d[4] = {i,j,k,l};
    // Order in increasing size d[0]<=d[1]<=d[2]<=d[3]
    SWAP(d[0], d[1]);
    SWAP(d[2], d[3]);
    SWAP(d[0], d[2]);
    SWAP(d[1], d[3]);
    SWAP(d[1], d[2]);

    uint64_t m1 = (d[1] > d[0] + 1) ? (((1ULL << d[1]) - 1) & ~((1ULL << (d[0] + 1)) - 1)) : 0;
    uint64_t m2 = (d[3] > d[2] + 1) ? (((1ULL << d[3]) - 1) & ~((1ULL << (d[2] + 1)) - 1)) : 0;

    return m1 | m2;
}

// Apply a_i† ai
int eval_f2_n(int i, uint64_t in, uint64_t *out){
    int occupied = in & (1ULL << i) ? 1 : 0 ; // 1 is occupied, 0 is not
    //printf("Is it occupied = %d \n",occupied);
    if (!occupied) return 0; 

    *out = in;

    return 1;

}

// Apply a_i† a_j
int eval_f2(int i, int j, uint64_t in, uint64_t * out, int *parity){
    int phase = 1;
    int occupied = in & (1ULL << i) ? 0 : 1 ; // 1 is not occupied, 0 is 
    //printf("Is it occupied = %d \n",occupied);
    if (!occupied) return 0;
    occupied = in & (1ULL << j) ? 1 : 0;      // 1 is occupied, 0 is not
    if (!occupied) return 0;
    
    uint64_t flipped = in ^ ((1ULL << i) | (1ULL << j));
    *out = flipped;
    //printf("Is occupied %d \n",occupied); // Both have to be one, to apply the operatorSlater

    uint64_t mask = 0;
    int init;
    int end;
    if (i < j) {
        init = i;
        end = j;
    }
    else {
        init = j;
        end = i;
    }
    for (int k = init+1; k < end; k++){
        mask |= (1ULL<<k);
    }
    mask &= in;

    int count = __builtin_popcountll(mask);
    //printf("Number of bits set up to 1 in mask: %d\n", count);
    *parity = ( (count & 1) ? -1 : 1) * phase; //pow(-1.0,count)*phase;
    //printf("The parity of the term is %d\n", *parity);
    return 1;
}

// Apply `a_i† a_j† a_k a_l`. Direct, no swapping of k,l indices. Good ordering when `i < j`, `k > l`
int eval_f4(int i, int j, int k, int l, uint64_t in, uint64_t * out, int *parity){

    int ordering = 1;

    if (i>j) ordering*=-1;
    if (k<l) ordering*=-1;

    uint64_t mask_unocc = (1ULL << i) | (1ULL << j);
    uint64_t mask_occ = (1ULL << k) | (1ULL << l);
    uint64_t a = mask_occ & in;
    uint64_t flipped_in = in ^ (1ULL << k) ^ (1ULL << l);
    uint64_t b = mask_unocc & flipped_in;

    if (a == mask_occ && b == 0ULL ) {
        *out = in ^ (1ULL << i) ^ (1ULL << j) ^ (1ULL << k) ^ (1ULL << l);
    } else {
        return 0;
    }

    uint64_t mask_parity;
    mask_parity = get_dual_mask(i,j,k,l); //((1ULL << i ) - 1) ^ ( (1ULL << j ) - 1) ^ ((1ULL << k ) - 1) ^ ( (1ULL << l ) - 1);
    //print_binary12(mask_parity);
    uint64_t par = mask_parity & in;
    int count = __builtin_popcountll(par);
    *parity = ( (count & 1) ? -1 : 1) * ordering;//pow(-1.0,count)*ordering;
    return 1;
}

// 
SectorJump * compute_jumps_ident(Slaters * slaters_iso, int * del_m){
    SectorJump * sectorjumps;
    int n_sectors = slaters_iso->n_sectors;
    int delta_m = 0;
    *del_m = delta_m;
    //printf("This jump has delta_m %d\n", delta_m); 
    sectorjumps = (SectorJump *)malloc(sizeof(SectorJump)*n_sectors);
    for(int n = 0; n<n_sectors; n++){
        // Here I can avoid comuting some sectors, if I know the jump
        // brings it out of the maximum M
        int initial_sector = slaters_iso->sectors[n].sector_value;
        int final_sector = initial_sector + delta_m;
        int final_sector_ind = n + slaters_iso->is_ascending*delta_m/2;
        int n_states = slaters_iso->sectors[n].n_states;
        sectorjumps[n].initial_m = initial_sector; 
        sectorjumps[n].pairs = (Pair *)malloc(sizeof(Pair)*16);
        sectorjumps[n].parities = (int *)malloc(sizeof(int)*16);
        sectorjumps[n].n_pairs = 0;
        int pair_capacity = 16;
        for(int m = 0; m< n_states; m++){
            uint64_t in = slaters_iso->sectors[n].states[m];
            uint64_t out = in;
            int parity;
            //printf("The jump is accepted \n");
            //printf("The input is ");
            //print_binary12(in);
            //printf("The outgoing is ");
            //print_binary12(out);
            //printf("I have the pair %d, %d \n", slaters_iso->sectors[n].sl_ind[m],slaters_iso->sectors[final_sector_ind].sl_ind[m] );

            if (sectorjumps[n].n_pairs == pair_capacity) {
                sectorjumps[n].pairs = (Pair *)realloc(sectorjumps[n].pairs, sizeof(Pair) * (sectorjumps[n].n_pairs * 2));
                sectorjumps[n].parities = (int *)realloc(sectorjumps[n].parities, sizeof(int) * (sectorjumps[n].n_pairs * 2));
                pair_capacity *= 2;
            }
            // sectorjumps[n].pairs[sectorjumps[n].n_pairs].in = slaters_iso->sectors[n].sl_ind[m];
            // sectorjumps[n].pairs[sectorjumps[n].n_pairs].out = slaters_iso->sectors[final_sector_ind].sl_ind[m];
            sectorjumps[n].pairs[sectorjumps[n].n_pairs].in_two = slaters_iso->sectors[n].two_body[m];
            sectorjumps[n].pairs[sectorjumps[n].n_pairs].out_two = slaters_iso->sectors[final_sector_ind].two_body[m];
            sectorjumps[n].parities[sectorjumps[n].n_pairs] = 1;
            sectorjumps[n].n_pairs++;

        }
        sectorjumps[n].pairs = (Pair *)realloc(sectorjumps[n].pairs, sizeof(Pair)*(sectorjumps[n].n_pairs));
        sectorjumps[n].parities = (int *)realloc(sectorjumps[n].parities, sizeof(int)*(sectorjumps[n].n_pairs));
    }

    return sectorjumps;
}

OperatorSlater compute_op_ident(Slaters* slaters_iso){
    OperatorSlater op;
    int delta_m;
    op.jumps = compute_jumps_ident(slaters_iso, &delta_m);
    op.delta_m = delta_m;
    op.n_sectors = slaters_iso->n_sectors;
    return op;
}

SectorJump * compute_jumps_n(int i, Slaters * slaters_iso, int * del_m){
    SectorJump * sectorjumps;
    int n_sectors = slaters_iso->n_sectors;
    int delta_m = 0;
    *del_m = delta_m;
    //printf("This jump has delta_m %d\n", delta_m); 
    sectorjumps = (SectorJump *)malloc(sizeof(SectorJump)*n_sectors);
    for(int n = 0; n<n_sectors; n++){
        // Here I can avoid comuting some sectors, if I know the jump
        // brings it out of the maximum M
        int initial_sector = slaters_iso->sectors[n].sector_value;
        int final_sector = initial_sector + delta_m;
        int final_sector_ind = n + slaters_iso->is_ascending*delta_m/2;
        int n_states = slaters_iso->sectors[n].n_states;
        sectorjumps[n].initial_m = initial_sector; 
        sectorjumps[n].pairs = (Pair *)malloc(sizeof(Pair)*16);
        sectorjumps[n].parities = (int *)malloc(sizeof(int)*16);
        int pair_capacity = 16;
        sectorjumps[n].n_pairs = 0;
        for(int m = 0; m< n_states; m++){
            uint64_t in = slaters_iso->sectors[n].states[m];
            uint64_t out ;
            int parity;
            int res = eval_f2_n(i, in, &out);
            if (res) {
                //printf("The jump is accepted \n");
                //printf("The input is ");
                //print_binary12(in);
                //printf("The outgoing is ");
                //print_binary12(out);
                //printf("I have the pair %d, %d \n", slaters_iso->sectors[n].sl_ind[m],slaters_iso->sectors[final_sector_ind].sl_ind[m] );
                if (sectorjumps[n].n_pairs == pair_capacity) {
                    sectorjumps[n].pairs = (Pair *)realloc(sectorjumps[n].pairs, sizeof(Pair) * (sectorjumps[n].n_pairs * 2));
                    sectorjumps[n].parities = (int *)realloc(sectorjumps[n].parities, sizeof(int) * (sectorjumps[n].n_pairs * 2));
                    pair_capacity *= 2;
                }
                // sectorjumps[n].pairs[sectorjumps[n].n_pairs].in = slaters_iso->sectors[n].sl_ind[m];
                // sectorjumps[n].pairs[sectorjumps[n].n_pairs].out = slaters_iso->sectors[final_sector_ind].sl_ind[m];
                sectorjumps[n].pairs[sectorjumps[n].n_pairs].in_two = slaters_iso->sectors[n].two_body[m];
                sectorjumps[n].pairs[sectorjumps[n].n_pairs].out_two = slaters_iso->sectors[final_sector_ind].two_body[m];
                sectorjumps[n].parities[sectorjumps[n].n_pairs] = 1;
                sectorjumps[n].n_pairs++;


            } else {
                //printf("The jump is denied \n");
                //printf("The input is ");
                //print_binary12(in);
                //printf("The outgoing is ");
                //print_binary12(out);
                continue;
            }

        }
        sectorjumps[n].pairs = (Pair *)realloc(sectorjumps[n].pairs, sizeof(Pair)*(sectorjumps[n].n_pairs));
        sectorjumps[n].parities = (int *)realloc(sectorjumps[n].parities, sizeof(int)*(sectorjumps[n].n_pairs));
    }

    return sectorjumps;
}

OperatorSlater compute_op_n(int i, Slaters* slaters_iso){
    OperatorSlater op;
    int delta_m;
    op.jumps = compute_jumps_n(i, slaters_iso, &delta_m);
    op.delta_m = delta_m;
    op.n_sectors = slaters_iso->n_sectors;
    return op;
}

SectorJump * compute_jumps4(int i, int j,int k, int l, Slaters * slaters_iso, int * del_m){
    SectorJump * sectorjumps;
    int n_sectors = slaters_iso->n_sectors;
    int delta_m = slaters_iso->m_values[i] + slaters_iso->m_values[j] - (slaters_iso->m_values[k] + slaters_iso->m_values[l]);
    *del_m = delta_m;
    //printf("This jump has delta_m %d\n", delta_m); 
    sectorjumps = (SectorJump *)malloc(sizeof(SectorJump)*n_sectors);
    for(int n = 0; n<n_sectors; n++){
        // Here I can avoid comuting some sectors, if I know the jump
        // brings it out of the maximum M
        int initial_sector = slaters_iso->sectors[n].sector_value;
        int final_sector = initial_sector + delta_m;
        int final_sector_ind = n + slaters_iso->is_ascending*delta_m/2;
        int n_states = slaters_iso->sectors[n].n_states;
        sectorjumps[n].initial_m = initial_sector; 
        sectorjumps[n].pairs = (Pair *)malloc(sizeof(Pair)*16);
        sectorjumps[n].parities = (int *)malloc(sizeof(int)*16);
        sectorjumps[n].n_pairs= 0; // (int *)malloc(sizeof(int)*16);
        int pair_capacity = 16;
        for(int m = 0; m< n_states; m++){
            uint64_t in = slaters_iso->sectors[n].states[m];
            uint64_t out ;
            int parity;
            int res = eval_f4(i,j,k,l, in, &out, &parity);
            if (res) {
                //printf("The jump is accepted \n");
                //printf("The input is ");
                //print_binary12(in);
                //printf("The outgoing is ");
                //print_binary12(out);
                //printf("The phase is %d \n\n", parity);
                for (int k = 0; k<slaters_iso->sectors[final_sector_ind].n_states; k++){
                    if (out == slaters_iso->sectors[final_sector_ind].states[k]){
                        //printf("I have the pair %d, %d \n", slaters_iso->sectors[n].sl_ind[m],slaters_iso->sectors[final_sector_ind].sl_ind[k] );
                        if (sectorjumps[n].n_pairs == pair_capacity) {
                            sectorjumps[n].pairs = (Pair *)realloc(sectorjumps[n].pairs, sizeof(Pair) * (sectorjumps[n].n_pairs * 2));
                            sectorjumps[n].parities = (int *)realloc(sectorjumps[n].parities, sizeof(int) * (sectorjumps[n].n_pairs * 2));
                            pair_capacity *= 2;
                        }
                        // sectorjumps[n].pairs[sectorjumps[n].n_pairs].in = slaters_iso->sectors[n].sl_ind[m];
                        // sectorjumps[n].pairs[sectorjumps[n].n_pairs].out = slaters_iso->sectors[final_sector_ind].sl_ind[k];
                        sectorjumps[n].pairs[sectorjumps[n].n_pairs].in_two = slaters_iso->sectors[n].two_body[m];
                        sectorjumps[n].pairs[sectorjumps[n].n_pairs].out_two = slaters_iso->sectors[final_sector_ind].two_body[k];
                        sectorjumps[n].parities[sectorjumps[n].n_pairs] = parity;
                        sectorjumps[n].n_pairs++;

                    }
                }
            } else {
                //printf("The jump is denied \n");
                //printf("The input is ");
                //print_binary12(in);
                //printf("The outgoing is ");
                //print_binary12(out);
                //printf("The phase is %d\n\n", parity);
                continue;
            }

        }
        sectorjumps[n].pairs = (Pair *)realloc(sectorjumps[n].pairs, sizeof(Pair)*(sectorjumps[n].n_pairs));
        sectorjumps[n].parities = (int *)realloc(sectorjumps[n].parities, sizeof(int)*(sectorjumps[n].n_pairs));
    }

    return sectorjumps;
}

OperatorSlater compute_op4(int i, int j,int k,int l, Slaters* slaters_iso){
    OperatorSlater op;
    int delta_m;
    op.jumps = compute_jumps4(i,j,k,l, slaters_iso, &delta_m);
    op.delta_m = delta_m;
    op.n_sectors = slaters_iso->n_sectors;
    return op;
}

SectorJump * compute_jumps(int i, int j, Slaters * slaters_iso, int * del_m){
    SectorJump * sectorjumps;
    int n_sectors = slaters_iso->n_sectors;
    int delta_m = slaters_iso->m_values[i] - slaters_iso->m_values[j];
    *del_m = delta_m;
    //printf("This jump has delta_m %d\n", delta_m); 
    sectorjumps = (SectorJump *)malloc(sizeof(SectorJump)*n_sectors);
    for(int n = 0; n<n_sectors; n++){
        // Here I can avoid comuting some sectors, if I know the jump
        // brings it out of the maximum M
        int initial_sector = slaters_iso->sectors[n].sector_value;
        int final_sector = initial_sector + delta_m;
        int final_sector_ind = n + slaters_iso->is_ascending*delta_m/2;
        int n_states = slaters_iso->sectors[n].n_states;
        sectorjumps[n].initial_m = initial_sector; 
        sectorjumps[n].pairs = (Pair *)malloc(sizeof(Pair)*16);
        sectorjumps[n].parities = (int *)malloc(sizeof(int)*16);
        sectorjumps[n].n_pairs = 0;  // ✓ Add this line

        int pair_capacity = 16;
        if (final_sector_ind > n_sectors - 1 || final_sector_ind < 0) continue;
        for(int m = 0; m< n_states; m++){
            uint64_t in = slaters_iso->sectors[n].states[m];
            uint64_t out ;
            int parity;
            int res = eval_f2(i,j, in, &out, &parity);
            if (res) {
                //printf("The jump is accepted \n");
                //printf("The input is ");
                //print_binary12(in);
                //printf("The outgoing is ");
                //print_binary12(out);
                //printf("The phase is %d \n\n", parity);
                for (int k = 0; k<slaters_iso->sectors[final_sector_ind].n_states; k++){
                    if (out == slaters_iso->sectors[final_sector_ind].states[k]){
                        //printf("I have the pair %d, %d \n", slaters_iso->sectors[n].sl_ind[m],slaters_iso->sectors[final_sector_ind].sl_ind[k] );
                        if (sectorjumps[n].n_pairs == pair_capacity) {
                            sectorjumps[n].pairs = (Pair *)realloc(sectorjumps[n].pairs, sizeof(Pair) * (sectorjumps[n].n_pairs * 2));
                            sectorjumps[n].parities = (int *)realloc(sectorjumps[n].parities, sizeof(int) * (sectorjumps[n].n_pairs * 2));
                            pair_capacity *= 2;
                        }
                        // sectorjumps[n].pairs[sectorjumps[n].n_pairs].in = slaters_iso->sectors[n].sl_ind[m];
                        // sectorjumps[n].pairs[sectorjumps[n].n_pairs].out = slaters_iso->sectors[final_sector_ind].sl_ind[k];
                        sectorjumps[n].pairs[sectorjumps[n].n_pairs].in_two = slaters_iso->sectors[n].two_body[m];
                        sectorjumps[n].pairs[sectorjumps[n].n_pairs].out_two = slaters_iso->sectors[final_sector_ind].two_body[k];
                        sectorjumps[n].parities[sectorjumps[n].n_pairs] = parity;
                        sectorjumps[n].n_pairs++;

                    }
                }
            } else {
                //printf("The jump is denied \n");
                //printf("The input is ");
                //print_binary12(in);
                //printf("The outgoing is ");
                //print_binary12(out);
                //printf("The phase is %d\n\n", parity);
                continue;
            }

        }
        sectorjumps[n].pairs = (Pair *)realloc(sectorjumps[n].pairs, sizeof(Pair)*(sectorjumps[n].n_pairs));
        sectorjumps[n].parities = (int *)realloc(sectorjumps[n].parities, sizeof(int)*(sectorjumps[n].n_pairs));
    }

    return sectorjumps;
}

OperatorSlater compute_op(int i, int j, Slaters* slaters_iso){
    OperatorSlater op;
    int delta_m;
    op.jumps = compute_jumps(i,j, slaters_iso, &delta_m);
    op.delta_m = delta_m;
    op.n_sectors = slaters_iso->n_sectors;
    return op;
}

void compute_full_op2(int i, int j, _Basis basis, OperatorSlater * op_p, OperatorSlater * op_n, int * ord_parity){
    // PARA one body
    int is_np;
    int half_space = basis.n_slaters.number_m_values/2;
    int order_parity = 1;
    if (i < half_space && j < half_space) {
        /* 
            If it is not n-p compute all pairs, and loop over n 
        */
        is_np = 0;
        if (i == j){
            *op_p = compute_op_n(i, &basis.p_slaters);
            *op_n = compute_op_ident(&basis.n_slaters);
        } else {
            *op_p = compute_op(i,j, &basis.p_slaters);
            *op_n = compute_op_ident(&basis.n_slaters);
        }
    } else {
        if (i == j){
            *op_p = compute_op_ident( &basis.p_slaters);
            *op_n = compute_op_n(i,&basis.n_slaters);
        } else {
            *op_p = compute_op_ident(&basis.p_slaters);
            *op_n = compute_op(i,j, &basis.n_slaters);
        }
    } 
    *ord_parity = order_parity;
}

void compute_full_op(int i, int j, int k, int l, _Basis basis, OperatorSlater * op_p, OperatorSlater * op_n, int *ord_parity){
    // Calcula los operadores op_p op_n
    int is_np;
    int half_space = basis.n_slaters.number_m_values/2;
    int order_parity = 1;
    if (i < half_space && j < half_space && k < half_space && l < half_space) {
        /* 
            If it is not n-p compute all pairs, and loop over n 
        */
        is_np = 0;
        *op_p = compute_op4(i,j,k,l, &basis.p_slaters);
        *op_n = compute_op_ident(&basis.n_slaters);
    } else if (i > half_space - 1 && j > half_space - 1 && k > half_space - 1 && l > half_space - 1)
    {
        is_np = 0;
        *op_n = compute_op4(i,j,k,l, &basis.n_slaters);
        *op_p = compute_op_ident(&basis.p_slaters);
    } else {
        is_np = 1;
        
        //printf("is_np %d \n", is_np);

        int proton_i;
        int proton_j;
        int neutron_i;
        int neutron_j;

        order_parity = -1;

        /* 
            Check if there are densities here, if so, create the Pairs directly
            and avoid the compute_op. The rest should follow.
        */

        /*if (i < half_space) { 
            proton_i = i;
            neutron_i = j;
            order_parity*=-1;
        } else {
            proton_i = j;
            neutron_i = i;      
        }

        if (k < half_space) {
            proton_j = k;
            neutron_j = l;
            order_parity*=-1;
        } else {
            proton_j = l;
            neutron_j = k;      
        }*/
        proton_i = i;
        neutron_i = j;
        proton_j = k;
        neutron_j = l;

        if (proton_i == proton_j) {
            *op_p = compute_op_n(proton_i, &basis.p_slaters);
        } else {
            *op_p = compute_op(proton_i, proton_j, &basis.p_slaters);
        }

        if (neutron_i == neutron_j) {
            *op_n = compute_op_n(neutron_i, &basis.n_slaters);
        } else {
            *op_n = compute_op(neutron_i, neutron_j, &basis.n_slaters);
        }
    }
    *ord_parity = order_parity;
}

void free_opsum(OperatorSum op_sum){
    int total = op_sum.n_terms;

    // for (int i =0 ; i<total; i++){
    //     // Free memory for Operator jumps
    //     for (int n = 0; n < op_sum.ops[i].op_p.n_sectors; n++) {
    //         free(op_sum.ops[i].op_p.jumps[n].pairs);
    //         free(op_sum.ops[i].op_p.jumps[n].parities);
    //     }

    //     for (int m = 0; m < op_sum.ops[i].op_n.n_sectors; m++) {
    //         free(op_sum.ops[i].op_n.jumps[m].pairs);
    //         free(op_sum.ops[i].op_n.jumps[m].parities);
    //     }
    //     free(op_sum.ops[i].op_p.jumps);
    //     free(op_sum.ops[i].op_n.jumps);

    // }
    free(op_sum.ops);
}

void free_op_sl(OperatorSlater *op_sl) {
    if (op_sl == NULL) return;

    if (op_sl->jumps != NULL) {
        for (int n = 0; n < op_sl->n_sectors; n++) {
            free(op_sl->jumps[n].pairs);
            free(op_sl->jumps[n].parities);
        }
        free(op_sl->jumps);
        op_sl->jumps = NULL;
    }
}

void multiply_state2(OperatorSum *opsum, int size_state, double * state_in, double * state_out){
    //printf("HOLA");
    memset(state_out, 0, size_state * sizeof(double));

    int n_terms = (*opsum).n_terms;
    //printf("Multiplication has started with %d terms", n_terms );
    // 1. Create a private output buffer for each thread
    // This avoids all atomic contention
    
    for(int i = 0; i < n_terms; i++) {
        // Hoist term-level constants
        const _C_operator *op = &opsum->ops[i];
        const double term_coeff = op->order_parity * op->coefficient;
        const int n_sectors = op->op_p->n_sectors;
        //printf("Coefficient %f", term_coeff);

        for(int n = 0; n < n_sectors; n++) {
            const SectorJump *jump_p = &op->op_p->jumps[n];
            const SectorJump *jump_n = &op->op_n->jumps[n]; // m = n
            
            const int n_pairs_p = jump_p->n_pairs;
            const int n_pairs_n = jump_n->n_pairs;
            
            for (int k = 0; k < n_pairs_p; k++) {
                const int in_p = jump_p->pairs[k].in_two;
                const int out_p = jump_p->pairs[k].out_two;
                const double p_val = jump_p->parities[k] * term_coeff;

                // This is the hot loop (Inner-most)
                for(int l = 0; l < n_pairs_n; l++) {
                    int in_idx  = in_p  + jump_n->pairs[l].in_two - 1;
                    int out_idx = out_p + jump_n->pairs[l].out_two - 1;
                    double val  = p_val * jump_n->parities[l];
                    //if (in_idx > size_state || out_idx > size_state){
                    //    printf("Overflow, %d and %d", in_idx, out_idx);
                    //}
                    //printf("In coeff %f \n", state_in[in_idx]);
                    //printf("Pair is %d, pair out %d, val %f \n", in_idx, out_idx, val);
                    // No atomic needed! Writing to private memory.
                    state_out[out_idx] += state_in[in_idx] * val;
                    //printf("Index changed %f", state_out[out_idx]);
                }
            }
        }
    }
}

void trace_op(OperatorSum *opsum, int size_state, double * trace_A){
    //printf("HOLA");

    int n_terms = (*opsum).n_terms;
    //printf("Multiplication has started with %d terms", n_terms );
    // 1. Create a private output buffer for each thread
    // This avoids all atomic contention
    double result = 0.0;
    
    for(int i = 0; i < n_terms; i++) {
        // Hoist term-level constants
        const _C_operator *op = &opsum->ops[i];
        const double term_coeff = op->order_parity * op->coefficient;
        const int n_sectors = op->op_p->n_sectors;
        //printf("Coefficient %f", term_coeff);

        for(int n = 0; n < n_sectors; n++) {
            const SectorJump *jump_p = &op->op_p->jumps[n];
            const SectorJump *jump_n = &op->op_n->jumps[n]; // m = n
            
            const int n_pairs_p = jump_p->n_pairs;
            const int n_pairs_n = jump_n->n_pairs;
            
            for (int k = 0; k < n_pairs_p; k++) {
                const int in_p = jump_p->pairs[k].in_two;
                const int out_p = jump_p->pairs[k].out_two;
                const double p_val = jump_p->parities[k] * term_coeff;

                // This is the hot loop (Inner-most)
                for(int l = 0; l < n_pairs_n; l++) {
                    int in_idx  = in_p  + jump_n->pairs[l].in_two - 1;
                    int out_idx = out_p + jump_n->pairs[l].out_two - 1;
                    double val  = p_val * jump_n->parities[l];
                    //if (in_idx > size_state || out_idx > size_state){
                    //    printf("Overflow, %d and %d", in_idx, out_idx);
                    //}
                    //printf("In coeff %f \n", state_in[in_idx]);
                    //printf("Pair is %d, pair out %d, val %f \n", in_idx, out_idx, val);
                    // No atomic needed! Writing to private memory.
                    if (in_idx == out_idx) {
                        result += val;
                    }
                    //printf("Index changed %f", state_out[out_idx]);
                }
            }
        }
    }
    *trace_A = result;
}


void complex_multiply_state2(OperatorSum *opsum, int size_state, complex128_t * state_in, complex128_t * state_out){
    //printf("HOLA");
    memset(state_out, 0, size_state * sizeof(complex128_t));

    int n_terms = (*opsum).n_terms;
    //printf("Multiplication has started with %d terms", n_terms );
    // 1. Create a private output buffer for each thread
    // This avoids all atomic contention
    
    for(int i = 0; i < n_terms; i++) {
        // Hoist term-level constants
        const _C_operator *op = &opsum->ops[i];
        const double term_coeff = op->order_parity * op->coefficient;
        const int n_sectors = op->op_p->n_sectors;
        //printf("Coefficient %f", term_coeff);

        for(int n = 0; n < n_sectors; n++) {
            const SectorJump *jump_p = &op->op_p->jumps[n];
            const SectorJump *jump_n = &op->op_n->jumps[n]; // m = n
            
            const int n_pairs_p = jump_p->n_pairs;
            const int n_pairs_n = jump_n->n_pairs;
            
            for (int k = 0; k < n_pairs_p; k++) {
                const int in_p = jump_p->pairs[k].in_two;
                const int out_p = jump_p->pairs[k].out_two;
                const double p_val = jump_p->parities[k] * term_coeff;

                // This is the hot loop (Inner-most)
                for(int l = 0; l < n_pairs_n; l++) {
                    int in_idx  = in_p  + jump_n->pairs[l].in_two - 1;
                    int out_idx = out_p + jump_n->pairs[l].out_two - 1;
                    double val  = p_val * jump_n->parities[l];
                    //if (in_idx > size_state || out_idx > size_state){
                    //    printf("Overflow, %d and %d", in_idx, out_idx);
                    //}
                    //printf("In coeff %f \n", state_in[in_idx]);
                    //printf("Pair is %d, pair out %d, val %f \n", in_idx, out_idx, val);
                    // No atomic needed! Writing to private memory.
                    state_out[out_idx].real += state_in[in_idx].real * val;
                    state_out[out_idx].imag += state_in[in_idx].imag * val;
                    //printf("Index changed %f", state_out[out_idx]);
                }
            }
        }
    }
}

void multiply_state3(OperatorSum *opsum, int size_state, double * state_in, double * state_out){
    // Initialize output state
    memset(state_out, 0, size_state * sizeof(double));
    
    int n_terms = (*opsum).n_terms;
    #pragma omp parallel
    {
    int n_threads = omp_get_num_threads();
    int tid = omp_get_thread_num();
        
    // For each term in the operator sum
    for(int i = 0; i < n_terms; i++) {
        const _C_operator *op = &opsum->ops[i];
        const double term_coeff = op->order_parity * op->coefficient;
        const int n_sectors = op->op_p->n_sectors;

            // Each thread processes sectors assigned to it based on thread ID
            for(int sector = tid - op->op_p->delta_m/2; sector < n_sectors; sector += n_threads) {
                if (sector<0 || sector > n_sectors-1) continue;
                const SectorJump *jump_p = &op->op_p->jumps[sector];
                const SectorJump *jump_n = &op->op_n->jumps[sector];
                
                const int n_pairs_p = jump_p->n_pairs;
                const int n_pairs_n = jump_n->n_pairs;

                for (int k = 0; k < n_pairs_p; k++) {
                    const int in_p = jump_p->pairs[k].in_two;
                    const int out_p = jump_p->pairs[k].out_two;
                    const double p_val = jump_p->parities[k] * term_coeff;
                    
                    // Inner loop over neutron pairs
                    for(int l = 0; l < n_pairs_n; l++) {
                        int in_idx  = in_p  + jump_n->pairs[l].in_two - 1;
                        int out_idx = out_p + jump_n->pairs[l].out_two - 1;
                        double val  = p_val * jump_n->parities[l];

                        // Atomic needed when parallelizing over terms
                        
                        state_out[out_idx] += state_in[in_idx] * val;
                    }
                }
            }
        }
    }
}

void complex_multiply_state3(OperatorSum *opsum, int size_state, complex128_t * state_in, complex128_t * state_out){
    // Initialize output state
    memset(state_out, 0, size_state * sizeof(complex128_t));
    
    int n_terms = (*opsum).n_terms;
    #pragma omp parallel
    {
    int n_threads = omp_get_num_threads();
    int tid = omp_get_thread_num();
        
    // For each term in the operator sum
    for(int i = 0; i < n_terms; i++) {
        const _C_operator *op = &opsum->ops[i];
        const double term_coeff = op->order_parity * op->coefficient;
        const int n_sectors = op->op_p->n_sectors;

            // Each thread processes sectors assigned to it based on thread ID
            for(int sector = tid - op->op_p->delta_m/2; sector < n_sectors; sector += n_threads) {
                if (sector<0 || sector > n_sectors-1) continue;
                const SectorJump *jump_p = &op->op_p->jumps[sector];
                const SectorJump *jump_n = &op->op_n->jumps[sector];
                
                const int n_pairs_p = jump_p->n_pairs;
                const int n_pairs_n = jump_n->n_pairs;

                for (int k = 0; k < n_pairs_p; k++) {
                    const int in_p = jump_p->pairs[k].in_two;
                    const int out_p = jump_p->pairs[k].out_two;
                    const double p_val = jump_p->parities[k] * term_coeff;
                    
                    // Inner loop over neutron pairs
                    for(int l = 0; l < n_pairs_n; l++) {
                        int in_idx  = in_p  + jump_n->pairs[l].in_two - 1;
                        int out_idx = out_p + jump_n->pairs[l].out_two - 1;
                        double val  = p_val * jump_n->parities[l];

                        // Atomic needed when parallelizing over terms
                        
                        state_out[out_idx].real += state_in[in_idx].real * val;
                        state_out[out_idx].imag += state_in[in_idx].imag * val;
                    }
                }
            }
        }
    }
}

void op_exp_state(OperatorSum *opsum, int size_state, double * state_in, double * state_out, double theta){
    // Initialize output state
    //memset(state_out, 0, size_state * sizeof(double));
    memcpy(state_out, state_in, size_state * sizeof(double));

    int n_terms = (*opsum).n_terms;
    double sin_theta = sin(theta);
    double cos_theta = 1.0 - cos(theta);
    // 1. Create a private output buffer for each thread
    // This avoids all atomic contention
    
    for(int i = 0; i < n_terms; i++) {
        // Hoist term-level constants
        const _C_operator *op = &opsum->ops[i];
        const double term_coeff = op->order_parity * op->coefficient;
        const int n_sectors = op->op_p->n_sectors;

        for(int n = 0; n < n_sectors; n++) {
            const SectorJump *jump_p = &op->op_p->jumps[n];
            const SectorJump *jump_n = &op->op_n->jumps[n]; // m = n
            
            const int n_pairs_p = jump_p->n_pairs;
            const int n_pairs_n = jump_n->n_pairs;

            for (int k = 0; k < n_pairs_p; k++) {
                const int in_p = jump_p->pairs[k].in_two;
                const int out_p = jump_p->pairs[k].out_two;
                const double p_val = jump_p->parities[k] * term_coeff;

                // This is the hot loop (Inner-most)
                for(int l = 0; l < n_pairs_n; l++) {
                    int in_idx  = in_p  + jump_n->pairs[l].in_two - 1;
                    int out_idx = out_p + jump_n->pairs[l].out_two - 1;
                    double val  = p_val * jump_n->parities[l];

                    state_out[out_idx] += sin_theta * state_in[in_idx] * val;
                    state_out[in_idx] += -1 * cos_theta * state_in[in_idx] * val * val;
                }
            }
        }
    }
}

void inner_prod(OperatorSum *opsum, int size_state, double * state_in_left, double * state_in_right, double * inner_prod){
    // Initialize output state
    
    int n_terms = (*opsum).n_terms;
    double inner_prod_res = 0;

    // For each term in the operator sum
    for(int i = 0; i < n_terms; i++) {
        const _C_operator *op = &opsum->ops[i];
        const double term_coeff = op->order_parity * op->coefficient;
        const int n_sectors = op->op_p->n_sectors;

        for(int n = 0; n < n_sectors; n++) {
            const SectorJump *jump_p = &op->op_p->jumps[n];
            const SectorJump *jump_n = &op->op_n->jumps[n];
            
            const int n_pairs_p = jump_p->n_pairs;
            const int n_pairs_n = jump_n->n_pairs;

            for (int k = 0; k < n_pairs_p; k++) {
                const int in_p = jump_p->pairs[k].in_two;
                const int out_p = jump_p->pairs[k].out_two;
                const double p_val = jump_p->parities[k] * term_coeff;
                
                // Inner loop over neutron pairs
                for(int l = 0; l < n_pairs_n; l++) {
                    int in_idx  = in_p  + jump_n->pairs[l].in_two - 1;
                    int out_idx = out_p + jump_n->pairs[l].out_two - 1;
                    double val  = p_val * jump_n->parities[l];

                    inner_prod_res += state_in_left[out_idx] * val * state_in_right[in_idx];
                }
            }
        }
    }
    *inner_prod = inner_prod_res;
}

void multiply_state_qubit(OperatorSum *opsum, int size_state, double * state_in, double * state_out){
    //printf("Multiplying with qubit");
    memset(state_out, 0, size_state * sizeof(double));

    int n_terms = (*opsum).n_terms;

    // 1. Create a private output buffer for each thread
    // This avoids all atomic contention
    
    for(int i = 0; i < n_terms; i++) {
        // Hoist term-level constants
        const _C_operator *op = &opsum->ops[i];
        const double term_coeff = op->coefficient;
        const int n_sectors = op->op_p->n_sectors;

        for(int n = 0; n < n_sectors; n++) {
            const SectorJump *jump_p = &op->op_p->jumps[n];
            const SectorJump *jump_n = &op->op_n->jumps[n]; // m = n
            
            const int n_pairs_p = jump_p->n_pairs;
            const int n_pairs_n = jump_n->n_pairs;

            for (int k = 0; k < n_pairs_p; k++) {
                const int in_p = jump_p->pairs[k].in_two;
                const int out_p = jump_p->pairs[k].out_two;
                const double p_val = term_coeff;

                // This is the hot loop (Inner-most)
                for(int l = 0; l < n_pairs_n; l++) {
                    int in_idx  = in_p  + jump_n->pairs[l].in_two - 1;
                    int out_idx = out_p + jump_n->pairs[l].out_two - 1;
                    double val  = p_val ;
                    //printf("In coeff %f \n", state_in[in_idx]);
                    //printf("Pair is %d, pair out %d, val %f \n", in_idx, out_idx, val);
                    // No atomic needed! Writing to private memory.
                    state_out[out_idx] += state_in[in_idx] * val;
                    //printf("Index changed %f", state_out[out_idx]);
                }
            }
        }
    }
}

void complex_multiply_state_qubit(OperatorSum *opsum, int size_state, complex128_t * state_in, complex128_t * state_out){
    //printf("Multiplying with qubit");
    memset(state_out, 0, size_state * sizeof(complex128_t));

    int n_terms = (*opsum).n_terms;

    // 1. Create a private output buffer for each thread
    // This avoids all atomic contention
    
    for(int i = 0; i < n_terms; i++) {
        // Hoist term-level constants
        const _C_operator *op = &opsum->ops[i];
        const double term_coeff = op->coefficient;
        const int n_sectors = op->op_p->n_sectors;

        for(int n = 0; n < n_sectors; n++) {
            const SectorJump *jump_p = &op->op_p->jumps[n];
            const SectorJump *jump_n = &op->op_n->jumps[n]; // m = n
            
            const int n_pairs_p = jump_p->n_pairs;
            const int n_pairs_n = jump_n->n_pairs;

            for (int k = 0; k < n_pairs_p; k++) {
                const int in_p = jump_p->pairs[k].in_two;
                const int out_p = jump_p->pairs[k].out_two;
                const double p_val = term_coeff;

                // This is the hot loop (Inner-most)
                for(int l = 0; l < n_pairs_n; l++) {
                    int in_idx  = in_p  + jump_n->pairs[l].in_two - 1;
                    int out_idx = out_p + jump_n->pairs[l].out_two - 1;
                    double val  = p_val ;
                    //printf("In coeff %f \n", state_in[in_idx]);
                    //printf("Pair is %d, pair out %d, val %f \n", in_idx, out_idx, val);
                    // No atomic needed! Writing to private memory.
                    state_out[out_idx].real += state_in[in_idx].real * val;
                    state_out[out_idx].imag += state_in[in_idx].imag * val;
                    //printf("Index changed %f", state_out[out_idx]);
                }
            }
        }
    }
}

void expand_CSR(OperatorSum * opsum,int dim, int *n_values, uint32_t ** rows, uint32_t ** columns, double ** values){
    int n_terms = (*opsum).n_terms;
    
    // Initialize dynamic array
    int capacity = 1024;  // Initial capacity
    int count = 0;

    //uint32_t * rows = (uint32_t *) malloc(sizeof(uint32_t) * capacity);
    //uint32_t * columns = (uint32_t *) malloc(sizeof(uint32_t) * capacity);
    //double * values = (double* )malloc(sizeof(double)*capacity);

    (*rows) = (uint32_t *) malloc(sizeof(uint32_t) * capacity);
    (*columns) = (uint32_t *) malloc(sizeof(uint32_t) * capacity);
    (*values) = (double* )malloc(sizeof(double)*capacity);
    
    for(int i = 0; i < n_terms; i++) {
        // Hoist term-level constants
        const _C_operator *op = &opsum->ops[i];
        const double term_coeff = op->order_parity * op->coefficient;
        const int n_sectors = op->op_p->n_sectors;

        for(int n = 0; n < n_sectors; n++) {
            const SectorJump *jump_p = &op->op_p->jumps[n];
            const SectorJump *jump_n = &op->op_n->jumps[n]; // m = n
            
            const int n_pairs_p = jump_p->n_pairs;
            const int n_pairs_n = jump_n->n_pairs;

            for (int k = 0; k < n_pairs_p; k++) {
                const int in_p = jump_p->pairs[k].in_two;
                const int out_p = jump_p->pairs[k].out_two;
                const double p_val = jump_p->parities[k] * term_coeff;

                // This is the hot loop (Inner-most)
                for(int l = 0; l < n_pairs_n; l++) {
                    int in_idx  = in_p  + jump_n->pairs[l].in_two - 1;
                    int out_idx = out_p + jump_n->pairs[l].out_two - 1;
                    double val  = p_val * jump_n->parities[l];
                    //printf("In coeff %f \n", state_in[in_idx]);
                    //printf("Pair is %d, pair out %d, val %f \n", in_idx, out_idx, val);
                    // No atomic needed! Writing to private memory.
                    //state_out[out_idx] += state_in[in_idx] * val;
                    //printf("Index changed %f", state_out[out_idx]);

                    // Check if we need to resize
                    if (count >= capacity) {
                        capacity *= 2;  // Double the capacity

                        (*rows) = (uint32_t *) realloc(*rows,sizeof(uint32_t) * capacity);
                        (*columns) = (uint32_t *) realloc(*columns,sizeof(uint32_t) * capacity);
                        (*values) = (double* )realloc(*values,sizeof(double)*capacity);
        
                    }
                    
                    // Store the matrix element
                    (*rows)[count] = in_idx;
                    (*columns)[count] = out_idx;
                    (*values)[count] = val;
                    count++;

                }
            }
        }
    }
    *n_values = count;
}

void expand_CSR_qubit(OperatorSum * opsum,int dim, int *n_values, uint32_t ** rows, uint32_t ** columns, double ** values){
    int n_terms = (*opsum).n_terms;
    
    // Initialize dynamic array
    int capacity = 1024;  // Initial capacity
    int count = 0;

    //uint32_t * rows = (uint32_t *) malloc(sizeof(uint32_t) * capacity);
    //uint32_t * columns = (uint32_t *) malloc(sizeof(uint32_t) * capacity);
    //double * values = (double* )malloc(sizeof(double)*capacity);

    (*rows) = (uint32_t *) malloc(sizeof(uint32_t) * capacity);
    (*columns) = (uint32_t *) malloc(sizeof(uint32_t) * capacity);
    (*values) = (double* )malloc(sizeof(double)*capacity);
    
    for(int i = 0; i < n_terms; i++) {
        // Hoist term-level constants
        const _C_operator *op = &opsum->ops[i];
        const double term_coeff = op->coefficient;
        const int n_sectors = op->op_p->n_sectors;

        for(int n = 0; n < n_sectors; n++) {
            const SectorJump *jump_p = &op->op_p->jumps[n];
            const SectorJump *jump_n = &op->op_n->jumps[n]; // m = n
            
            const int n_pairs_p = jump_p->n_pairs;
            const int n_pairs_n = jump_n->n_pairs;

            for (int k = 0; k < n_pairs_p; k++) {
                const int in_p = jump_p->pairs[k].in_two;
                const int out_p = jump_p->pairs[k].out_two;
                const double p_val = term_coeff;

                // This is the hot loop (Inner-most)
                for(int l = 0; l < n_pairs_n; l++) {
                    int in_idx  = in_p  + jump_n->pairs[l].in_two - 1;
                    int out_idx = out_p + jump_n->pairs[l].out_two - 1;
                    double val  = p_val;

                    // Check if we need to resize
                    if (count >= capacity) {
                        capacity *= 2;  // Double the capacity

                        (*rows) = (uint32_t *) realloc(*rows,sizeof(uint32_t) * capacity);
                        (*columns) = (uint32_t *) realloc(*columns,sizeof(uint32_t) * capacity);
                        (*values) = (double* )realloc(*values,sizeof(double)*capacity);
        
                    }
                    
                    // Store the matrix element
                    (*rows)[count] = in_idx;
                    (*columns)[count] = out_idx;
                    (*values)[count] = val;
                    count++;

                }
            }
        }
    }
    *n_values = count;
}

// Find index of uint-represented slater determinant in lexicographically ordered array
int _binary_search_c_lexicographical(uint64_t n, uint64_t *arr, uint64_t target) {
    int low = 0;
    int high = n - 1;
    int mid;
    int comparison;

    while (low <= high){
        mid = low + (high - low); // 2
        
        comparison = _compare_bitmasks_same_size(arr[mid], target);
        if (comparison == 0){ 
            return mid;
        }
        else if (comparison < 0){
            low = mid + 1; 
        }
        else{
            high = mid - 1; 
        }
    }
            
    return -1;
}

// Compare two equal 1s bitmasks lexicographically 
int _compare_bitmasks_same_size(uint64_t ma, uint64_t mb) {
    if (ma == mb) {return 0;}
    uint64_t diff;
    uint64_t first_diff;

    diff = ma ^ mb;
    first_diff = __builtin_ctzll(diff);
    
    return ma & (1 << first_diff) ? -1 : 1; // If a has the smaller digit, it is smaller ma<mb
    
}