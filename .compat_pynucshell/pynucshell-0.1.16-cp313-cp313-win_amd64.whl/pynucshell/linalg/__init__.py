"""Extension module written in C/Cython implementing the optimized low level algebraic operations
for nuclear shell model calculations."""