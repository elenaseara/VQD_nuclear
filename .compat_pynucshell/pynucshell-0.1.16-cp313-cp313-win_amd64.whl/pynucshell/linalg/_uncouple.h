#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define MAX(X, Y) (((X) > (Y)) ? (X) : (Y))

typedef struct {
    size_t d1, d2, d3, d4, d5, d6;
    double *data;
} abcdTJV;

typedef struct {
    size_t d1, d2, d3, d4, d5, d6;
    double *data;
} abcdJV;

void decouple_to_arrays(int ** array_M, int space_size, int total_space,
             const char *input2,
             double ** coeffs, int ** indices, int * n_one_bodies, int * mapping);

void decouple_to_arrays_from_arrays(int ** array_M, int space_size, int total_space,
             int * ind_coupled, double * values_coupled, int n_terms, 
             double ** coeffs, int ** indices, int * n_one_bodies, int * mapping);

void decouple_to_arrays_np(int ** array_M, int space_size, int total_space,
             const char *input2,
             double ** coeffs, int ** indices, int * n_one_bodies, int * mapping);

void decouple_to_arrays_from_arrays_np(int ** array_M, int space_size, int total_space,
             int * ind_coupled, double * values_coupled, int n_terms, 
             double ** coeffs, int ** indices, int * n_one_bodies, int * mapping);