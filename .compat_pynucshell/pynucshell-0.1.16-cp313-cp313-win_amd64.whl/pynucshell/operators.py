"""Fermionic and Qubit Operators implementations.

This module implements a dictionary-based representation for Fermionic and Qubit operators.
Each operator is represented as a dictionary mapping a tuple of terms to a coefficient.
"""

import numpy as np
import copy

from pynucshell.formatting import SUB
#from pynucshell import Simulator, Space, Operator, Basis
from numbers import Number

# from openfermion import QubitOperator, FermionOperator

class BaseOperator:
    """
    Abstract class to define the basic functionalities of operators.
    
    Parameters
    ----------
    term : tuple or str, optional
        The operator term.
    coefficient : complex or float, optional
        The coefficient of the term. Default is 1.0.
    """

    def __init__(self, term=None, coefficient=1.0):
        self.terms = {}
        if term is not None:
            self.terms[term] = coefficient

    def __add__(self, other):
        """Add two operators."""
        result = copy.deepcopy(self)
        result += other
        return result

    def __radd__(self, other):
        """Right addition."""
        return self.__add__(other)

    def __iadd__(self, other):
        """Add two operators in-place."""
        if isinstance(other, type(self)):
            for term, coeff in other.terms.items():
                self.terms[term] = self.terms.get(term, 0.0) + coeff
        else:
            self.terms[()] = self.terms.get((), 0.0) + other # scalar term
        self.compress()
        return self

    # TODO: __sub__ gets called a lot? Profile? Inplace etc.
    def __sub__(self, other):
        """Subtract two operators."""
        result = copy.deepcopy(self)
        if isinstance(other, type(self)):
            for term, coeff in other.terms.items():
                result.terms[term] = self.terms.get(term, 0.0) - coeff
        else:
            result.terms[()] = self.terms.get((), 0.0) - other # scalar term
        result.compress()
        return result
        #return self + (-1.0 * other)
    
    def __imul__(self, other):
        """In place multiplication"""
        if isinstance(other, (int, float, complex)):
            for term in self.terms:
                self.terms[term] *= other
        else:
            raise NotImplementedError("Operator multiplication is specific to subclasses.")
        self.compress()
        return self

    def __mul__(self, other):
        """Multiply by a scalar."""
        result = copy.deepcopy(self)
        result *= other
        return result

    def __rmul__(self, other):
        """Right multiplication by a scalar."""
        return self.__mul__(other)
    
    def __matmul__(self,other):
        return self.__mul__(other)

    def __rmatmul__(self, other):
        return self.__rmul__(other)
    
    def compress(self, abs_tol=1e-12):
        """
        Eliminates terms with coefficients close to zero.
        
        Parameters
        ----------
        abs_tol : float
            Tolerance for absolute value of coefficients. Terms with absolute
            value smaller than this are removed.
        """
        keys_to_remove = []
        for term, coeff in self.terms.items():
            if abs(coeff) < abs_tol:
                keys_to_remove.append(term)
        for key in keys_to_remove:
            del self.terms[key]

    def __eq__(self, other):
        """Check equality of two operators."""
        if not isinstance(other, type(self)):
            return False
        self.compress()
        other.compress()
        if len(self.terms) != len(other.terms):
            return False
        for term, coeff in self.terms.items():
            if term not in other.terms or not np.isclose(self.terms[term], coeff):
                return False
        return True

    def __repr__(self):
        """String representation of the operator."""
        if not self.terms:
            return "0"
        lines = []
        # Sort output
        for term, coeff in sorted(self.terms.items()):
            lines.append(f"{coeff} * {self._repr_term(term)}")
        return " +\n".join(lines)
    
    def __iter__(self):
        """Return an iterator over the terms's items, to ease for loops and other constructions."""
        return iter(self.terms.items())

    @staticmethod
    def _repr_term(term):
        """String representation of term"""
        return str(term)
    
    def __len__(self):
        return len(self.terms)


class FermionicOperator(BaseOperator):
    """
    Class to construct and perform algebra with Fermionic operators.
    
    Terms are represented as tuples of (index, action).
    `action` corresponds to 1 for creation (dagger) and 0 for annihilation.
    When initialized, term may also be passed as a tuple or list of n creation
    and n destruction indices
    
    Parameters
    ----------
    term : tuple[tuple[int,int]] or tuple[int, ...] or str, optional
        Example: ``((1, 1), (0, 0))`` for :math:`a_1^\\dagger a_0`.
        May also be built as a string, passed as a reference. See :py:func:`~pynucshell.operators.FermionicOperator.string_to_term`
    coefficient : complex or float, optional
        The coefficient of the term. Default is 1.0.
    """
    
    def __init__(self, term=None, coefficient=1.0):
        # check if term is not None or not empty
        if term:
            # check if it is a string
            if isinstance(term, str):
                term = self.string_to_term(term)

            # check if it is already in BaseOperator format
            elif isinstance(term[0], tuple):
                pass

            # check if it can be interpreted as excitation tuple
            elif len(term)%2 != 0:
                raise ValueError("Invalid term: A tuple or list was passed and can't be interpreted as an n-body operator (length is not even)")
            
            else:
                term = tuple((term[ind],int(ind < len(term)//2)) for ind in range(len(term)))
                
        super().__init__(term, coefficient)

    @classmethod
    def from_n_body_operator(cls, n_body_operator: dict):
        """Converts an n_body operator into a FermionicOperator.
        
        An n_body operator is a dictionary of the form {term: coeff},
        where each term is a 2 x n tuple of the n creation and n annihilation operator indices.
        Note the fermionic order is as given::
            
            (a, b, c, d) -> a^ b^ c d
        
        """
        ferm_op = cls()
        for indices, coeff in n_body_operator.items():
            fermi_term = tuple((indices[ind],int(ind < len(indices)//2)) for ind in range(len(indices)))
            ferm_op += cls(fermi_term, coeff)
        
        return ferm_op
    
    @staticmethod
    def string_to_term(fermionic_string: str):
        """Converts a string representation of a Fermionic operator into a FermionicOperator term.
        
        The string should follow a format similar to OpenFermion. That is, an operator:
        :math:`a_3^\\dagger a_1 a_2^\\dagger` would be created by the string ``"3^ 1 2^"``
        """

        term = tuple((int(s[:-1]), 1) if s[-1]=='^' 
                     else (int(s), 0) for s in fermionic_string.split())
        
        return term
        
    def __mul__(self, other):
        """
        Multiply two Fermionic operators or a generic scalar.
        This simply concatenates the tuples but does NOT perform normal ordering.
        """
        if isinstance(other, (int, float, complex)):
            return super().__mul__(other)
            
        if isinstance(other, FermionicOperator):
            result = FermionicOperator()
            for term_a, coeff_a in self.terms.items():
                for term_b, coeff_b in other.terms.items():
                    new_term = term_a + term_b
                    new_coeff = coeff_a * coeff_b
                    result.terms[new_term] = result.terms.get(new_term, 0.0) + new_coeff
            result.compress()
            return result
        raise NotImplementedError("Multiplication only supported with scalar or FermionicOperator.")

    def __matmul__(self,other):
        return self.__mul__(other)

    def __rmatmul__(self, other):
        return self.__mul__(other)

    @staticmethod
    def _repr_term(term):
        return "".join(f"a{str(index).translate(SUB)}"+ ("† " if action == 1 else " ") for index, action in term)

class QubitOperator(BaseOperator):
    """
    Class to construct and perform algebra with Qubit operators.
    
    Terms are represented as tuples of (index, pauli_string).
    pauli_string corresponds to 'X', 'Y', or 'Z'.
    
    Parameters
    ----------
    term : tuple of tuple, optional
        Example: ((0, 'X'), (1, 'Y'),) for X_0 Y_1. ((3, 'Y'),) for Y_3 (notice the comma ,) and nothing for I. 
    coefficient : complex or float, optional
        The coefficient of the term. Default is 1.0.
    """
    
    def __init__(self, term=None, coefficient=1.0):
        if type(term) is str:
            term = self.string_to_term(term)
            # IIXXIZI type term : # term = tuple((position, pauli) for position, pauli in enumerate(term) if pauli != 'I')
        super().__init__(term, coefficient)

    @staticmethod
    def string_to_term(qubit_string: str):
        """Converts a string representation of a Qubit operator into a QubitOperator term.
        
        The string should follow a format similar to OpenFermion. That is, an operator:
        :math:`X_2 Y_1 Z_6` would be created by the string ``"X2 Y1 Z6"``
        """
        if qubit_string == 'I':
            return ()
        term = tuple((int(s[1:]), s[0].upper()) for s in qubit_string.split())

        term = tuple(sorted(term, key=lambda x: x[0])) # sort by qubit number
        
        return term
    
    def __imul__(self, other):
        """
        Multiply two Qubit operators or a scalar, combining Pauli matrices.
        """
        if isinstance(other, (int, float, complex)):
            return super().__imul__(other)
            
        if isinstance(other, QubitOperator):
            for term_a, coeff_a in self.terms.items():
                for term_b, coeff_b in other.terms.items():
                    new_term, phase = self._multiply_pauli_terms(term_a, term_b)
                    new_coeff = coeff_a * coeff_b * phase
                    self.terms[new_term] = self.terms.get(new_term, 0.0) + new_coeff
            self.compress()
            return self
        raise NotImplementedError("Multiplication only supported with scalar or QubitOperator.")


    def __mul__(self, other):
        """
        Multiply two Qubit operators or a scalar, combining Pauli matrices.
        """
        if isinstance(other, (int, float, complex)):
            return super().__mul__(other)
            
        if isinstance(other, QubitOperator):
            result = QubitOperator()
            for term_a, coeff_a in self.terms.items():
                for term_b, coeff_b in other.terms.items():
                    new_term, phase = self._multiply_pauli_terms(term_a, term_b)
                    new_coeff = coeff_a * coeff_b * phase
                    result.terms[new_term] = result.terms.get(new_term, 0.0) + new_coeff
            result.compress()
            return result
        raise NotImplementedError("Multiplication only supported with scalar or QubitOperator.")

    def _multiply_pauli_terms(self, term_a, term_b):
        """
        Multiply two Pauli strings and return the resulting term and phase.
        """
        pauli_mult = {
            ('X', 'X'): ('I', 1.0), ('X', 'Y'): ('Z', 1.0j), ('X', 'Z'): ('Y', -1.0j),
            ('Y', 'X'): ('Z', -1.0j), ('Y', 'Y'): ('I', 1.0), ('Y', 'Z'): ('X', 1.0j),
            ('Z', 'X'): ('Y', 1.0j), ('Z', 'Y'): ('X', -1.0j), ('Z', 'Z'): ('I', 1.0)
        }
        
        dict_a = dict(term_a)
        dict_b = dict(term_b)
        all_indices = set(dict_a.keys()).union(set(dict_b.keys()))
        
        new_term = []
        phase = 1.0

        # To mantain ordering iterate over sorted indices.
        # Python overhead demerits exploiting both terms, as they are already sorted
        
        for idx in sorted(all_indices):
            op_a = dict_a.get(idx, 'I')
            op_b = dict_b.get(idx, 'I')
            
            if op_a == 'I':
                if op_b != 'I':
                    new_term.append((idx, op_b))
            elif op_b == 'I':
                new_term.append((idx, op_a))
            else:
                new_op, new_phase = pauli_mult[(op_a, op_b)]
                phase *= new_phase
                if new_op != 'I':
                    new_term.append((idx, new_op))
                    
        return tuple(new_term), phase
    
    @staticmethod
    def _repr_term(term):
        return "".join(f"{pauli}{str(index).translate(SUB)}" for index, pauli in term)

    def is_hermitian(self):
        return not any(coeff.imag for coeff in self.terms.values())
# # TO RUN WITH OPENFERMION
#  class FermionicOperator(FermionOperator):

#     def __init__(self, term=None, coefficient=1.0):
#         try:
#             if term and len(term) % 2 == 0 and isinstance(term[0], Number):
#                 term = tuple((int(term[ind]),int(ind < len(term)//2)) for ind in range(len(term)))
#             super().__init__(term, coefficient)
#         except Exception as e:
#             print(f"Failed for term: {term}\nterm? {term is not None}\nlen(term) % 2 == {len(term) % 2}\nisinstance(term[0], Number) = {isinstance(term[0], Number)}")
#             raise e

#     @classmethod
#     def from_n_body_operator(cls, n_body_operator: dict):
#         """Converts an n_body operator into a FermionicOperator.
        
#         An n_body operator is a dictionary of the form {term: coeff},
#         where each term is a 2 x n tuple of the n creation and n annihilation operator indices."""
#         ferm_op = cls()
#         for indices, coeff in n_body_operator.items():
#             fermi_term = tuple((int(indices[ind]),int(ind < len(indices)//2)) for ind in range(len(indices)))
#             ferm_op += cls(fermi_term, coeff)
        
#         return ferm_op

# QubitOperator.__matmul__ = QubitOperator.__mul__