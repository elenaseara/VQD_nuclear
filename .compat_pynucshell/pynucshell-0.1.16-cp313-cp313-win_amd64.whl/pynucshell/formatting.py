"""Implementation of helper methods and constants to format outputs."""

# TRANSLATION TABLES:

# Subscript translation table
SUB = str.maketrans("0123456789", "₀₁₂₃₄₅₆₇₈₉")

# Superscript translation table
SUP = str.maketrans("0123456789", "⁰¹²³⁴⁵⁶⁷⁸⁹")


# Unicode Fraction slash U+2044 / Breaks monospace
SMALL_SLASH = '⁄'