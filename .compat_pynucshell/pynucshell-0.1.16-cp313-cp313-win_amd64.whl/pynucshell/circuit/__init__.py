"""Tools for studying nuclear shell model Hamiltonians with quantum computers.

Provides an interface with quantum computing backends: qibo, qiskit, pennylane

These backends are not installed by default, they need to be added with
    pip install pynucshell[qibo] or pip install pynucshell[qiskit]"""

import pynucshell.circuit.backends

from . import encodings, solvers
from .backends import *
from .encodings import hardware_efficient, identity, jordan_wigner
from .solvers import ADAPTVQE, VQE

allowed_encodings = ["jordan_wigner", "identity", "hardware_efficient"]
