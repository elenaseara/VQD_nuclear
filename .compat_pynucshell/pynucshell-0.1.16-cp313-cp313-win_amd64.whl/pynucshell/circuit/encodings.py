"""Encoding schemes of nuclear operators to qubits, currently JWT."""

# TODO: Decide if to have self-contained version or to implement from library (e.g. openfermion)

from pynucshell.operators import FermionicOperator, QubitOperator
import numpy.fft

# TODO: Make not needing to pass Hamiltonian.get_fermionic(). Be smart!

# if isinstance(ferm_op, Hamiltonian):
#         return encoding(ferm_op)

def jordan_wigner(ferm_op: FermionicOperator) -> QubitOperator:
    r"""Jordan-Wigner encoding.
    Maps fermionic operators as:
    
    .. math::
    
        \hat{a}_p \mapsto \left(\prod^{p-1}_{k=0} Z_k \right)\frac12 (X_p+ i Y_p)
        
        \hat{a}^\dagger_p \mapsto \left(\prod^{p-1}_{k=0} Z_k \right)\frac12 (X_p- i Y_p)

    Parameters
    ----------
    ferm_op : FermionicOperator
        The fermionic operator to be encoded.

    Returns
    -------
    QubitOperator
        The encoded qubit operator.

    """
    if isinstance(ferm_op, QubitOperator):
        print("WARNING: jordan-wigner input is already a QubitOperator.")
        return ferm_op
    
    qubit_op = QubitOperator()
    pauli_mult = {
        ('X', 'X'): ('I', 1.0), ('X', 'Y'): ('Z', 1.0j), ('X', 'Z'): ('Y', -1.0j),
        ('Y', 'X'): ('Z', -1.0j), ('Y', 'Y'): ('I', 1.0), ('Y', 'Z'): ('X', 1.0j),
        ('Z', 'X'): ('Y', 1.0j), ('Z', 'Y'): ('X', -1.0j), ('Z', 'Z'): ('I', 1.0),
    }

    for term, coeff in ferm_op.terms.items():
        if not term:
            qubit_op += QubitOperator((), coeff)
            continue
            
        active_terms = [((), 1.0)] 
        for index, action in term:
            z_string = tuple((k, 'Z') for k in range(index))
            term_x = z_string + ((index, 'X'),)
            term_y = z_string + ((index, 'Y'),)
            
            coeff_y = -0.5j if action == 1 else 0.5j
            
            new_active_terms = []
            for base_pauli, base_coeff in active_terms:
                # Fast inner tuple multiplication
                for term_mapped, mapped_coeff in [(term_x, 0.5), (term_y, coeff_y)]:
                    d1, d2 = dict(base_pauli), dict(term_mapped)
                    new_term, phase = [], 1.0
                    for idx in sorted(set(d1).union(d2)):
                        p1, p2 = d1.get(idx, 'I'), d2.get(idx, 'I')
                        if p1 == 'I':
                            new_term.append((idx, p2))
                        elif p2 == 'I':
                            new_term.append((idx, p1))
                        else:
                            new_p, ph = pauli_mult[(p1, p2)]
                            phase *= ph
                            if new_p != 'I':
                                new_term.append((idx, new_p))
                    new_active_terms.append((tuple(new_term), base_coeff * mapped_coeff * phase))
            active_terms = new_active_terms
            
        for final_pauli, final_coeff in active_terms:
            qubit_op.terms[final_pauli] = qubit_op.terms.get(final_pauli, 0.0) + final_coeff * coeff
        
    qubit_op.compress()
    return qubit_op

def hardware_efficient(ferm_op: FermionicOperator) -> QubitOperator:
    r"""Hardware-efficient encoding, equivalent to Jordan-Wigner without Z phases. Ends up being equivalent to givens rotations.
    Maps fermionic operators as:
    
    .. math::
    
        \hat{a}_p \mapsto \frac12 (X_p+ i Y_p)
        
        \hat{a}^\dagger_p \mapsto \frac12 (X_p- i Y_p)

    Parameters
    ----------
    ferm_op : FermionicOperator
        The fermionic operator to be encoded.

    Returns
    -------
    QubitOperator
        The encoded qubit operator.

    """
    if isinstance(ferm_op, QubitOperator):
        print("WARNING: hardware-efficient input is already a QubitOperator.")
        return ferm_op
    
    qubit_op = QubitOperator()
    pauli_mult = {
        ('X', 'X'): ('I', 1.0), ('X', 'Y'): ('Z', 1.0j), ('X', 'Z'): ('Y', -1.0j),
        ('Y', 'X'): ('Z', -1.0j), ('Y', 'Y'): ('I', 1.0), ('Y', 'Z'): ('X', 1.0j),
        ('Z', 'X'): ('Y', 1.0j), ('Z', 'Y'): ('X', -1.0j), ('Z', 'Z'): ('I', 1.0),
    }

    for term, coeff in ferm_op.terms.items():
        if not term:
            qubit_op += QubitOperator((), coeff)
            continue
            
        active_terms = [((), 1.0)] 
        for index, action in term:
            term_x = ((index, 'X'),)
            term_y = ((index, 'Y'),)
            
            coeff_y = -0.5j if action == 1 else 0.5j
            
            new_active_terms = []
            for base_pauli, base_coeff in active_terms:
                # Fast inner tuple multiplication
                for term_mapped, mapped_coeff in [(term_x, 0.5), (term_y, coeff_y)]:
                    d1, d2 = dict(base_pauli), dict(term_mapped)
                    new_term, phase = [], 1.0
                    for idx in sorted(set(d1).union(d2)):
                        p1, p2 = d1.get(idx, 'I'), d2.get(idx, 'I')
                        if p1 == 'I':
                            new_term.append((idx, p2))
                        elif p2 == 'I':
                            new_term.append((idx, p1))
                        else:
                            new_p, ph = pauli_mult[(p1, p2)]
                            phase *= ph
                            if new_p != 'I':
                                new_term.append((idx, new_p))
                    new_active_terms.append((tuple(new_term), base_coeff * mapped_coeff * phase))
            active_terms = new_active_terms
            
        for final_pauli, final_coeff in active_terms:
            qubit_op.terms[final_pauli] = qubit_op.terms.get(final_pauli, 0.0) + final_coeff * coeff
        
    qubit_op.compress()
    return qubit_op 


def identity(qubit_op: QubitOperator) -> QubitOperator:
    """Does nothing. Useful for hamiltonians and observables which are already in Spin/Qubit representation or for ClassicalBackend."""
    return qubit_op

def parity(ferm_op: FermionicOperator) -> QubitOperator:
    r"""Parity encoding, analogous to Jordan-Wigner, but parity is stored (and thus local) instead of occupation.
    
    Maps fermionic operators as:
    
    .. math::
    
        \hat{a}_p \mapsto \frac12 (X_p Z_{p-1}+ i Y_p) \left( \prod^{n-1}_{k=p+1} Z_k \right)
        
        \hat{a}^\dagger_p \mapsto \frac12 (X_p Z_{p-1} - i Y_p) \left( \prod^{n-1}_{k=p+1} Z_k \right)

    """

    pass


def bravi_kitaev(ferm_op: FermionicOperator) -> QubitOperator:
    """Bravyi-Kitaev encoding."""
    # TODO: Implement Bravyi-Kitaev encoding
    pass