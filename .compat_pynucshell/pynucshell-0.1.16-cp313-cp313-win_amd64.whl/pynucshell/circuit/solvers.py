"""Abstract compiler to create and run quantum circuits.

It provides a common interface that given some encoding, will implement the correspondign
qubit operations in one the specified backend."""

from pynucshell.models import Hamiltonian
from .backends.abstract import CircuitBackend
from ..operators import QubitOperator

import numpy as np
import scipy.optimize as opt

# encoding = "JW"
# backend = "qibo"

backendsError = NotImplementedError("Need to choose a valid backend from: qibo, Qiskit, PennyLane")

class Solver:
    def __init__(self, encoding, backend: CircuitBackend):
        self.encoding = encoding
        self.backend = backend
        self._circuit = None

        if hasattr(self.backend, 'get_encoding'):
            self.encoding = self.backend.get_encoding()
            if backend is not None:
                print("INFO: Using backend-specific encoding.")

        self.finished = False

        self.energy_history = []
        self.cost_history = []

        self.observable = None
        self._observable_backend = None

    
    @property
    def circuit(self):
        return self._circuit
    
    @circuit.setter
    def circuit(self, circuit):
        if circuit is not None:
            self._circuit = circuit
            self.nqubits = self.backend.num_qubits(circuit)

    def load_nucleus(self, ham: Hamiltonian, load_hf=True, prune=True):
        self.ham = ham

        if ham.N_protons == 0:
            shift = ham.get_space().half_space
            self.nqubits = ham.get_space().half_space
        elif ham.N_neutrons == 0:
            shift = 0
            self.nqubits = ham.get_space().half_space
        else:
            shift = 0
            self.nqubits = 2*ham.get_space().half_space
        
        # Instantiate the quantum circuit and set the initial Hartree-Fock state vector
        self.circuit = self.backend.create_circuit(self.nqubits)
        
        # FIXME: Referring to basis implies exponential cost
        if load_hf:
            hf_state = [int(q)-shift for q in self.ham._basis.mb()[0]]
            self.backend.set_initial_state(self.circuit, hf_state)
        
        self.observable = self.encoding(ham.get_fermionic(prune=prune))
        self._observable_backend = self.backend.convert_operator(self.observable, nqubits=self.nqubits)

        self.finished = False

        self.energy_history = []
        self.cost_history = []

class VQE(Solver):
    def __init__(self, encoding, backend: CircuitBackend):
        super().__init__(encoding, backend)
        

    def load_nucleus(self, ham: Hamiltonian, load_hf=True, prune=True):
        super().load_nucleus(ham, load_hf, prune)

        self.op_pool_ferm = ham.operator_pool()
        self.op_pool = [self.encoding(op) for op in ham.operator_pool()]
    
    
    def run(self, observable=None, initial_params=None, max_iter=10, tol=1e-4, optimizer="L-BFGS-B", callback=None):
        """
        ADAPT-VQE routine.
        Evolves the circuit by choosing operators from the pool,
        minimizing the parameters, adding the next operator, and iterating.
        """
        
        if self.finished:
            raise RuntimeError("Solver was already ran or was not initalized. Call load_nucleus().")

        if not hasattr(self, 'circuit') or self.circuit is None:
            raise RuntimeError("Circuit not initialized. Call load_nucleus() first.")
        
        if self.backend.num_parameters(self.circuit) == 0:
            raise ValueError("Circuit has no parameters to optimize.")

        if observable is None:
            observable = self._observable_backend
        else:
            if isinstance(observable, QubitOperator):
                observable = self.backend.convert_operator(observable, nqubits=self.backend.num_qubits(self.circuit))

        if initial_params is None:
            initial_params = np.random.random(self.backend.num_parameters(self.circuit))
    
        current_energy = self.backend.expectation(self.circuit, initial_params, observable)
        print(f"Initial energy: {current_energy:.6f}")

        self.iteration_count = 0

        def cost_function(params):
            self.iteration_count += 1
            cost = self.backend.expectation(self.circuit, params, observable, copy=False)
            self.cost_history.append(cost)
            return cost
            
        
        def callback_count_func(intermediate_result):
            try: 
                self.energy_history.append(intermediate_result.fun)
            
            # OLDER VERSIONS OF SCIPY DON'T STORE INTERMEDIATE RESULTS FOR COBYLA/SPSQA
            except:
                params = intermediate_result
                self.energy_history.append(self.backend.expectation(self.circuit, params, observable))

        if callback:
            scipy_callback = lambda x: (callback_count_func(x), callback(x))
        else:
            scipy_callback = callback_count_func
            
        res = opt.minimize(cost_function, initial_params, method=optimizer, callback=scipy_callback)
        
        current_energy = res.fun
        print(f"Optimized energy: {current_energy:.6f}")
        
        self.finished = True
        return res, current_energy


class ADAPTVQE(Solver):
    """Class to generate circuits from the nuclear operators."""
    def __init__(self, encoding, backend: CircuitBackend):
        super().__init__(encoding, backend)

        self.commutators = None
        self.op_pool = None


    def load_nucleus(self, ham: Hamiltonian, load_hf: bool = True, prune: bool = True):
        super().load_nucleus(ham, load_hf, prune)

        self.op_pool_ferm = ham.operator_pool()
        self.op_pool = [self.encoding(op) for op in ham.operator_pool()]

        self.commutators = [self.observable@op - op@self.observable for op in self.op_pool]
        self._commutators_backend = [self.backend.convert_operator(comm, nqubits=self.nqubits) for comm in self.commutators]

# TODO: Add callback for adaptvqe steps?
    def run(self, op_pool=None, observable=None, initial_params=None, max_iter=10, tol=1e-4, optimizer="L-BFGS-B", callback=None):
        """
        ADAPT-VQE routine.
        Evolves the circuit by choosing operators from the pool,
        minimizing the parameters, adding the next operator, and iterating.
        """
        
        if self.finished:
            raise RuntimeError("Solver was already ran or was not initalized. Call load_nucleus().")

        if not hasattr(self, 'circuit') or self.circuit is None:
            raise RuntimeError("Circuit not initialized. Call load_nucleus() first.")
        
        if initial_params is None:
            initial_params = np.random.random(self.backend.num_parameters(self.circuit))

        if observable is None:
            observable = self._observable_backend

        if op_pool is None:
            op_pool = self.op_pool
            op_pool_view = self.op_pool_ferm
        else:
            self.commutators = [observable@op - op@observable for op in op_pool]
            self._commutators_backend = [self.backend.convert_operator(comm, nqubits=self.nqubits) for comm in self.commutators]
            op_pool_view = op_pool

        if self.backend.requires_copying:
            temp_circuit = self.circuit.copy()
            # if hasattr(self.circuit, "logical_params"):
            #     temp_circuit.logical_params = copy.deepcopy(self.circuit.logical_params)
            #     temp_circuit.logical_to_physical = copy.deepcopy(self.circuit.logical_to_physical)

        else:
            temp_circuit = self.circuit

        current_energy = self.backend.expectation(temp_circuit, initial_params, observable)
        print(f"Initial energy: {current_energy:.6f}")

        converged_params = list(initial_params) # no need to copy?

        for step in range(max_iter):            
            print(f"\n------------ LAYER {step} ------------ ")

            print("Finding maximal gradient: ")
            min_ind, min_gradient = self.find_op_circuit(temp_circuit, converged_params, observable, op_pool)
            
            # ADAPT-VQE convergence criterion: max absolute gradient below tolerance
            if abs(min_gradient) < tol:
                print(f"Converged at step {step+1}. Max gradient absolute value {abs(min_gradient)} < {tol}")
                break
                
            op_to_add = op_pool[min_ind]
            print(f"  Chose operator:\n {op_pool_view[min_ind]}\n  with gradient: {min_gradient:.6f}")

            # Add the selected operator to the circuit
            self.backend.exp_pauli_str_staircase(self.circuit, 0.0, op_to_add)


            if self.backend.requires_copying:
                temp_circuit = self.circuit.copy()#deep=True)
                # if hasattr(self.circuit, "logical_params"):
                #     temp_circuit.logical_params = copy.deepcopy(self.circuit.logical_params)
                #     temp_circuit.logical_to_physical = copy.deepcopy(self.circuit.logical_to_physical)

            else:
                temp_circuit = self.circuit

            # Minimize parameters
            def cost_function(params):
                return self.backend.expectation(temp_circuit, params, observable)
            
            # TODO: Add options for optimization 
            # (optimize only new param? / start from random instead of previous converged? / etc)
            res = opt.minimize(cost_function, converged_params+[0.], method=optimizer)
            
            converged_params = list(res.x)
            current_energy = res.fun
            print(f"Optimized energy: {current_energy:.6f}")
        
        self.finished = True
        # TODO: Add res ? Includes information about convergence // BUT REQUIRES refactoring code
        return res, current_energy

    def find_op_circuit(self, circuit, params, observable, op_pool=None):
        """Finds next operator to add to the circuit in the ADAPT-VQE routine.
        It chooses the one with highest gradient, measured using the commutator."""
        if op_pool is None:
            op_pool = self.ham.operator_pool()
            
        min_gradient = 0
        min_ind = 0

        for i, op in enumerate(op_pool): 
            # Measure commutator
            # TODO: self._commutators_backend need not be defined or match desired object ! (if load_nucleus has not been run before)
            grad = self.backend.expectation(circuit, params, self._commutators_backend[i])#, copy=False)

            if i == 0 or abs(grad) > abs(min_gradient):
                min_gradient = grad
                min_ind = i

        return min_ind, min_gradient






# Circuits can be embeded into larger circuits (qibo: .on_qubits(), qiskit: .compose())

# Abstract functions to obtain 

# TODO: Decide on parametrization of gates: basic (iθ·T) or more general (if(θ)·T)
#   - Currently only basic param.

# TODO: Restructure Compiler?
#           - Maybe better as interface to call other objects:
#           - Ansatze
#           - Model / Solver
#           - Optimizers


        