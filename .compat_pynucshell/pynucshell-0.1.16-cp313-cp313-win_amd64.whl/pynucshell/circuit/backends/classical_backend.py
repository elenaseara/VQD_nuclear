from .abstract import CircuitBackend
from typing import Optional, Union
from pynucshell.operators import QubitOperator, FermionicOperator
from pynucshell import Operator
from typing import Union
from scipy.sparse.linalg import expm_multiply
from copy import deepcopy
from pynucshell import Space, Basis, Operator, Simulator
from scipy.sparse.linalg import LinearOperator
from scipy.sparse import csr_matrix

import numpy as np

# TODO: Add ABC / abstractmethod  to define abstract class?
# TODO: Parameters are no longer expected to be part of circuit. They could be removed now.

class ClassicalCircuit:
    """Analogue to a quantum circuit for the simulations performed using a :class:`ClassicalCircuitBackend`

    Does not actually use qubits but rather stores the fock states and fermionic operations
    that will be applied through the added gates.
    """

    def __init__(self,n_qubits : int, basis: Basis):
        self.n_qubits = n_qubits
        self._initial_state = None
        self.ops : list[LinearOperator | csr_matrix]
        self.ops = []
        self.params : list[float]
        self.params = []
        self.basis = basis
    
    def two_body_fermionic(self, indices: tuple, theta : float):
        self.params.append(theta)
        self.ops.append(('2BF', indices))

    def one_body_fermionic(self, indices: tuple, theta : float):
        self.params.append(theta)
        self.ops.append(('1BF', indices))

    @property
    def initial_state(self):
        return self._initial_state

    @initial_state.setter
    def initial_state(self, value):
        self.mb_initial_state = self.basis.set_state(value)
        self._initial_state = value

    def copy(self, deep = True):
        return self
        #raise RuntimeWarning("Shallow copy")

    def __repr__(self):
        return f"""
ClassicalCircuit(n_qubits={self.n_qubits},initial_state={self.initial_state},\
                 ops = {self.ops})"""

class ClassicalCircuitBackend(CircuitBackend):
    """Class implementing interface to build and run quantum circuits but which
    simulates them using fermionic simulation. 
    
    It presents a substantial speedup
    to actual quantum circuit backends, but it can only compute noiseless expectation
    values of circuits which respect the problem symmetries. 
    As we are not actually working with qubits, instead of encodings such as jordan wigner
    one must use the encoding provided by the backend itself, obtained from :meth:`get_encoding`.

    Parameters
    ----------
    basis : Basis
        The problem basis (with restricted symmetries) that will be simulated.
    is_CSR : bool, optional
        Boolean indicating if the operators should be represented as CSR sparse matrices.
        False by default, indicating to use scipy Linear Operators.
    """

    def __init__(self, space : Space, basis : Basis, is_CSR : bool = False):
        if hasattr(basis, "get_basis"):
            self.basis = basis.get_basis()
        else:
            self.basis = basis
        self.is_CSR = is_CSR
        self.sim = Simulator(space, basis)
        super().__init__()

    # FIXME: There seems to be a problem with complex coefficients?
    def get_encoding(self): #, is_CSR : bool = False):
        """Returns classical backend specific encoding, which
        translates operators into efficient Linear Operators (or CSR sparse matrices),
        as used in the classical nuclear shell model calculations.
        """
        def encode(fermionic: FermionicOperator):
            coefficients = []
            operators = []
            for operator in fermionic.terms.keys():
                if len(operator) == 4:
                    i,j,k,l = operator
                    if i[1] != 1 or j[1] != 1 or k[1] != 0 or l[1] != 0:
                        raise RuntimeError("2-body terms other than i^ j^ k l not implemented")
                    else:
                        i,j,k,l = i[0], j[0], k[0], l[0]
                    operators.append((i,j,k,l))
                    coefficients.append(fermionic.terms[operator])
                elif len(operator) == 2:
                    i,j = operator
                    if i[1] != 1 or j[1] != 0:
                        raise RuntimeError("1-body terms other than i^ j not implemented")
                    else:
                        i,j = i[0], j[0]
                    operators.append((i,j))
                    coefficients.append(fermionic.terms[operator])
            operator = Operator.from_uncoupled(operators,coefficients)
            if self.is_CSR:
                return self.sim.to_csr(operator)
            return self.sim.to_lin_op(operator)
        return encode
    
    def create_circuit(self,n_qubits: int) -> ClassicalCircuit:
        """Create a new quantum circuit with the given number of qubits."""
        return ClassicalCircuit(int(n_qubits), self.basis)
    
    def set_initial_state(self, circuit: ClassicalCircuit, state: list) -> None:
        """Set the initial state of the circuit as a slater determinant
        
        Parameters
        -----------
        circuit : ClassicalCircuit
        state : list
            List of indices of initially occupied orbitals."""
        circuit.initial_state = state
    
    def exp_pauli_str_staircase(self, circuit: ClassicalCircuit, theta: float, op : Simulator) -> None:
        circuit.params.append(theta)
        circuit.ops.append(op)
    
    def expectation(self, circuit: ClassicalCircuit, parameters: list[float], f_op: csr_matrix | LinearOperator , nshots: Optional[int] = None, copy : bool = False):
        state = circuit.mb_initial_state #self.basis.set_state(circuit.initial_state) # Removed: No need to reconstruct basis each time
        H_op = f_op
        for theta, op in zip(parameters, circuit.ops):
            state = expm_multiply(theta * op, state, traceA = 0.0)

        return np.vdot(state, H_op@state)
    
    def state(self, circuit: ClassicalCircuit, parameters: list[float], copy: bool = False):
        
        state = circuit.mb_initial_state #self.basis.set_state(circuit.initial_state) # Removed: No need to reconstruct basis each time
        
        for theta, op in zip(parameters, circuit.ops):
            state = expm_multiply(theta * op, state, traceA = 0.0)

        return state
        
    @staticmethod
    def expectation_from_samples(circuit: object, observable: QubitOperator, nshots: int):
        """Helper functionto calculate expectation value from sampling."""
        raise NotImplementedError
    
    def add_measurement(self, circuit: ClassicalCircuit, qubits: list[int]):
        """Add a measurement gates to the circuit."""
        raise NotImplementedError
    
    @staticmethod
    def sample(circuit: object, observable: QubitOperator, nshots: int):
        """Sample quantum circuit in the computational basis."""
        raise NotImplementedError
    
    @staticmethod    
    def get_parameters(circuit: ClassicalCircuit):
        return circuit.params

    @staticmethod
    def set_parameters(circuit: ClassicalCircuit, parameters: list):
        circuit.params = list(parameters)

    @staticmethod
    def parameter_shift_rule(circuit: object, param_num: int, observable: QubitOperator, shift=np.pi/2, analytical=False):
        raise NotImplementedError
    
    # TODO: Maybe better to duck tape  or define this in abstract class rather than here
    @staticmethod
    def convert_operator(operator: Simulator, **kwargs):
        """Converts encoded operator to backend-specific format.
        
        Many quantum computing backends have their own way of representing observables,
        which is more efficient for their specific implementations. This method converts
        our QubitOperator objects into the backend-specific format when applicable."""
        return operator
    
    @staticmethod
    def matplotlib_plot(circuit: object, **kwargs):
        """Plot the quantum circuit using matplotlib."""
        raise NotImplementedError
    
    def givens_single(self, circuit: ClassicalCircuit, theta: float, qubits: list[int]) -> None:
        r"""Implements Givens rotation acting on target qubits.
        
        Our givens rotation is defined as a :math:`R_y(\theta)` rotation acting on a 2 state subspace.
        For the single givens rotation, it acts on the :math:`\{\ket{01},\ket{10}\}` subspace of two qubits.
        
        .. math::
            
            G(\theta) =     \begin{pmatrix}
                                1 & 0 & 0 & 0 \\
                                0 & \cos \theta / 2 & -\sin \theta / 2 & 0 \\
                                0 & \sin \theta / 2 & \cos \theta / 2 & 0 \\
                                0 & 0 & 0 & 1\\
                            \end{pmatrix}

        
        """
        basis = self.basis
        if len(qubits) == 2:
            i,j = qubits[0], qubits[1]
            op = Operator.from_uncoupled((i,j), 1.0, is_fermionic = False) + \
                 Operator.from_uncoupled((j,i),-1.0, is_fermionic = False)
            if self.is_CSR:
                sim = self.sim.to_csr(op)
            else:
                sim = self.sim.to_lin_op(op)
        circuit.params.append(theta)
        circuit.ops.append(sim)


    def givens_double(self, circuit: object, theta: float, qubits: list[int]) -> None:
        r"""Implements Givens rotation acting on target qubits.
        
        Our givens rotation is defined as a :math:`R_y(\theta)` rotation acting on a 2 state subspace.
        For the double givens rotation, it acts on the :math:`\{\ket{0011},\ket{1100}\}` subspace of four qubits.
        """
        basis = self.basis
        if len(qubits) == 4:
            i,j,k,l = qubits[0], qubits[1],qubits[2],qubits[3]
            op = Operator.from_uncoupled((i,j,k,l), 1.0, is_fermionic = False) + \
                 Operator.from_uncoupled((k,l,i,j),-1.0, is_fermionic = False)
            if self.is_CSR:
                sim = self.sim.to_csr(op)
            else:
                sim = self.sim.to_lin_op(op)
        circuit.params.append(theta)
        circuit.ops.append(sim)

    def num_qubits(self, circuit: ClassicalCircuit):
        return circuit.n_qubits
    
    def num_parameters(self, circuit: ClassicalCircuit):
        return len(circuit.params)