"""Backends for quantum circuit implementations.

An abstract :py:class:`CircuitBackend` class implements the generic frontend,
while concrete backends provide the specific implementations for different quantum computing frameworks."""

import importlib

from .abstract import CircuitBackend
from .classical_backend import ClassicalCircuitBackend

allowed_backends = [ClassicalCircuitBackend]
if importlib.util.find_spec("qibo") is not None:
    HAS_QIBO = True
    from .qibo_backend import QiboCircuitBackend
    allowed_backends.append(QiboCircuitBackend)

if importlib.util.find_spec("qiskit") is not None:
    HAS_QISKIT = True
    from .qiskit_backend import QiskitCircuitBackend
    allowed_backends.append(QiskitCircuitBackend)

if importlib.util.find_spec("pennylane") is not None:
    HAS_PENNYLANE = True
    from .pn_backend import PennyLaneCircuitBackend
    allowed_backends.append(PennyLaneCircuitBackend)