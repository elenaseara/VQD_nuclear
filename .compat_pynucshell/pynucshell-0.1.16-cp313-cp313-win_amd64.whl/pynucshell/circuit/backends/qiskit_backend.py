"""Implementation of Qiskit Circuit backend.
For more reference about the front end, refer to abstract.py"""

from typing import Optional

import numpy as np
from qiskit import QuantumCircuit
from qiskit.circuit import Parameter
from qiskit.quantum_info import SparsePauliOp
from qiskit_aer import AerSimulator
from qiskit_aer.primitives import EstimatorV2 as Estimator

from pynucshell.operators import QubitOperator

from .abstract import CircuitBackend


class QiskitCircuitBackend(CircuitBackend):
    """Qiskit CircuitBackend for building and running circuits"""
    def __init__(self):
        super().__init__()

        self.simulator = AerSimulator()
        self.estimator = Estimator()

    def create_circuit(self, n_qubits: int) -> QuantumCircuit:
        """Create a new quantum circuit with the given number of qubits."""
        circ = QuantumCircuit(int(n_qubits))
        circ._qubshell_num_operators = 0
        return circ
    

    def set_initial_state(self, circuit: QuantumCircuit, state: list) -> None:
        """Set the initial state of the circuit by applying X gates
        to the occupied orbitals (qubits)."""
        # TODO: Define in terms of creation operators acting on vacuum state
        for qubit in state:
            circuit.x(int(qubit))

    def exp_pauli_str_staircase(self, circuit: QuantumCircuit, theta: float, qubit_operator: QubitOperator):

        if type(qubit_operator) is str:
            qubit_operator = QubitOperator(qubit_operator)

        if len(qubit_operator.terms) == 0:
            raise ValueError("Given operator is 0")
        
        if not hasattr(circuit, '_qubshell_num_operators'):
            circuit._qubshell_num_operators = 1
            circuit._qubshell_num_exp = 1
        elif not hasattr(circuit, '_qubshell_num_exp'):
            circuit._qubshell_num_exp = 1
        else:
            circuit._qubshell_num_operators += 1
            circuit._qubshell_num_exp += 1

        # theta = Parameter(fr"\theta")
        theta = Parameter(f"theta_op{circuit._qubshell_num_operators}")


        for term, coef in qubit_operator.terms.items():
            qubits = [q for q, p in term]

            if qubits[-1] >= circuit.num_qubits:
                raise ValueError("Pauli string acts on qubits outside the circuit")
            
            if not term:
                # global phase shift
                continue
            
            for q, p in term:
                if p == "X":
                    circuit.h(q)
                elif p == "Y":
                    circuit.rx(np.pi/2, qubit=q)
            
            for i in range(len(qubits) - 1):
                circuit.cx(qubits[i], qubits[i+1])

            if coef.real != 0 and coef.imag != 0:
                raise(ValueError("Can only exponentiate Hermitian or Anti-Hermitian operators (pure real or pure imaginary coefficients)"))
            c = coef.real if coef.real != 0 else -coef.imag
            circuit.rz(2*c*theta, qubit=qubits[-1])

            #phys_map_for_theta.append((current_phys_idx, c))

            for i in reversed(range(len(qubits) - 1)):
                circuit.cx(qubits[i], qubits[i+1])

            for q, p in term:
                if p == "X":
                    circuit.h(q)
                elif p == "Y":
                    circuit.rx(-np.pi / 2, qubit=q)

    def givens_single(self, circuit: object, theta: float, qubits: list[int]) -> None:
        if not hasattr(circuit, '_qubshell_num_operators'):
            circuit._qubshell_num_operators = 1
            circuit._qubshell_num_givens_single = 1
        elif not hasattr(circuit, '_qubshell_num_givens_single'):
            circuit._qubshell_num_givens_single = 1
        else:
            circuit._qubshell_num_operators += 1
            circuit._qubshell_num_givens_single += 1

        # theta = Parameter(fr"\theta")

        theta = Parameter(f"theta_op{circuit._qubshell_num_operators}")

        circuit.cx(qubits[0], qubits[1])
        circuit.ry(theta/2, qubits[0])
        circuit.cx(qubits[1], qubits[0])
        circuit.ry(-theta/2, qubits[0])
        circuit.cx(qubits[1], qubits[0])
        circuit.cx(qubits[0], qubits[1])


    def givens_double(self, circuit: object, theta: float, qubits: list[int]) -> None:
        if not hasattr(circuit, '_qubshell_num_operators'):
            circuit._qubshell_num_operators = 1
            circuit._qubshell_num_givens_double = 1
        elif not hasattr(circuit, '_qubshell_num_givens_double'):
            circuit._qubshell_num_givens_double = 1
        else:
            circuit._qubshell_num_operators += 1
            circuit._qubshell_num_givens_double += 1

        # theta = Parameter(fr"\theta")
        theta = Parameter(f"theta_op{circuit._qubshell_num_operators}")

        circuit.cx(qubits[2], qubits[3])
        circuit.cx(qubits[0], qubits[2])
        circuit.h(qubits[0])
        circuit.h(qubits[3])
        circuit.cx(qubits[0], qubits[1])
        circuit.cx(qubits[2], qubits[3])
        circuit.ry(-theta/8, qubits[0])
        circuit.ry( theta/8, qubits[1])
        circuit.cx(qubits[0], qubits[3])
        circuit.h(qubits[3])
        circuit.cx(qubits[3], qubits[1])
        circuit.ry(-theta/8, qubits[0])
        circuit.ry( theta/8, qubits[1])
        circuit.cx(qubits[2], qubits[1])
        circuit.cx(qubits[2], qubits[0])
        circuit.ry( theta/8, qubits[0])
        circuit.ry(-theta/8, qubits[1])
        circuit.cx(qubits[3], qubits[1])
        circuit.h(qubits[3])
        circuit.cx(qubits[0], qubits[3])
        circuit.ry( theta/8, qubits[0])
        circuit.ry(-theta/8, qubits[1])
        circuit.cx(qubits[0], qubits[1])
        circuit.cx(qubits[2], qubits[0])
        circuit.h(qubits[0])
        circuit.h(qubits[3])
        circuit.cx(qubits[0], qubits[2])
        circuit.cx(qubits[2], qubits[3])

    # QISKIT NEEDS TO COPY FOR ASSIGNING PARAMETERS.
    # ONE SHOULDn'T SET PARAMETERS; ONLY WHEN USING ESTIMATOR/SAMPLER
    def get_parameters(self, circuit: QuantumCircuit):
        """Retrieve logical parameters, including 1-to-1 unmapped physical parameters.
        
        .. warning::
            
            For Qiskit backends these are logical parameters, not numerical"""
        return circuit.parameters

    def state(self, circuit: QuantumCircuit, copy = True):
        return NotImplementedError
    
    def expectation(self, circuit: QuantumCircuit, params: list[float], observable, nshots: Optional[int] = None, copy = True):
        # Initial implementation assuming state vector execution
        obs = self.convert_operator(observable, nqubits=circuit.num_qubits)
        if len(params) != circuit.num_parameters:
            raise ValueError(f"Number of parameters passed ({len(params)}) does not match the number of parameters in the circuit ({circuit.num_parameters}).")
        return self.estimator.run([(circuit, obs, params)]).result()[0].data.evs

    def expectation_from_samples(self, circuit: QuantumCircuit, observable: QubitOperator, nshots: int):
        """Helper function to calculate expectation value from sampling."""
        raise NotImplementedError
    
    def add_measurement(self, circuit: QuantumCircuit, qubits: list[int]):
        """Add a measurement gates to the circuit."""
        circuit.measure(qubits)

    def sample(self, circuit, observable, nshots):
        return NotImplementedError
    
    def parameter_shift_rule(self, circuit, param_num, observable, shift=np.pi/2, analytical=False):
       return NotImplementedError
    
    def convert_operator(self, operator: QubitOperator, nqubits = None) -> SparsePauliOp:
        """Convert a QubitOperator to a Qiskit SparsePauliOp."""
        if isinstance(operator, SparsePauliOp):
            if nqubits is not None and operator.num_qubits != nqubits:
                raise ValueError(f"Number of qubits in the operator {operator.num_qubits} does not match the specified number {nqubits}.")
            return operator
            
        if isinstance(operator, QubitOperator):

            return _openfermion_to_qiskit(operator, nqubits)
            
        raise TypeError("Operator must be a QubitOperator or a qiskit SparsePauliOp")

    def matplotlib_plot(self, circuit: QuantumCircuit, **kwargs):
        """Plot the quantum circuit using matplotlib. 
        Refer to qiskit.visualization.plot_circuit for more details and optional arguments."""
        circuit.draw(output="mpl",**kwargs)

    def summary(self, circuit: QuantumCircuit):
        """Returns string summarizing the quantum circuit, giving gate and depth count."""
        return str(circuit.count_ops()) + "depth : " + str(circuit.depth())
    
    def num_qubits(self, circuit: QuantumCircuit):
        return circuit.num_qubits

    def num_parameters(self, circuit: QuantumCircuit):
        return circuit.num_parameters


def _openfermion_to_qiskit(qubit_op, num_qubits):
    """
    Efficiently converts an OpenFermion QubitOperator to a Qiskit SparsePauliOp.
    
    Args:
        qubit_op (openfermion.QubitOperator): The OpenFermion operator dictionary.
        num_qubits (int, optional): Total number of qubits in the system. 
                                    If None, it is automatically inferred from the 
                                    highest qubit index present.
                                    
    Returns:
        SparsePauliOp: The optimized Qiskit sparse Pauli operator.
    """

    sparse_list = []

    # Infer number of qubits if not explicitly provided
    if num_qubits is None:
        all_indices = [idx for term in qubit_op.terms for idx, _ in term]
        num_qubits = max(all_indices) + 1 if all_indices else 1
    
    for term, coeff in qubit_op.terms.items():
        if not term:  
            # Identity
            sparse_list.append(("I", [0], coeff))
        else:
            # Combine into ["p1p2p3...", [q1,q2,q3,...]]
            pauli_str = "".join(action for _, action in term)
            qubit_indices = [idx for idx, _ in term]           
            
            sparse_list.append((pauli_str, qubit_indices, coeff))

    return SparsePauliOp.from_sparse_list(sparse_list, num_qubits=num_qubits)

