"""Implementation of PennyLane Circuit backend"""
# Expectation value
# Convert Hamiltonian

from .abstract import CircuitBackend
from pynucshell.operators import QubitOperator
import copy
import pennylane as qml
from typing import Optional

import numpy as np
from functools import reduce

class PennyLaneCircuit:

    def __init__(self,n_qubits : int):
        self.n_qubits = n_qubits
        self.nqubits = n_qubits
        self.initial_state = None
        self.gates = []
        self.device = qml.device('lightning.qubit', wires=n_qubits)
        self.exp_val = None
    
    def exp_pauli(self, qubit_operator, theta):
        """Appends to given PennyLane circuit the gates implementing a pauli string exponential using the
        staircase decomposition assuming linear connectivity"""
        if len(theta) > 1:
            raise RuntimeError("More than one parameter for one parameter gate")
        theta = theta[0]
        if type(qubit_operator) is str:
            qubit_operator = QubitOperator(qubit_operator)

        if len(qubit_operator.terms) == 0:
            raise ValueError("Given operator is 0")

        for term, coef in qubit_operator.terms.items():
            paulis = [p for q, p in term]
            qubits = [q for q, p in term]

            if qubits[-1] >= self.nqubits:
                raise ValueError("Pauli string acts on qubits outside the circuit")
            
            # # Circuit labelling could be compacted if we force qibo >= 0.2.14
            # # otherwise dependency is qibo >= 0.2.4
            # circuit = Circuit(nqubits=len(qubits), wire_names=qubits) 
            
            if not term:
                # global phase shift
                continue
            
            for q, p in term:
                if p == "X":
                    #circuit.add(gates.H(q))
                    #self.add(('Hadamard', [q], []))
                    qml.Hadamard(q)
                elif p == "Y":
                    #circuit.add(gates.RX(q, theta=np.pi / 2, trainable=False))
                    #circuit.add('RX', [q], [np.pi / 2])
                    qml.RX(np.pi/2, q)
            
            for i in range(len(qubits) - 1):
                #circuit.add(gates.CNOT(qubits[i], qubits[i+1]))
                #circuit.add(('CNOT', [i,i+1], []))
                qml.CNOT([qubits[i],qubits[i+1]])

            # Map the logical parameter to this new physical parameter
            if coef.real != 0 and coef.imag != 0:
                raise(ValueError("Can only exponentiate Hermitian or Anti-Hermitian operators (pure real or pure imaginary coefficients)"))
            c = coef.real if coef.real != 0 else -coef.imag
            qml.RZ(2* theta * c, qubits[-1] )
            #circuit.add(gates.RZ(qubits[-1], theta=2 * theta * c))

            #phys_map_for_theta.append((current_phys_idx, c))

            for i in reversed(range(len(qubits) - 1)):
                #circuit.add(gates.CNOT(qubits[i], qubits[i+1]))
                qml.CNOT([qubits[i],qubits[i+1]])

            for q, p in term:
                if p == "X":
                    #circuit.add(gates.H(q))
                    qml.Hadamard(q)
                elif p == "Y":
                    #circuit.add(gates.RX(q, theta=-np.pi / 2, trainable=False))   
                    qml.RX(-np.pi/2, q)

    def givens_single(self, qubits: list[int], theta: float):
        """Appends to given PennyLane circuit the gates implementing a single givens excitation
        assuming all-to-all connectivity"""
        theta = theta[0]
        qml.CNOT([qubits[0], qubits[1]])
        qml.RY(theta/2, qubits[0])
        qml.CNOT([qubits[1], qubits[0]])
        qml.RY(-theta/2, qubits[0])
        qml.CNOT([qubits[1], qubits[0]])
        qml.CNOT([qubits[0], qubits[1]])
    
    def givens_double(self, qubits: list[int], theta: float) -> None:
        """Appends to given PennyLane circuit the gates implementing a double givens excitation
        assuming all-to-all connectivity"""
        theta = theta[0]
        qml.CNOT([qubits[2], qubits[3]])
        qml.CNOT([qubits[0], qubits[2]])
        qml.H(qubits[0])
        qml.H(qubits[3])
        qml.CNOT([qubits[0], qubits[1]])
        qml.CNOT([qubits[2], qubits[3]])
        qml.RY(-theta/8, qubits[0])
        qml.RY(theta/8, qubits[1])
        qml.CNOT([qubits[0], qubits[3]])
        qml.H(qubits[3])
        qml.CNOT([qubits[3], qubits[1]])
        qml.RY(-theta/8, qubits[0])
        qml.RY(theta/8, qubits[1])
        qml.CNOT([qubits[2], qubits[1]])
        qml.CNOT([qubits[2], qubits[0]])
        qml.RY(theta/8, qubits[0])
        qml.RY(-theta/8, qubits[1])
        qml.CNOT([qubits[3], qubits[1]])
        qml.H(qubits[3])
        qml.CNOT([qubits[0], qubits[3]])
        qml.RY(theta/8, qubits[0])
        qml.RY(-theta/8, qubits[1])
        qml.CNOT([qubits[0], qubits[1]])
        qml.CNOT([qubits[2], qubits[0]])
        qml.H(qubits[0])
        qml.H(qubits[3])
        qml.CNOT([qubits[0], qubits[2]])
        qml.CNOT([qubits[2], qubits[3]])
        

    def add(self, gate):
        self.gates.append(gate)

    def set_parameters(self, parameters):
        counter = 0
        # Update stored logical parameters
        for i in range(len(self.gates)):
            if len(self.gates[i][2]) > 0:
                self.gates[i] = (self.gates[i][0], self.gates[i][1], [parameters[counter]])
                counter += 1

    def get_parameters(self):
        parameters = []
        # Update stored logical parameters
        for i in range(len(self.gates)):
            if len(self.gates[i][2]) > 0:
                parameters.append(self.gates[i][2])
        return parameters
    
    def run(self):
        for gate, wires, params in self.gates:
            
            if hasattr(self, gate):
                gate_obj = getattr(self, gate)
                gate_obj(wires, params)
            else:
                gate_obj = getattr(qml,gate)
                gate_obj(*params, wires=wires)

    def exp_value(self, op):
        self.exp_val = op

    def run_circuit(self):
        def circuit():
            self.run()
            return qml.expval(self.exp_val)
        qnode = qml.QNode(circuit,self.device)
        return qnode()
    
    def draw(self):
        def circuit():
            self.run()
            return qml.expval(self.exp_val)
        qnode = qml.QNode(circuit,self.device)
        return print(qml.draw(qnode)())
    
class PennyLaneCircuitBackend(CircuitBackend):
    """Qibo Circuitbackend for building and running circuits
    
    Non trainable gates are marked as such setting trainable=False"""
    requires_copying = False
    def create_circuit(self, n_qubits: int) -> PennyLaneCircuit:
        """Create a new quantum circuit with the given number of qubits."""
        # TODO:     Decide if to initialize in vacuum state?
        return PennyLaneCircuit(int(n_qubits))

    def set_initial_state(self, circuit: PennyLaneCircuit, state: list) -> None:
        """Set the initial state of the circuit by applying X gates
        to the occupied orbitals (qubits)."""
        # TODO: Define in terms of creation operators acting on vacuum state
        for qubit in state:
            #circuit.add(gates.X(int(qubit)))
            circuit.add(('X', [int(qubit)], []))

    def apply_pauli_string(self, circuit: object, pauli_string: QubitOperator) -> None:
        r"""Create X,Y,Z gates implementing Pauli string.
        """
        #gate_list = {'X': gates.X, 'Y': gates.Y, 'Z': gates.Z}
        if len(pauli_string > 1):
            raise ValueError(f"Trying to apply multiple ({len(pauli_string)}) Pauli strings", pauli_string)
        for term in pauli_string:
            for q, P in term:
                #circuit.add(gate_list[P](int(q)))
                circuit.add((P, [q], []))

    def exp_pauli_str_staircase(self, circuit: PennyLaneCircuit, theta: float, qubit_operator):
        """Appends to given qibo circuit the gates implementing a pauli string exponential using the
        staircase decomposition assuming linear connectivity"""

        circuit.add(('exp_pauli', qubit_operator, [theta]))

    def givens_single(self, circuit: object, theta: float, qubits: list[int]) -> None:
        r"""Implements Givens rotation acting on target qubits.
        
        Our givens rotation is defined as a :math:`R_y(\theta)` rotation acting on a 2 state subspace.
        For the single givens rotation, it acts on the :math:`\{\ket{01},\ket{10}\}` subspace of two qubits.
        
        .. math::
            
            G(\theta) =     \begin{pmatrix}
                                1 & 0 & 0 & 0 \\
                                0 & \cos \theta / 2 & -\sin \theta / 2 & 0 \\
                                0 & \sin \theta / 2 & \cos \theta / 2 & 0 \\
                                0 & 0 & 0 & 1\\
                            \end{pmatrix}

        
        """
        circuit.add(('givens_single', qubits, [theta]))


    def givens_double(self, circuit: object, theta: float, qubits: list[int]) -> None:
        r"""Implements Givens rotation acting on target qubits.
        
        Our givens rotation is defined as a :math:`R_y(\theta)` rotation acting on a 2 state subspace.
        For the double givens rotation, it acts on the :math:`\{\ket{0011},\ket{1100}\}` subspace of four qubits.
        """
        circuit.add(('givens_double', qubits, [theta]))

    def get_parameters(self, circuit):
        """Retrieve logical parameters, including 1-to-1 unmapped physical parameters."""
        return circuit.logical_parameters

    def set_parameters(self, circuit, parameters):
        """Map logical/unmapped parameters back to the PL internal structure."""
        
        circuit.set_parameters(parameters)

    def expectation(self, circuit: object, parameters: list[float], observable, nshots: Optional[int] = None, copy: bool = False):

        self.set_parameters(circuit, parameters)
        #print(type(observable))
        obs = self.convert_operator(observable, nqubits = circuit.n_qubits, check_hermitian=True)
        circuit.exp_value(obs)
        return circuit.run_circuit()

    def expectation_from_samples(self, circuit: object, observable: QubitOperator, nshots: int):
        """Helper functionto calculate expectation value from sampling."""
        raise NotImplementedError
    
    def sample(self, circuit, observable, nshots):
        raise NotImplementedError
    
    def shift_parameter(self, circuit, param_num, shift):
        """Shift a logical parameter and update physical mapped parameters."""
        params = list(self.get_parameters(circuit))
        params[param_num] += shift
        self.set_parameters(circuit, params)
    
    def parameter_shift_rule(self, circuit, param_num, observable, shift=np.pi/2, analytical=False):
        # TODO: General structure can be abstracted, generic for different backends.
        # BUT SHOULD CHECK IF IT IS VALID (access gate information of corresponding parameter / physical mapping)
        raise RuntimeError("Not implemented")
    
    def convert_operator(self, operator: QubitOperator, nqubits = None, check_hermitian=False) :
        """Convert a QubitOperator to a PennyLane LinearCombination."""
        # similar to pennylane.qchem.convert._openfermion_to_pennylane

        if isinstance(operator, qml.ops.op_math.LinearCombination):
            return operator
        # TODO: PennyLane is only backend which can't measure hermitian observables?
        if check_hermitian:
            if not operator.is_hermitian():
                raise ValueError("Operator is not Hermitian, PennyLane will only measure the real casted part\n" \
                                 "You may split operator into hermitian and anti-hermitian parts to force measurement.")
        
        coeffs = []
        ops = []

        mapping = {
            'X' : qml.PauliX,
            'Y' : qml.PauliY,
            'Z' : qml.PauliZ,
            'I' : qml.I,
        }
        #print(type(operator))
        for key in operator.terms.keys():
            temp = []
            for pauli in key:
                i = pauli[0]
                gate = mapping.get(pauli[1])
                temp.append(gate(i))
            coeffs.append(operator.terms[key])
            if len(temp) == 1:
                ops.append(temp[0])
            elif len(temp) > 1:
                # initial = temp[0]
                # for i in temp[1:]:
                #     initial = initial @ i
                # ops.append(initial)   # compact into more efficient qml.prod (lazy=True)
                ops.append(qml.prod(*temp))
            elif len(temp) == 0 :
                ops.append(mapping.get('I')(0))
        #print(len(coeffs), len(ops))
        return qml.Hamiltonian(coeffs, ops)

    def matplotlib_plot(self, circuit: object, **kwargs):
        """Plot the quantum circuit using matplotlib."""
        # Lazy import to avoid importing matplotlib during backend import.
        # also fixes PyparsingDeprecationWarnings which may appear in some matplotlib versions
        raise RuntimeError("Not implemented")
        from qibo.ui import plot_circuit
        plot_circuit(circuit, **kwargs)

    def summary(self, circuit):
        return None
        """Summarize the quantum circuit, giving gate and depth count."""
        return circuit.summary()
    
    def get_nqubits(self, circuit):
        return None
        return circuit.nqubits

    def add_measurement(self, circuit: object, qubits: list[int]):
        """Add a measurement gate to the circuit."""
    def num_parameters(self, circuit):
        return len(circuit.get_parameters())
    def num_qubits(self, circuit):
        return circuit.n_qubits
    def state():
        return None

