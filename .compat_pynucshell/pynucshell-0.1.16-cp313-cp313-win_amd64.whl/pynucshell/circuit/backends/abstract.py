"""Backends to work in circuit formalism from operators."""

from abc import ABC, abstractmethod
from typing import Optional, Union
from pynucshell.operators import QubitOperator
from typing import Union

import numpy as np

class CircuitBackend(ABC):
    """Abstract class that defines the interface between pynucshell objects
    and quantum circuit libraries.
    """
    # If ran circuits can't be modified (and thus need to be copied before) / ex. QIBO
    requires_copying: bool = False
    
        
    def __init__(self):
        self.noisy = False

    @abstractmethod
    def create_circuit(self, n_qubits: int) -> object:
        """Create a new quantum circuit with the given number of qubits."""
        raise NotImplementedError

    @abstractmethod
    def set_initial_state(self, circuit: object, state: list) -> None:
        """Set initial product state using X gates. Provided state must indicate the
        qubits to set to 1 (otherwise they are set to 0)."""
        raise NotImplementedError
    
    @abstractmethod
    def exp_pauli_str_staircase(self, circuit: object, theta: float, pauli_string: Union[str, QubitOperator]) -> None:
        """Construct the staircase circuit for the exponential of a Pauli string.

        Builds a quantum circuit implementing the unitary

        :math:`\\exp\\left(i\\theta P\\right)`,

        where :math:`\\theta` is a real scalar and :math:`P` is the input Pauli string.

        Parameters
        ----------
        theta : float
            Rotation parameter :math:`\\theta` in radians.
        pauli_string : QubitOperator or str
            string representing the pauli gate acting on each operator (e.g., ``"XZIY"``), or 
            qubit operator, where coefficients are relevant and a first order trotterization
            will be performed.

        Returns
        -------
        QuantumCircuit
            Circuit implementing :math:`\\exp\\left(i\\theta P\\right)` using a
            staircase decomposition.

        Raises
        ------
        NotImplementedError
            Always raised in the abstract backend implementation; concrete backends
            must provide this method.
        """
        """Returns the circuits implementing the exponential of a single pauli string:
        `math`:`exp(i * theta * pauli_string)`
        passed as input using the staircase algorithm."""

        # TODO: Add different implemnetations ("Givens-like" / different trotterization levels / etc)
        raise NotImplementedError
    
    @abstractmethod     # TODO: This is a circuit specific gate!!! Makes not much sense.
    def givens_single(self, circuit: object, theta: float, qubits: list[int]) -> None:
        r"""Implements Givens rotation acting on target qubits.
        
        Our givens rotation is defined as a :math:`R_y(\theta)` rotation acting on a 2 state subspace.
        For the single givens rotation, it acts on the :math:`\{\ket{01},\ket{10}\}` subspace of two qubits.
        Reference: Quantum 6, 742 (2022).
        
        .. math::
            
            G(\theta) =     \begin{pmatrix}
                                1 & 0 & 0 & 0 \\
                                0 & \cos \theta / 2 & -\sin \theta / 2 & 0 \\
                                0 & \sin \theta / 2 & \cos \theta / 2 & 0 \\
                                0 & 0 & 0 & 1\\
                            \end{pmatrix}

        
        """
        pass

    @abstractmethod
    def givens_double(self, circuit: object, theta: float, qubits: list[int]) -> None:
        r"""Implements Givens rotation acting on target qubits.
        
        Our givens rotation is defined as a :math:`R_y(\theta)` rotation acting on a 2 state subspace.
        For the double givens rotation, it acts on the :math:`\{\ket{0011},\ket{1100}\}` subspace of four qubits.
        Reference: Quantum 6, 742 (2022).
        """
        pass

    @abstractmethod
    def state(self, circuit: object, copy: bool = True):
        """Calculate the state vector result of running a circuit."""
        raise NotImplementedError

    @abstractmethod
    def expectation(self, circuit: object, parameters: list[float], observable: QubitOperator, nshots: Optional[int] = None, copy: bool = False):
        """Calculate the expectation value of an observable with respect to a quantum circuit.
        If nshots is not provided, the exact expectation value is calculated (if applicable).
        
        .. note::

            Parameters must always be provided. If there are no parameters, an empty list should be passed instead.
        """
        raise NotImplementedError
     
    def expectation_from_samples(self, circuit: object, observable: QubitOperator, nshots: int):
        """Helper function to calculate expectation value from sampling.
        Usually doesn't need to be defined """
        raise NotImplementedError
    
    @abstractmethod
    def add_measurement(self, circuit: object, qubits: list[int]):
        """Add a measurement gate to the circuit."""
        raise NotImplementedError

    @abstractmethod
    def sample(self, circuit: object, nshots: int) -> dict:
        """Sample quantum circuit in the computational basis.
        Returns a dictionary-like object of measurement results."""
        raise NotImplementedError
    
    
    def get_parameters(self, circuit: object):
        """Get the logical parameters of a circuit. The only consistent expected behaviour is to return a list from which
        one can infer the number of parameters.
        
        Parameters are returned as a list."""
        raise NotImplementedError

    # NOT MANDATORY
    # def set_parameters(self, circuit: object, parameters: list):
    #     """Set the logical parameters of a circuit. In some cases these correspond to attributes
    #     injected by pynucshell. """
    #     raise NotImplementedError

    @abstractmethod
    def parameter_shift_rule(self, circuit: object, param_num: int, observable: QubitOperator, shift=np.pi/2):
        raise NotImplementedError
    
    @abstractmethod
    def convert_operator(self, operator: QubitOperator):
        """Converts QubitOperator to backend-specific format.
        
        Many quantum computing backends have their own way of representing observables,
        which is more efficient for their specific implementations. This method converts
        our QubitOperator objects into the backend-specific format when applicable."""
        raise NotImplementedError
    
    @abstractmethod
    def matplotlib_plot(self, circuit: object, **kwargs):
        """Plot the quantum circuit using matplotlib."""
        raise NotImplementedError
    
    #@abstractmethod
    def summary(self, circuit: object):
        """Summarize the quantum circuit, giving gate and depth count."""
        raise NotImplementedError
    
    @abstractmethod # currently being called in solvers
    def num_qubits(self, circuit: object):
        """Number of qubits in the circuit"""
        raise NotImplementedError #return circuit.nqubits
    
    # TODO: Add num_parameters instead of using get_parameters?
    @abstractmethod
    def num_parameters(self, circuit: object):
        """Number of parameters in the circuit"""
        raise NotImplementedError
    


def inject_counts(circuit):
    if not hasattr(circuit, '_qubshell_num_operators'):
        circuit._qubshell_num_operators = 1
        circuit._qubshell_num_exp = 1
    elif not hasattr(circuit, '_qubshell_num_exp'):
        circuit._qubshell_num_exp = 1
    else:
        circuit._qubshell_num_operators += 1
        circuit._qubshell_num_exp += 1