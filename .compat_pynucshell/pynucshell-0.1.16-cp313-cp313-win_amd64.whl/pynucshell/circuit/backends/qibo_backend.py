"""Implementation of Qibo Circuit backend.
For more reference about the front end, refer to abstract.py"""

from typing import Optional

from .abstract import CircuitBackend
from pynucshell.operators import QubitOperator
import copy

import numpy as np
import sympy
from functools import reduce

# Qibo imports
try:
    from qibo import Circuit, gates
    from qibo import symbols
    from qibo.symbols import X, Y, Z, I
    from qibo.hamiltonians import SymbolicHamiltonian

    # TODO: Check if qibo version is compatible
    # By default, it is not a dependency, so unless [qibo] is used during pip install
    # user may unknowingly have a differente qibo version
    from qibo import __version__ as QIBO_VERSION
    if QIBO_VERSION < "0.2.14":
        print("WARNING: Qibo version is older than 0.2.14. Some features may not work as expected.\n" \
        "To make sure your qibo version is compatible, use the [qibo] dependency when installing pynucshell") 

except:
    raise ImportError("Qibo is not installed. You may add it as an additional dependency using:\n" \
    ">>> pip install pynucshell[qibo]")


PAULI_SYMBOLS = {
    "X": X,
    "Y": Y,
    "Z": Z,
    "I": I,
}


class QiboCircuitBackend(CircuitBackend):
    """Qibo Circuitbackend for building and running circuits
    
    Non trainable gates are marked as such setting trainable=False.
    This backend has two peculiarities. 
    - It requires copying: After executing a circuit it cannot be modified
    - Logical mapping: It """

    requires_copying = True
    
    def __init__(self):
        super().__init__()
        self._qibo_symbol_cache = {}

    def create_circuit(self, n_qubits: int) -> Circuit:
        """Create a new quantum circuit with the given number of qubits."""
        # TODO:     Decide if to initialize in vacuum state?
        return Circuit(int(n_qubits))

    def set_initial_state(self, circuit: Circuit, state: list) -> None:
        """Set the initial state of the circuit by applying X gates
        to the occupied orbitals (qubits)."""
        # TODO: Define in terms of creation operators acting on vacuum state
        for qubit in state:
            circuit.add(gates.X(int(qubit)))

    def apply_pauli_string(self, circuit: object, pauli_string: QubitOperator) -> None:
        r"""Create X,Y,Z gates implementing Pauli string.
        """
        gate_list = {'X': gates.X, 'Y': gates.Y, 'Z': gates.Z}
        if len(pauli_string > 1):
            raise ValueError(f"Trying to apply multiple ({len(pauli_string)}) Pauli strings", pauli_string)
        for term in pauli_string:
            for q, P in term:
                circuit.add(gate_list[P](int(q)))

    def exp_pauli_str_staircase(self, circuit, theta, qubit_operator):
        """Appends to given qibo circuit the gates implementing a pauli string exponential using the
        staircase decomposition assuming linear connectivity"""

        if type(qubit_operator) is str:
            qubit_operator = QubitOperator(qubit_operator)

        if len(qubit_operator.terms) == 0:
            raise ValueError("Given operator is 0")

        # if not hasattr(circuit, "logical_params"):
        #     circuit.logical_params = []
        #     circuit.logical_to_physical = []
            
        # circuit.logical_params.append(theta)
        # phys_map_for_theta = []

        is_logical = hasattr(circuit, "logical_parameters")

        if is_logical: 
            logical_index = len(circuit.logical_parameters)

        for term, coef in qubit_operator.terms.items():
            paulis = [p for q, p in term]
            qubits = [q for q, p in term]

            if qubits[-1] >= circuit.nqubits:
                raise ValueError("Pauli string acts on qubits outside the circuit")
            
            # # Circuit labelling could be compacted if we force qibo >= 0.2.14
            # # otherwise dependency is qibo >= 0.2.4
            # circuit = Circuit(nqubits=len(qubits), wire_names=qubits) 
            
            if not term:
                # global phase shift
                continue
            
            for q, p in term:
                if p == "X":
                    circuit.add(gates.H(q))
                elif p == "Y":
                    circuit.add(gates.RX(q, theta=np.pi / 2, trainable=False))
            
            for i in range(len(qubits) - 1):
                circuit.add(gates.CNOT(qubits[i], qubits[i+1]))

            # Map the logical parameter to this new physical parameter
            current_phys_idx = len(circuit.get_parameters())
            if coef.real != 0 and coef.imag != 0:
                raise(ValueError("Can only exponentiate Hermitian or Anti-Hermitian operators (pure real or pure imaginary coefficients)"))
            c = coef.real if coef.real != 0 else -coef.imag
            if is_logical:
                circuit.add(gates.RZ(qubits[-1], theta=2 * theta * c), logical_index=logical_index, coefficient=2*c)
            else:
                circuit.add(gates.RZ(qubits[-1], theta=2 * theta * c))

            #phys_map_for_theta.append((current_phys_idx, c))

            for i in reversed(range(len(qubits) - 1)):
                circuit.add(gates.CNOT(qubits[i], qubits[i+1]))

            for q, p in term:
                if p == "X":
                    circuit.add(gates.H(q))
                elif p == "Y":
                    circuit.add(gates.RX(q, theta=-np.pi / 2, trainable=False))   

        # if phys_map_for_theta:
        #     circuit.logical_to_physical.append(phys_map_for_theta)
        # else:
        #     # If no physical gates were created, remove the logical parameter
        #     circuit.logical_params.pop()

    def givens_single(self, circuit: object, theta: float, qubits: list[int]) -> None:
        r"""Implements Givens rotation acting on target qubits.
        
        Our givens rotation is defined as a :math:`R_y(\theta)` rotation acting on a 2 state subspace.
        For the single givens rotation, it acts on the :math:`\{\ket{01},\ket{10}\}` subspace of two qubits.
        
        .. math::
            
            G(\theta) =     \begin{pmatrix}
                                1 & 0 & 0 & 0 \\
                                0 & \cos \theta / 2 & -\sin \theta / 2 & 0 \\
                                0 & \sin \theta / 2 & \cos \theta / 2 & 0 \\
                                0 & 0 & 0 & 1\\
                            \end{pmatrix}

        
        """
        #circuit.add(gates.GIVENS(qubits[0], qubits[1], theta=theta))
        logical_index = len(circuit.logical_parameters)
        circuit.add(gates.CNOT(qubits[0], qubits[1]))
        circuit.add(gates.RY(qubits[0], theta/2), logical_index, 1/2.)
        circuit.add(gates.CNOT(qubits[1], qubits[0]))
        circuit.add(gates.RY(qubits[0], -theta/2), logical_index, -1/2.)
        circuit.add(gates.CNOT(qubits[1], qubits[0]))
        circuit.add(gates.CNOT(qubits[0], qubits[1]))


    def givens_double(self, circuit: object, theta: float, qubits: list[int]) -> None:
        r"""Implements Givens rotation acting on target qubits.
        
        Our givens rotation is defined as a :math:`R_y(\theta)` rotation acting on a 2 state subspace.
        For the double givens rotation, it acts on the :math:`\{\ket{0011},\ket{1100}\}` subspace of four qubits.
        """
        logical_index = len(circuit.logical_parameters)
        circuit.add(gates.CNOT(qubits[2], qubits[3]))
        circuit.add(gates.CNOT(qubits[0], qubits[2]))
        circuit.add(gates.H(qubits[0]))
        circuit.add(gates.H(qubits[3]))
        circuit.add(gates.CNOT(qubits[0], qubits[1]))
        circuit.add(gates.CNOT(qubits[2], qubits[3]))
        circuit.add(gates.RY(qubits[0], -theta/8), logical_index, -1/8.)
        circuit.add(gates.RY(qubits[1], theta/8), logical_index, 1/8.)
        circuit.add(gates.CNOT(qubits[0], qubits[3]))
        circuit.add(gates.H(qubits[3]))
        circuit.add(gates.CNOT(qubits[3], qubits[1]))
        circuit.add(gates.RY(qubits[0], -theta/8), logical_index, -1/8.)
        circuit.add(gates.RY(qubits[1], theta/8), logical_index, 1/8.)
        circuit.add(gates.CNOT(qubits[2], qubits[1]))
        circuit.add(gates.CNOT(qubits[2], qubits[0]))
        circuit.add(gates.RY(qubits[0], theta/8), logical_index, 1/8.)
        circuit.add(gates.RY(qubits[1], -theta/8), logical_index, -1/8.)
        circuit.add(gates.CNOT(qubits[3], qubits[1]))
        circuit.add(gates.H(qubits[3]))
        circuit.add(gates.CNOT(qubits[0], qubits[3]))
        circuit.add(gates.RY(qubits[0], theta/8), logical_index, 1/8.)
        circuit.add(gates.RY(qubits[1], -theta/8), logical_index, -1/8.)
        circuit.add(gates.CNOT(qubits[0], qubits[1]))
        circuit.add(gates.CNOT(qubits[2], qubits[0]))
        circuit.add(gates.H(qubits[0]))
        circuit.add(gates.H(qubits[3]))
        circuit.add(gates.CNOT(qubits[0], qubits[2]))
        circuit.add(gates.CNOT(qubits[2], qubits[3]))

    def get_parameters(self, circuit):
        """Retrieve logical parameters, including 1-to-1 unmapped physical parameters."""
        return circuit.logical_parameters
        # phys_params = list(circuit.get_parameters())
        # if not hasattr(circuit, "logical_params"):
        #     return phys_params
            
        # owned_indices = set()
        # block_starts = {}
        # for logical_idx, mapping in enumerate(circuit.logical_to_physical):
        #     if mapping:
        #         first_phys_idx = mapping[0][0]
        #         block_starts[first_phys_idx] = logical_idx
        #         for idx, coef in mapping:
        #             owned_indices.add(idx)
                    
        # logical_params = []
        # for i in range(len(phys_params)):
        #     if i in block_starts:
        #         logical_params.append(circuit.logical_params[block_starts[i]])
        #     elif i not in owned_indices:
        #         logical_params.append(phys_params[i])
                
        # return logical_params

    def set_parameters(self, circuit, parameters):
        """Map logical/unmapped parameters back to the Qibo internal structure."""
        # if not hasattr(circuit, "logical_params"):
        #     circuit.set_parameters(parameters)
        #     return

        # phys_params = list(circuit.get_parameters())
        # owned_indices = set()
        # block_starts = {}
        # for logical_idx, mapping in enumerate(circuit.logical_to_physical):
        #     if mapping:
        #         first_phys_idx = mapping[0][0]
        #         block_starts[first_phys_idx] = logical_idx
        #         for idx, coef in mapping:
        #             owned_indices.add(idx)

        # new_phys_params = list(phys_params)
        # logical_counter = 0
        
        # for i in range(len(phys_params)):
        #     if i in block_starts:
        #         block_idx = block_starts[i]
        #         logical_val = parameters[logical_counter]
        #         circuit.logical_params[block_idx] = logical_val
        #         for phys_idx, coef in circuit.logical_to_physical[block_idx]:
        #             new_phys_params[phys_idx] = 2 * logical_val * coef
        #         logical_counter += 1
        #     elif i not in owned_indices:
        #         new_phys_params[i] = parameters[logical_counter]
        #         logical_counter += 1
                
        # circuit.set_parameters(new_phys_params)
        
        if len(parameters) != len(circuit.logical_parameters):
            raise ValueError(f"Circuit expects {len(circuit.logical_parameters)} parameters, but {len(parameters)} were given: {parameters}.")

        # Update stored logical parameters
        circuit.logical_parameters = list(parameters)

        # Build physical parameter list and apply coefficient mapping
        param_list = [0.] * circuit.n_phys_params
        for logical_index, param in enumerate(parameters):
            mapping = circuit.logical_to_physical[logical_index]
            for phys_idx, coeff in mapping:
                param_list[phys_idx] = param * coeff

        circuit.set_parameters(param_list)

    def state(self, circuit: Circuit, parameters: list[float], copy = False):
        
        self.set_parameters(circuit, parameters)

        if copy: circuit = circuit.copy()

        return circuit().state()

    def expectation(self, circuit: Circuit, parameters: list[float], observable: SymbolicHamiltonian, nshots: Optional[int] = None, copy: bool = False):

        self.set_parameters(circuit, parameters)

        if copy:
            circuit = circuit.copy()
        if QIBO_VERSION < "0.2.23":
            state = circuit().state()
        else:
            state = circuit # circuit can be passed directly

        obs = self.convert_operator(observable, nqubits = circuit.nqubits)
        if QIBO_VERSION < "0.2.23":
            # TODO: Change for expectation_from_circuit?
            return obs.expectation(state)
        else:
            return obs.expectation(state, nshots=nshots)

    def expectation_from_samples(self, circuit: Circuit, observable: QubitOperator, nshots: int):
        """Helper functionto calculate expectation value from sampling."""
        raise NotImplementedError
    
    def add_measurement(self, circuit: Circuit, qubits: list[int]):
        """Add a measurement gates to the circuit."""
        circuit.add(gates.M(*qubits))

    def sample(self, circuit, observable, nshots):
        return circuit(nshots=nshots).frequencies()
    
    def parameter_shift_rule(self, circuit, param_num, observable, shift=np.pi/2, analytical=False):
        # TODO: General structure can be abstracted, generic for different backends.
        # BUT SHOULD CHECK IF IT IS VALID (access gate information of corresponding parameter / physical mapping)
        if not hasattr(circuit, "logical_params"):
            # interpret as physical parameter
            physical_parameters = [param_num]
        else: 
            pass
            #physical_parameters = circuit.__

        self.shift_parameter(circuit, param_num, shift)
        forward = self.expectation(circuit, observable, analytical=analytical)
        
        self.shift_parameter(circuit, param_num, -2 * shift)
        backward = self.expectation(circuit, observable, analytical=analytical)
        
        # Restore to original parameter
        self.shift_parameter(circuit, param_num, shift)
        
        return (forward - backward) / (2 * np.sin(shift))
    
    def convert_operator(self, operator: QubitOperator, nqubits = None) -> SymbolicHamiltonian:
        """Convert a QubitOperator to a Qibo SymbolicHamiltonian."""
        if hasattr(operator, "expectation"):
            return operator
            
        if isinstance(operator, QubitOperator):

            expr_terms = []
            for term, coef in operator.terms.items():
                if coef == 0:
                    continue

                if not term:
                    expr_terms.append(sympy.Mul(sympy.sympify(coef), I(0), evaluate=False))
                    continue

                factors = []
                for q, p in term:
                    cache_key = (p, int(q))
                    sym_op = self._qibo_symbol_cache.get(cache_key)
                    if sym_op is None:
                        sym_op = PAULI_SYMBOLS[p](int(q))
                        self._qibo_symbol_cache[cache_key] = sym_op
                    factors.append(sym_op)

                term_expr = sympy.Mul(*factors, evaluate=False)
                expr_terms.append(sympy.Mul(sympy.sympify(coef), term_expr, evaluate=False))

            if not expr_terms:
                expr_terms.append(sympy.Mul(sympy.Integer(0), I(0), evaluate=False))

            total_sym_op = sympy.Add(*expr_terms, evaluate=False)
                
            return SymbolicHamiltonian(total_sym_op, nqubits=nqubits)
            
        raise TypeError("Operator must be a QubitOperator or a qibo.hamiltonians.Hamiltonian.")

    def _qubit_to_symbolic_hamiltonian(self, qubit_ham, nqubits):
        symbolic_ham = sum(
            reduce(lambda x, y: x * y, (getattr(symbols, pauli_op)(int(qubit)) for qubit, pauli_op in pauli_string), coeff)
            for pauli_string, coeff in qubit_ham.terms.items()
        )
        return SymbolicHamiltonian(symbolic_ham, nqubits=nqubits)

    def matplotlib_plot(self, circuit: object, **kwargs):
        """Plot the quantum circuit using matplotlib."""
        # Lazy import to avoid importing matplotlib during backend import.
        # also fixes PyparsingDeprecationWarnings which may appear in some matplotlib versions
        from qibo.ui import plot_circuit
        plot_circuit(circuit, **kwargs)

    def summary(self, circuit: Circuit):
        """Summarize the quantum circuit, giving gate and depth count."""
        return circuit.summary()
    
    def num_qubits(self, circuit: Circuit):
        return circuit.nqubits
    
    def num_parameters(self, circuit: Circuit):
        return len(self.get_parameters(circuit))


class Circuit(Circuit):
    """Subclass of a Qibo Circuit to inject it with
    logical to physical parameter mapping.
    
    The mapping of logical to physical is stored as a list of lists [(physical_param, coefficient)]"""
# TODO: Decide, another way would be to store the gate itself (reference). But this is less stable between copies/changes

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.logical_parameters = []
        self.logical_to_physical = []
        self.n_phys_params = 0
        
        # name for easy access
        self.logical_params = self.logical_parameters
    
    # TODO: Fix gates warning for documentation
    def add(self, gate, logical_index: int = None, coefficient: float = 1.0) -> None:
        """Extended add method to handle logical parameter mapping.
        
        Parameters
        ------------
        logical_index: int, optional
            The logical parameter index. Only valid if gate expects only one parameter
        """
        super().add(gate)

        if isinstance(gate, gates.ParametrizedGate) and gate.trainable:
            params = gate.parameters

            # We only support single-parameter logical mapping for now
            if logical_index is None:
                for param in params:
                    self.logical_parameters.append(param/coefficient)
                    self.logical_to_physical.append([(self.n_phys_params, coefficient)])
                    self.n_phys_params += 1

            else:
                if len(params) > 1:
                    raise ValueError(
                        f"Logical parameters can only be assigned to single-parameter gates,"
                        f" but gate {gate.__class__.__name__} takes {len(params)} parameters"
                    )

                for param in params:
                    if logical_index >= len(self.logical_parameters):
                        if (logical_index != len(self.logical_parameters)):
                            raise ValueError(
                                f"New logical parameter index {logical_index} does not match the logical parameter list length {len(self.logical_parameters)}."
                            )
                        # create new logical parameter initialized to 0.0
                        self.logical_to_physical.append([])
                        self.logical_parameters.append(param/coefficient)
                    
                    if self.logical_parameters[-1] != param/coefficient:
                        print(f"Warning: The gate {gate} has a parameter {param} that does not match the logical parameter it shares {self.logical_parameters[-1]}.")

                    self.logical_to_physical[logical_index].append((self.n_phys_params, coefficient))
                    self.n_phys_params += 1

    def copy(self, *args, **kwargs):
        """Return a copy of the circuit preserving logical parameter metadata."""
        new = super().copy(*args, **kwargs)
        try:
            # attach deep-copied metadata to the new circuit
            new.logical_parameters = copy.deepcopy(self.logical_parameters)
            new.logical_to_physical = copy.deepcopy(self.logical_to_physical)
            new.n_phys_params = self.n_phys_params
            new.logical_params = new.logical_parameters
        except Exception:
            # if anything goes wrong, still return the shallow copy
            pass
        return new
        
        