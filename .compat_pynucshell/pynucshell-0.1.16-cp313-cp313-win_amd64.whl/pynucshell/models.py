"""Module defining the Hamiltonian class for nuclear shell model calculations."""

from pynucshell import Space, Basis, Operator, Simulator
from scipy.sparse.linalg import eigsh
from numpy import sort
import os
import itertools

from pynucshell.operators import FermionicOperator

# TODO: Add a generic way to modify hamiltonians maybe?
# - useful for quasiparticle?
# - useful for subspace like JUN45 without 0g9/2
class Hamiltonian:
    """Base class for defining nuclear shell model hamiltonians. As an important aspect,
        these are defined with a specific space and basis (number of protons and neutrons)."""

    def __init__(self, N_protons: int, N_neutrons: int, total_J: int, space: Space, ham: Operator):
        """
        Creates a  Hamiltonian
        
        Parameters
        ---------
            N_protons : int
                Number of protons
            N_neutrons : int
                Number of neutrons
            total_J : int
                Twice the total J_z of the system
            space : Space
                Single particle valence space
            ham: Operator
                Hamiltonian Operator
        """
        # TODO: Leave clear what "total_J" is (M/Jz). Also if it is meant to be 2xJ
        #TODO: Allow half-integer Jz? (For odd total N)
        self.N_protons = N_protons
        self.N_neutrons = N_neutrons

        # TODO: DO we allow negative N_protons / N_neutrons to indicate holes?
        if N_protons < 0 or N_neutrons < 0:
            raise(ValueError("Number of protons and neutrons must be non-negative"))
        if N_protons == 0 and N_neutrons == 0:
            raise(ValueError("Nucleus was initialized with zero nucleons"))

        self.total_J = total_J

        # TODO: Hamiltonian currently also holds basis
        #       - Exponential size, should it be deferred to simulator / classical backends?
        basis = Basis(space, self.N_protons, self.N_neutrons, self.total_J)

        self._ham = ham
        self._basis = basis
        self._space = space

        self._operator_pool = None
        self._one_body_operator_pool = None

    @property
    def one_body_ops(self):
        """
        Returns the one-body operators of the Hamiltonian.
        """
        one_bodies = []
        ops = self._ham.ops
        for key in ops.keys():
            #temp = ops[key]
            if len(key) == 2:
                one_bodies.append(key)
        return one_bodies
        
    def get_basis(self) -> Basis:
        return self._basis
    
    def get_operator(self) -> Operator:
        return self._ham
    
    def get_space(self) -> Space:
        return self._space
    
    def set_value(self,indices, value, scaling = None):
        """
        Sets the values of the uncoupled operators to a given value.

        indices : tuple
            tuple of indices representing the operator
        value : float
            value to assign to the operator
        """

        if isinstance(indices, list):
            indices = tuple(indices)
        if indices not in self._ham.ops.keys():
            if scaling is None:
                scaling = False
            self._ham.ops[indices] = (value, scaling)
            raise RuntimeWarning(f"Indices {indices} not in Hamiltonian, adding new operator")
        else:
            if scaling is None:
                scaling = self._ham.ops[indices][1]
            self._ham.ops[indices] = (value, scaling)

    def get_scaled_terms(self):
        N = self.N_neutrons + self.N_protons
        scaling_ar = self._ham.func
        terms = {indices: coeff[0]*(scaling_ar[1]/(scaling_ar[0]+N))**scaling_ar[2] if coeff[1] else coeff[0] for indices, coeff in self._ham.ops.items()}
        return terms

    def get_fermionic(self, prune = True):
        # N = self.N_neutrons + self.N_protons
        # #terms = {indices: self._ham.func(coeff[0], N) if coeff[1] else coeff[0] for indices, coeff in self._ham.ops.items()}
        # scaling_ar = self._ham.func
        # terms = {indices: coeff[0]*(scaling_ar[1]/(scaling_ar[0]+N))**scaling_ar[2] if coeff[1] else coeff[0] for indices, coeff in self._ham.ops.items()}
        terms = self.get_scaled_terms()
        
        # reindex so only neutron states start with index 0, avoid wasting empty qubits
        if self.N_protons == 0:
            shift = self._space.half_space
        else:
            shift = 0

        N_nucleons = self.N_neutrons + self.N_protons

        if prune:
            # TODO: would be more optimal to check from Space properties, not Basis
            allowed_pairs = set()
            allowed_states = set()
            
            # if N_nucleons == 1:
            
            
            for states in self.get_basis().mb():
                for i in range(len(states)):
                    allowed_states.add(states[i]-shift)
                    for j in range(i+1, len(states)):
                        allowed_pairs.add((states[i]-shift, states[j]-shift))

            to_delete = []
            for indices in terms.keys():
                if not all(sp in allowed_states for sp in indices):
                    to_delete.append(indices)
                elif len(indices)==4 and (indices[:2] not in allowed_pairs or indices[2:] not in allowed_pairs):
                    to_delete.append(indices)

            for indices in to_delete:
                del terms[indices]
        
        return FermionicOperator.from_n_body_operator(terms) 

    
    @property
    def two_body_ops(self):
        """
        Returns the two-body operators of the Hamiltonian.
        """
        two_bodies = []
        ops = self._ham.ops
        for key in ops.keys():
            #temp = ops[key]
            if len(key) == 4:
                two_bodies.append(key)
        return two_bodies
    

    # TODO: Add flexibility to operator_pool :
    #   Allow one body operators? (E.g. for Givens / Hardware efficient parametrizations)
    #   Change logic for finding operator_pool?
    #   Decide return format
    def operator_pool(self,  only_hamiltonian: bool = True, antihermitize: bool = True) -> list[FermionicOperator]:
        """
        Returns the two-body operator pool of the Hamiltonian.
        
        This corresponds to limiting the two-body operators to only those
        which mix states in the nucleus' many body basis."""

        #FIXME: If we change arguments, we should rerun circuit?
        if self._operator_pool is not None:
            return self._operator_pool

        if self.N_protons == 0:
            shift = self._space.half_space
        else:
            shift = 0

        mb = self._basis.mb()
        pool = set()
        
        # Strategy: Find possible transitions by finding "cores" accessible from the
        #   many body states via two-body transitions
        core_dict = {}

        for state in mb:
            sorted_state = sorted(state)
            state_set = set(sorted_state)
            
            # Find all pairs (r, s) that can be removed from this state
            for r, s in itertools.combinations(sorted_state, 2):
                core = tuple(sorted(state_set - {r, s}))
                
                if core not in core_dict:
                    core_dict[core] = []

                core_dict[core].append((r, s))
                
        for core, removed_pairs in core_dict.items():
            for (r1, s1), (r2, s2) in itertools.combinations(removed_pairs, 2):
                if not only_hamiltonian or (r2, s2, r1, s1) in self._ham.ops:
                    pool.add((r2-shift, s2-shift, r1-shift, s1-shift))
                    if not antihermitize: pool.add((r1-shift, s1-shift, r2-shift, s2-shift))

        if antihermitize:
            self._operator_pool = [FermionicOperator(el) - FermionicOperator(el[2:]+el[:2]) for el in sorted(list(pool))]
        else:
            self._operator_pool = [FermionicOperator(el) for el in sorted(list(pool))]
        return self._operator_pool
    
    def operator_pool_ind(self,  only_hamiltonian: bool = True) -> list[tuple[int]]:
        """
        Returns the indices of the two-body operator pool of the Hamiltonian.
        
        This corresponds to limiting the two-body operators to only those
        which mix states in the nucleus' many body basis."""

        #FIXME: If we change arguments, we should rerun circuit?
        if self._operator_pool is not None:
            return self._operator_pool

        if self.N_protons == 0:
            shift = self._space.half_space
        else:
            shift = 0

        mb = self._basis.mb()
        pool = set()
        
        # Strategy: Find possible transitions by finding "cores" accessible from the
        #   many body states via two-body transitions
        core_dict = {}

        for state in mb:
            sorted_state = sorted(state)
            state_set = set(sorted_state)
            
            # Find all pairs (r, s) that can be removed from this state
            for r, s in itertools.combinations(sorted_state, 2):
                core = tuple(sorted(state_set - {r, s}))
                
                if core not in core_dict:
                    core_dict[core] = []

                core_dict[core].append((r, s))
                
        for core, removed_pairs in core_dict.items():
            for (r1, s1), (r2, s2) in itertools.combinations(removed_pairs, 2):
                if not only_hamiltonian or (r2, s2, r1, s1) in self._ham.ops:
                    pool.add((int(r2-shift), int(s2-shift), int(r1-shift), int(s1-shift)))

        self._operator_pool = sorted(list(pool))
        return self._operator_pool
    
    def one_body_operator_pool(self, only_hamiltonian: bool = False, antihermitize: bool = False) -> list[FermionicOperator]:
        """
        Returns the one-body operator pool of the Hamiltonian.
        
        This corresponds to limiting the one-body operators to only those
        which mix states in the nucleus' many body basis."""
        if self._one_body_operator_pool is not None:
            return self._one_body_operator_pool

        if self.N_protons == 0:
            shift = self._space.half_space
        else:
            shift = 0

        mb = self._basis.mb()
        pool = set()
        
        # Strategy: Find possible transitions by finding "cores" accessible from the
        #   many body states via one-body transitions
        core_dict = {}

        for state in mb:
            sorted_state = sorted(state)
            state_set = set(sorted_state)
            
            for s in sorted_state:
                core = tuple(sorted(state_set - {s}))
                
                if core not in core_dict:
                    core_dict[core] = []

                core_dict[core].append(s)
                
        for core, removed_el in core_dict.items():
            for s1, s2 in itertools.combinations(removed_el, 2):
                if not only_hamiltonian or (s2, s1) in self._ham.ops:
                    pool.add((s2-shift, s1-shift))
                    if not antihermitize: pool.add((s1-shift, s2-shift))
            for s in removed_el:
                if not only_hamiltonian or (s, s) in self._ham.ops:
                    if not antihermitize: pool.add((s-shift, s-shift))
        if antihermitize:
            self._one_body_operator_pool = [FermionicOperator(el) - FermionicOperator(el[::-1]) for el in sorted(list(pool))]
        else:
            self._one_body_operator_pool = [FermionicOperator(el) for el in sorted(list(pool))]
        return self._one_body_operator_pool

    def linear_op(self):
        """
        Returns the sparse LinearOperator for the sd Hamiltonian
        """
        if not hasattr(self,'sim'):
            self.sim = Simulator(self.get_space(), self.get_basis())
        return self.sim.to_lin_op(self.get_operator())

    def complex_linear_op(self):
        """
        Returns the sparse LinearOperator for the sd Hamiltonian
        """
        if not hasattr(self,'sim'):
            self.sim = Simulator(self.get_space(), self.get_basis())
        return self.sim.to_lin_op(self.get_operator())

    def get_eigvals(self, k):
        """
        Computes the lowest k eigenvalues
        
        Parameters
        ----------
            k : int
                Number of eigenvalues to compute
        """
        if not hasattr(self,'sim'):
            self.sim = Simulator(self.get_space(), self.get_basis())
        return sort(eigsh(self.sim.to_lin_op(self.get_operator()), k = k, return_eigenvectors = False, which= 'SA'))

    def get_eigs(self, k):
        """
        Computes the lowest k eigenvalues
        
        Parameters
        ----------
            k : int
                Number of eigenvalues to compute
        """
        if not hasattr(self,'sim'):
            self.sim = Simulator(self.get_space(), self.get_basis())
        return eigsh(self.sim.to_lin_op(self.get_operator()), k = k, return_eigenvectors = True, which= 'SA')
    
    def to_csr(self):
        """
        Returns the sparse CSR for the Hamiltonian
        """
        if not hasattr(self,'sim'):
            self.sim = Simulator(self.get_space(), self.get_basis())
        return self.sim.to_csr(self.get_operator())
        #return Simulator(self._ham, self._basis).to_csr()

    def to_dense(self):
        """
        Returns the matrix for the Hamiltonian
        """
        if not hasattr(self,'sim'):
            self.sim = Simulator(self.get_space(), self.get_basis())
        return self.sim.to_csr(self.get_operator()).todense()
        #return Simulator(self._ham, self._basis).to_csr().todense()
    
    def __repr__(self):
        """
        Returns text description of the Hamiltonian (class and parameters)"""
        return f"{self.__class__.__name__}(N_protons={self.N_protons}, N_neutrons={self.N_neutrons}, total_Jz={self.total_J})"

class sd_Hamiltonian(Hamiltonian):

    def __init__(self, N_protons, N_neutrons, total_J):
        """
        Creates a sd shell Hamiltonian using the USDB interaction
        
        Parameters
        ---------
            N_protons : int
                Number of protons
            N_neutrons : int
                Number of neutrons
            total_J : int
                Total J_z of the system
        """
        sd_space = Space([0, 1, 0], [2, 0, 2], [2.5, 0.5, 1.5])

        base_path = os.path.dirname(os.path.abspath(__file__))
        h1b_path = os.path.join(base_path, 'data', 'h1b_sd.txt')
        h2b_path = os.path.join(base_path, 'data', 'h2b_sd.txt')

        one_b = Operator.from_file(h1b_path)
        two_b = Operator.from_file(h2b_path, [16.0,18.0,0.3] , True)
        
        #TODO: Decide on -1/4. Minus sign is currently consistent with ordering V = Vijkl · ai^ aj^ ak al 
        ham = -1/4*two_b + one_b

        super().__init__(N_protons, N_neutrons, total_J, sd_space, ham)


class p_Hamiltonian(Hamiltonian):

    def __init__(self, N_protons, N_neutrons, total_J):
        """
        Creates a p shell Hamiltonian using the Cohen-Kurath interaction
        
        Parameters
        ---------
            N_protons : int
                Number of protons
            N_neutrons : int
                Number of neutrons
            tota_J : int
                Total J_z of the system
        """

        p_space = Space([0, 0], [1, 1], [1.5, 0.5])

        base_path = os.path.dirname(os.path.abspath(__file__))
        h1b_path = os.path.join(base_path, 'data', 'h1b_p.txt')
        h2b_path = os.path.join(base_path, 'data', 'h2b_p.txt')

        one_b = Operator.from_file(h1b_path)
        #two_b = Operator.from_file(h2b_path, lambda x, A : -x/4, True)
        two_b = Operator.from_file(h2b_path)

        ham = -1/4*two_b + one_b

        super().__init__(N_protons, N_neutrons, total_J, p_space, ham)


class USDB_Hamiltonian(Hamiltonian):

    def __init__(self, N_protons, N_neutrons, total_J):
        """
        Creates a sd shell Hamiltonian using the USDB interaction
        Parameters
        ----------
            N_protons : int
                Number of protons
            N_neutrons : int
                Number of neutrons
            tota_J : int
                Total J_z of the system
        """
        sd_space = Space([0, 1, 0], [2, 0, 2], [2.5, 0.5, 1.5])

        base_path = os.path.dirname(os.path.abspath(__file__))
        int_path = os.path.join(base_path, 'data', 'usdb.int')

        ham = Operator.from_coupled_file(sd_space, int_path)

        super().__init__(N_protons, N_neutrons, total_J, sd_space, ham)


class KB3G_Hamiltonian(Hamiltonian):

    def __init__(self, N_protons, N_neutrons, total_J):
        """
        Creates a sd shell Hamiltonian using the USDB interaction
        Parameters
        ----------
            N_protons : int
                Number of protons
            N_neutrons : int
                Number of neutrons
            tota_J : int
                Total J_z of the system
        """

        pf_space = Space([0,1,0,1], [3,1,3,1], [3.5,1.5,2.5,0.5])

        base_path = os.path.dirname(os.path.abspath(__file__))
        int_path = os.path.join(base_path, 'data', 'kb3g.int')

        ham = Operator.from_coupled_file(pf_space, int_path)
        
        super().__init__(N_protons, N_neutrons, total_J, pf_space, ham)

class JUN45_Hamiltonian(Hamiltonian):

    def __init__(self, N_protons, N_neutrons, total_J):
        """
        Creates a PFG shell Hamiltonian using the JUN45 interaction
        Parameters
        ----------
            N_protons : int
                Number of protons
            N_neutrons : int
                Number of neutrons
            tota_J : int
                Total J_z of the system
        """

        pf_space = Space([1,0,1,0], [1,3,1,4], [1.5,2.5,0.5,4.5])

        base_path = os.path.dirname(os.path.abspath(__file__))
        int_path = os.path.join(base_path, 'data', 'jun45.int')

        ham = Operator.from_coupled_file(pf_space, int_path)
        
        super().__init__(N_protons, N_neutrons, total_J, pf_space, ham)
