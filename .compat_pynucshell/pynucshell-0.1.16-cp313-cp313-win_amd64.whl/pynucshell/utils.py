"""Implementation of utilities for nuclear shell model calculations such as angular momenta and isospin operators."""

from pynucshell import Operator, Basis, Space, Simulator
#from .linalg.core import SimulatorExcOp
from numpy import copy, sin, cos, vdot, sqrt

class ExcitationOp:
    r"""
    Fermionic double excitation operator for quantum many-body simulations.

    This class represents a skew-Hermitian double excitation operator, often 
    used in Unitary Coupled Cluster (UCC) theories, defined as:

    .. math::

        \hat{T}_{i,j,k,l} = (a^\dagger_i a^\dagger_j a_k a_l) - (a^\dagger_l a^\dagger_k a_j a_i)

    Attributes
    ----------
    basis : Basis
        The basis set object defining the orbital space.
    indices : tuple of int
        The orbital indices $(i, j, k, l)$ involved in the excitation.
    Methods
    -------
    exc_op : Operator
        The underlying pynucshell Operator object.
    csr : scipy.sparse.csr_matrix
        The compressed sparse row representation of the operator.
    op : scipy.sparse.linalg.LinearOperator
        The linear operator representation for matrix-vector products.
    """
    def __init__(self, basis : Basis,  indices : tuple ):
        """
        Initialize the ExcitationOp with a basis and specific indices.

        Parameters
        ----------
        basis : Basis
            Basis object representing the physical space.
        indices : tuple of int
            A tuple of four indices $(i, j, k, l)$ representing the 
            creation and annihilation operations.
        """
        i, j, k, l = indices  # noqa: E741
        exc_opa = Operator.from_uncoupled((i, j, k, l) , 1.0)
        exc_opb = Operator.from_uncoupled((k, l, i, j) , -1.0)
        exc_op = exc_opa + exc_opb
        #op = SimulatorExcOp(exc_op, basis)#.linear_op()
        op = Simulator(exc_op, basis).linear_op()
        self.exc_op = exc_op
        self.basis = basis
        self.simulator = op
        self.op = op.linear_op()
    
    def to_csr(self):
        """
        Get the sparse CSR matrix representation. Returns None if
        the ExcitationOp does not connect elements.

        Returns
        -------
        scipy.sparse.csr_matrix
            The operator represented as a sparse matrix.
        """
        self.csr = self.simulator.to_csr()
        return self.csr

    def linear_op(self):
        """
        Get the LinearOperator representation.

        Returns
        -------
        scipy.sparse.linalg.LinearOperator
            The operator in a form suitable for iterative solvers.
        """
        return self.op

    def exponential_op(self,theta, state): ## We should add the possibility to take the Transpose
        r"""
        Compute the action of the exponential operator on a state.

        This method applies $\exp(\theta \hat{T})$ to a given state vector. 
        Because $\hat{T}^3 = -\hat{T}$ for single/double excitations in 
        restricted subspaces, the expansion is simplified via:

        .. math::

            e^{\theta \hat{T}} | \phi \rangle = | \phi \rangle + \sin(\theta) \hat{T} | \phi \rangle + (1 - \cos(\theta)) \hat{T}^2 | \phi \rangle

        Parameters
        ----------
        theta : float
            The rotation angle or excitation amplitude.
        state : ndarray
            The input state vector (wavefunction coefficients).

        Returns
        -------
        ndarray
            The transformed state vector after the exponential action.
        """
        out = copy(state)
        out += sin(theta)*self.op@state
        out += (1-cos(theta))*self.op@self.op@state
        return out
    

class J2:
    """
    Computes the $J^2$ on a state.

    Attributes
    ----------
    space : Space
        The basis set object defining the orbital space.
    basis : Basis
        The basis set object defining the orbital space.
    Methods
    -------
    on_state : float
        Return the value applied to the state.
    """
    def __init__(self, space_S : Space, basis : Basis ):
        """
        Initialize the J2 operator with a space and basis.

        Parameters
        ----------
        space : Space
            The basis set object defining the orbital space.
        basis : Basis
            The basis set object defining the orbital space.
        """
        space = space_S .J_ar
        J_or2 = [val*(val+1) for val in space]
        orbital_pairs = []
        int_ind = []
        int_vals = []
        for i in range(len(space)):
            for j in range(i,len(space)):
                orbital_pairs.append((i,j))
        for pair in orbital_pairs:
            i,j = pair[0], pair[1]
            #print("ORBITAL ", pair)
            #print('min j', abs(space[i]-space[j]))
            #print('max j', space[i]+space[j])
            min_j = int(abs(space[i]-space[j]))
            max_j = int(abs(space[i]+space[j]))
            if i==j:
                for J in range(min_j, max_j +1):
                    for T in [0,1]:
                        if (J+T) % 2 == 0:
                            pass
                        else:
                            int_ind.extend([i +1,j +1 , i+1 , j+1, J,T])
                            int_vals.append(-J_or2[i]-J_or2[j]+J*(J+1))
                            #print(i +1,j +1 , i+1 , j+1, J,T, -J_or2[i]-J_or2[j]+J*(J+1))

                #print('pauli')
            else:
                for J in range(min_j, max_j +1):
                    for T in [0,1]:
                        int_ind.extend([i +1,j +1 , i+1 , j+1, J,T])
                        int_vals.append(-J_or2[i]-J_or2[j]+J*(J+1))
                        #print(i +1,j +1 , i+1 , j+1, J,T, -J_or2[i]-J_or2[j]+J*(J+1))
                #print('all')
                
        #sp = [len(int_vals)] + J_or2 + [1,1,0.0]
        J2_sp = Operator.from_sp(space_S, J_or2)
        J2_op_tb = Operator.from_coupled(space_S , int_ind, int_vals)
        J2_op = J2_sp + J2_op_tb
        J2_sim = Simulator(space_S,basis)#.to_csr().todense()
        self.lin_op = J2_sim.to_lin_op(J2_op)
        self.sim = J2_sim
        self.op = J2_op

    def on_state(self, state):
        """
        Initialize the J2 operator with a space and basis.

        Parameters
        ----------
        state : ndarray
            The state as a numpy array.

        Returns
        -------
        exp_value : float
            The J2 of the state
        """
        jstsq = vdot(state, self.lin_op@state)  
        return 0.5 * ( sqrt(4.0 * jstsq + 1) - 1 )
    

class T2:
    """
    Computes the $T^2$ on a state.

    Attributes
    ----------
    space : Space
        The basis set object defining the orbital space.
    basis : Basis
        The basis set object defining the orbital space.
    Methods
    -------
    on_state : float
        Return the value applied to the state.
    """
    def __init__(self, space_S : Space, basis : Basis ):
        """
        Initialize the T2 operator with a space and basis.

        Parameters
        ----------
        space : Space
            The basis set object defining the orbital space.
        basis : Basis
            The basis set object defining the orbital space.
        """
        space = space_S .J_ar
        T_or2 = [0.75 for _ in space]
        orbital_pairs = []
        int_ind = []
        int_vals = []
        for i in range(len(space)):
            for j in range(i,len(space)):
                orbital_pairs.append((i,j))
        for pair in orbital_pairs:
            i,j = pair[0], pair[1]
            #print("ORBITAL ", pair)
            #print('min j', abs(space[i]-space[j]))
            #print('max j', space[i]+space[j])
            min_j = int(abs(space[i]-space[j]))
            max_j = int(abs(space[i]+space[j]))
            if i==j:
                for J in range(min_j, max_j +1):
                    for T in [0,1]:
                        if (J+T) % 2 == 0:
                            pass
                        else:
                            int_ind.extend([i +1,j +1 , i+1 , j+1, J,T])
                            int_vals.append(-1.5+2*T)
                            #print(i +1,j +1 , i+1 , j+1, J,T, -J_or2[i]-J_or2[j]+J*(J+1))

                #print('pauli')
            else:
                for J in range(min_j, max_j +1):
                    for T in [0,1]:
                        int_ind.extend([i +1,j +1 , i+1 , j+1, J,T])
                        int_vals.append(-1.5+2*T)
                        #print(i +1,j +1 , i+1 , j+1, J,T, -J_or2[i]-J_or2[j]+J*(J+1))
                #print('all')
                
        #sp = [len(int_vals)] + T_or2 + [1,1,0.0]
        T2_sp = Operator.from_sp(space_S, T_or2)
        T2_op_tb = Operator.from_coupled(space_S , int_ind, int_vals)
        T2_op = T2_sp + T2_op_tb
        #T2_op = Operator.from_coupled(space_S , int_ind, int_vals, sp )
        T2_sim = Simulator(space_S,basis)#.to_csr().todense()
        self.lin_op = T2_sim.to_lin_op(T2_op)
        self.sim = T2_sim
        self.op = T2_op

    def on_state(self, state):
        """
        Initialize the T2 operator with a space and basis.

        Parameters
        ----------
        state : ndarray
            The state as a numpy array.

        Returns
        -------
        exp_value : float
            The T2 of the state
        """
        jstsq = vdot(state, self.lin_op@state)
        # Check the /2 factor in the isospin part  
        return 0.5 * ( sqrt(4.0 * jstsq + 1) - 1 )