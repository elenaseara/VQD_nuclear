"""This is the top level module from which common methods and classes can be called.
For a more in depth explanation of the package, see the documentation"""

# provide __version__ automatically
from importlib.metadata import PackageNotFoundError as _importlib_PackageNotFoundError, version as _importlib_version

try:
    __version__ = _importlib_version("pynucshell")
except _importlib_PackageNotFoundError:
    __version__ = "0.1.16"

from .linalg.core import Space, Basis, Simulator, decouple, compute_phase, decouple_from_list, decouple_np
from .pynucshell import Operator

from .models import sd_Hamiltonian, p_Hamiltonian, USDB_Hamiltonian, KB3G_Hamiltonian, JUN45_Hamiltonian, Hamiltonian

from . import utils, circuit
# When import pynucshell is called
# this is imported. Makes Pair, and PairArray visible

# __all__ indicates what to import with from . import *, and also
# what will be automatically documented at top level
# This defines our Public API
__all__ = ["Space", "Basis", "Simulator", "Operator"]

#### DEFINE MODULES
# # Reassign __module__ to point here instead of original submodule
# for name in __all__:
#     obj = locals()[name]
#     if hasattr(obj, "__module__"):
#         obj.__module__ = __name__