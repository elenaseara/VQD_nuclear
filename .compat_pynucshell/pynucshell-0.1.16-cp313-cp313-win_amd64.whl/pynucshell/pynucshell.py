"""Implementation of second quantization operators via Operator class."""

import copy
from os.path import splitext  # To read file names and get extension
from typing import Union

import numpy as np

from . import Space, compute_phase, decouple, decouple_from_list, decouple_np

# NOTE: -coefficients[i]/4 is responsible for the negative sign convention:
#       so that Vabcd corresponds to a^ b^ c d term instead of usual a^ b^ d c
from pynucshell.operators import FermionicOperator 

class Operator:
    """
    Class for obtaining and treating second quantization operators.
    
    Operators can be added together or multiplied by scalars. They can be also obtained
    from interaction files using :py:func:`from_file` or :py:func:`from_coupled_file`.
    
    .. warning::
        Only up to two body terms are supported. And a sign convention is used so that
        the two body coefficient Vabcd corresponds to ``a^ b^ c d`` term instead of the usual ``a^ b^ d c``.

    Example
    -------
    operator (:math:`1d_{\\frac{5}{2}}, 2s_{\\frac{1}{2}}, 1d_{\\frac{3}{2}}`)::

        sd = Space([0  , 1  , 0  ],
                   [2  , 0  , 2  ],
                   [2.5, 0.5, 1.5])

    Attributes
    ----------
    ops : dict[tuple[int], tuple[float, bool]]
        Dictionary holding operator term and tuple indicating
        coefficient and whether it needs scaling, as::

            {term1: (coef1, scale1), term2: (coef2, scale2), ...}

    func : list[float] or None
        Scaling of the coefficients (with valence nucleon number A_v). Currently consists in
        the following expression 
        
        .. math::

            f(A_v) = \\left( \\frac{A_r}{A_0+A_v} \\right)^e

        where func indicates the parameters ``func = [A_0, A_r, e]``.
        Or to indicate no scaling, it must be explicitly passed as None.
    space : Space
        Space of the interaction
    is_fermionic : bool
        Whether the operator obeys fermionic commutation
        relations, by default True.
        
        Useful for classically simulating Givens rotations.
    
                    
    """

    def __init__(self, coeff_list: list[float], op_list : list[tuple[int]], func: Union[list[float], None] , func_ind: list[bool], space : Space = None, is_fermionic : bool = True):
        """Default constructor for initializing an operator.

        To actually construct a class, it is easier to use specific
        methods such as :py:func:`from_coupled_file`, :py:func:`from_sp`, etc.


        Parameters
        ----------
        coeff_list : list[float]
            List with the coefficients of each term
        op_list : list[tuple[int]]
            List with each term of the operator (indices)
        func : list[float] or None
            Scaling of the coefficients with nucleon number
        func_ind : list[bool]
            List indicating which terms have scaling
        space : Space, optional
            Space of the interaction
        is_fermionic : bool, optional
            Whether the operator is fermionic, by default True

        Raises
        ------
        ValueError
            If coefficients are not real, corresponding to non hermitean terms. 
            If you really need complex coefficients, convert an operator 
            to a scipy object via a :py:class:`pynucshell.Simulator` and then
            multiply it with complex factors.
        RuntimeError
            If one same operator has a term which scales and a term which doesn't.
            This is currently not supported.
        """
        self.ops = {}
        self.func = func
        self.space = space
        self.is_fermionic = is_fermionic
        for i in range(len(coeff_list)):
            coeff = coeff_list[i]
            if coeff.imag:
                raise ValueError(  f"Operators need to have real coefficients but one term was {coeff}\n" \
                                    "If you really need to use complex coefficients, you can convert them\n" \
                                    "first to a Simulator and linear_op / csr, and then multiply them by the coefficients,\n" \
                                    "or splitting first the real/complex parts into two operators and adding them at the end")
            phase, operators = compute_phase(op_list[i])
            if not self.is_fermionic:
                phase = 1
            if operators not in self.ops:
                self.ops[operators] = (phase*coeff, func_ind[i])
            else:
                if self.ops[operators][1] != func_ind[i]:
                    raise RuntimeError(f'The scalings of the operator {operators} are assigned with different scalings')

                temp = self.ops[operators][0]
                self.ops[operators] = (phase*coeff+temp, func_ind[i])

    @classmethod
    def from_file(cls, filename:str, func = None, scaling: bool = False):
        """Create Operator from unocupled interaction file.

        The format should be as::

            V1 a1 b1 c1 d1
            V2 a2 b2 c2 d2
            E3 a3 b3
            ...

        Where each line indicates the value of :math:`V_{abcd}` or :math:`e_{ab}`.
        Note :math:`V_{abcd}` is associated with the fermionic term :math:`\\hat{a}_a^\\dagger \\hat{a}_b^\\dagger \\hat{a}_d \\hat{a}_c`.

        Parameters
        ----------
        filename : str
            File holding the interaction, examples are provided
            in ``pynucshell/data/`` with extension ``.txt``
        func : list[float], optional
            Terms describing functional scaling factor of coefficients (with nucleon number)
            
            :math:`fun(A) = \\frac{func[1]}{func[0]+Av}^func[2]`,
            
            by default None (no scaling).
        scaling : bool, optional
            Whether to apply scaling, by default False

        Returns
        -------
        Operator
            
        """
        ind_list = []
        scalings = []
        coeffs = []
        with open(filename, 'r') as file:
            lines = file.readlines()
            for line in lines:
                line = line.split(' ')
                coeffs.append(float(line[0]))
                temp = []
                for i in range(len(line[1:])):
                    if line[i+1] != '\n':
                        temp.append(int(line[i+1]))
                #print(temp)
                ind_list.append(tuple(temp))
                scalings.append(scaling)
        return cls(coeffs, ind_list, func, scalings)

    @classmethod
    def from_coupled_file(cls, space : Space, filename: str, type="") -> 'Operator':
        """Generate operator from coupled basis interaction file.
        Accepted formats are BIGSTICK (NUSHELLX), with extension ``.int``,
        and ANTOINE, with no extension. Example files are provided
        in ``pynucshell/data/``

        Parameters
        ----------
        space : Space
            Space of 
        filename : str
            Name of the interaction file
        type : str, optional
            Enforce one particular format, by default ""

        Returns
        -------
        Operator
            Creates Operator

        Raises
        ------
        ValueError
            If the file type is not supported
        """
        filepath, extension = splitext(filename)

        if type == "BIGSTICK" or extension == ".int":
            if extension != ".int":
                print("WARNING: File type does not match expected format for BIGSTICK (.int extension)")
            return cls._from_coupled_file_bigstick(space, filename)
        
        if type == "ANTOINE" or extension == "":
            if extension != "":
                print("WARNING: File type does not match expected format for ANTOINE (no extension)")
            return cls._from_coupled_file_antoine(space, filename)
    
        else:
            raise ValueError("Unsupported file format")
    
    @classmethod
    def _from_coupled_file_bigstick(cls, space : Space, filename):
        total_orb = len(space.J_ar)
        sp_energies = []
        scalings = []
        #print(space.J_ar)
        with open(filename, 'r') as file:
            lines = file.readlines()
            for line in lines:
                line = line.split()
                #print(line)
                if line[0][0] == '!':
                    #print('SKIP')
                    continue
                if line[0][0] == '-':
                    scaling = True
                else:
                    scaling = False
                for i in range(1, total_orb + 1):
                    sp_energies.append(float(line[i]))
                for i in range(1+ total_orb, 1+ total_orb +2):
                    scalings.append(float(line[i]))
                scalings.append(float(line[total_orb+ 3]))
                break
        
        array_M = [int(2*i+1) for i in space.J_ar]
        coefficients, indices = decouple(array_M, len(space.array_M)//2, filename, space.mapping)
        ind = []
        coef = []
        scalings_ind = []
        for i in range(coefficients.shape[0]):
            ind.append(tuple((int(indices[4*i + 0]), int(indices[4*i + 1]), int(indices[4*i + 2]), int(indices[4*i + 3]))))
            coef.append(-coefficients[i]/4)
            if scaling:
                scalings_ind.append(True)
            else:
                scalings_ind.append(False)
        counter = 0
        
        temp_coeff = []
        for i, j in enumerate(space.J_ar):
            for _ in range(int(2*j+1)):
                temp_coeff.append(sp_energies[i])
                #coef.append(sp_energies[i])
                ind.append((counter,counter))
                scalings_ind.append(False)
                counter +=1

        for i,j  in enumerate(space.J_ar):
            for _ in range(int(2*j+1)):
                temp_coeff.append(sp_energies[i])
                #coef.append(sp_energies[i])
                ind.append((counter,counter))
                scalings_ind.append(False)
                counter +=1
        for i in range(space.half_space*2):
            coef.append(temp_coeff[space.mapping[i]])
        if scaling:
            funcs = [scalings[0], scalings[1], scalings[2]]
        else:
            funcs = None
        return cls(coef, ind, funcs, scalings_ind, space)
    
    @classmethod
    def _from_coupled_file_antoine(cls, space : Space, filename):
        total_orb = len(space.J_ar)
        sp_energies = []
        scalings = []
        with open(filename, 'r') as file:

            line = file.readline() # Skip first line, comment, read up to 6 lines

            line = file.readline().split()
            # Read space definition
            qmax = int(line[0]) 
            if qmax != 1:
                raise ValueError("Unsupported Antoine format QMAX value: spe energies must be the same for p and n")
            
            nshell = int(line[1])
            if total_orb != nshell:
                raise ValueError(f"Number of shells mismatch: passed space with {total_orb}, read {nshell} in file")
            
            for s in range(nshell):
                sh = int(line[2+s])
                antoine_shell = [sh//1000, (sh//100)%10, sh%100/2.]
                space_shell = [space.n_ar[s], space.L_ar[s], space.J_ar[s]]
                if antoine_shell != space_shell:
                    raise ValueError(f"Shell mismatch between input file and space definitions for shell {s}: input_shell={antoine_shell}, space_shell={space_shell}")

            
            line = file.readline().split()
            for s in range(nshell):
                sp_energies.append(float(line[s]))
            
            line = file.readline().split()
            core1 = float(line[1])
            core2 = float(line[2])
            zmass = float(line[3]) # exponent for scaling
            if line[0] == '1':
                scaling = True
                scalings = [core1*2, core2*2+2, zmass]
            elif line[0] == '2':
                raise ValueError("Unsupported Antoine-format scaling=2 (scaling of both TBMEs and SPEs)")
            else:
                scaling = False
                scalings = None

            
            if core1 != core2:
                raise ValueError("Unsupported Antoine-format core1 != core2: protons and neutrons must be in the same shell")
            
            #scalings = [core1*2, core2*2+2, zmass]
        
        array_M = [int(2*i+1) for i in space.J_ar]
        coefficients, indices = decouple(array_M, len(space.array_M)//2, filename, space.mapping)
        ind = []
        coef = []
        scalings_ind = []
        for i in range(coefficients.shape[0]):
            ind.append(tuple((int(indices[4*i + 0]), int(indices[4*i + 1]), int(indices[4*i + 2]), int(indices[4*i + 3]))))
            coef.append(-coefficients[i]/4)
            scalings_ind.append(scaling)
            
        counter = 0

        temp_coeff = []
        for i, j in enumerate(space.J_ar):
            for _ in range(int(2*j+1)):
                temp_coeff.append(sp_energies[i])
                #coef.append(sp_energies[i])
                ind.append((counter,counter))
                scalings_ind.append(False)
                counter +=1

        for i,j  in enumerate(space.J_ar):
            for _ in range(int(2*j+1)):
                temp_coeff.append(sp_energies[i])
                #coef.append(sp_energies[i])
                ind.append((counter,counter))
                scalings_ind.append(False)
                counter +=1
        for i in range(space.half_space*2):
            coef.append(temp_coeff[space.mapping[i]])
        if scaling:
            funcs = [scalings[0], scalings[1], scalings[2]]
        else:
            funcs = None
        return cls(coef, ind, funcs, scalings_ind, space)

    # FIXME: This is deprecated? Uses old scaling convention
    @classmethod
    def _from_coupled_file_bigstick_np(cls, space : Space, filename):
        total_orb = len(space.J_ar)
        sp_energies = []
        scalings = []
        #print(space.J_ar)
        with open(filename, 'r') as file:
            lines = file.readlines()
            for line in lines:
                line = line.split()
                #print(line)
                if line[0][0] == '!':
                    #print('SKIP')
                    continue
                # if line[0][0] == '-':
                #     scaling = True
                # else:
                #     scaling = False
                for i in range(1, total_orb + 1):
                    sp_energies.append(float(line[i]))
                for i in range(1+ (total_orb * 2), 1+ (total_orb * 2) +2):
                    scalings.append(float(line[i]))
                scalings.append(float(line[total_orb*2+ 3]))
                break
        
        array_M = [int(2*i+1) for i in space.J_ar] + [int(2*i+1) for i in space.J_ar]
        coefficients, indices = decouple_np(array_M, len(space.array_M)//2, filename, space.mapping)
        ind = []
        coef = []
        scalings_ind = []
        for i in range(coefficients.shape[0]):
            ind.append(tuple((int(indices[4*i + 0]), int(indices[4*i + 1]), int(indices[4*i + 2]), int(indices[4*i + 3]))))
            coef.append(-coefficients[i]/4)
            scalings_ind.append(True)
        counter = 0
        
        temp_coeff = []
        for i, j in enumerate(space.J_ar):
            for _ in range(int(2*j+1)):
                temp_coeff.append(sp_energies[i])
                #coef.append(sp_energies[i])
                ind.append((counter,counter))
                scalings_ind.append(False)
                counter +=1

        for i,j  in enumerate(space.J_ar):
            for _ in range(int(2*j+1)):
                temp_coeff.append(sp_energies[i])
                #coef.append(sp_energies[i])
                ind.append((counter,counter))
                scalings_ind.append(False)
                counter +=1
        for i in range(space.half_space*2):
            coef.append(temp_coeff[space.mapping[i]])
        print("SP energies", sp_energies)
        print("SCaling " , scalings)
        funcs = [scalings[0], scalings[1], scalings[2]]
        return cls(coef, ind, funcs, scalings_ind, space)

    @classmethod
    def from_coupled(cls, space : Space, ind_list, val_list, scaling = None):
        """Generate operator from a manual list of coupled intereaction terms,
        in BIGSTICK format

        Parameters
        ----------
        space : Space
            Space for the operator
        ind_list : list[list[int]]
            List with the indices. Shape should be::

                [[a b c d J T, ...]]

        val_list : list[float]
            List with the values for each matrix element.
        scaling : bool
            Indicate if the term has scaling, by default False.
        """
        # total_orb = len(space.J_ar)

        ind_coupled = np.array(ind_list).ravel()
        val_coupled = np.array(val_list)
        array_M = [int(2*i+1) for i in space.J_ar]
        coefficients, indices = decouple_from_list(array_M, len(space.array_M)//2, ind_coupled, val_coupled, len(val_list), space.mapping)
        #coefficients, indices = decouple(array_M, len(space.array_M)//2, filename)
        ind = []
        coef = []
        scalings_ind = []
        for i in range(coefficients.shape[0]):
            ind.append(tuple((int(indices[4*i + 0]), int(indices[4*i + 1]), int(indices[4*i + 2]), int(indices[4*i + 3]))))
            coef.append(-coefficients[i]/4)
            if scaling:
                scalings_ind.append(True)
            else:
                scalings_ind.append(False)
                
        return cls(coef, ind, scaling, scalings_ind, space)
        
    @classmethod
    def from_uncoupled(cls, indices: tuple[int]|list[tuple[int]],
                       coefficients: float|list[float], is_fermionic : bool = True):
        """Generate operator from manual list of uncoupled terms, or from a 
        single uncoupled term.

        Parameters
        ----------
        indices : tuple[int] or list[tuple[int]]
            Tuples of the indices of the term. 
        coefficients : float or list[float]
            Coefficients of each term
        is_fermionic : bool, optional
            Indicate if the operator respects fermionic
            commutation relations, by default True
        """
        if isinstance(indices,list) and isinstance(coefficients,list):
            ind_list = []
            for i in range(len(indices)):
                if len(indices[i]) !=4 and len(indices[i]) != 2:
                    raise TypeError(f'Not implemented operators with len {len(indices)}')
                ind_list.append(tuple(indices[i]))
            scalings = [False] * len(indices)
            return cls(coefficients, ind_list, None, scalings, is_fermionic = is_fermionic)
        else:
            if len(indices) != 4 and len(indices) != 2:
                raise TypeError(f'Not implemented operators with len {len(indices)}')
            ind_list = [tuple(indices)]
            scalings = [False]
            coeffs = [coefficients]
            return cls(coeffs, ind_list, None, scalings, is_fermionic=is_fermionic)
    
    @classmethod
    def from_sp(cls, space : Space, sp, scaling = None):
        """
        Generate operator from single particle energies.

        Parameters
        ----------
        space : Space
            Space for the operator
        sp : list[float]
            List with single particle energies of each shell.
        scaling : bool
            If the operator has scaling, by default false.

        Example
        -------
        The single particle energies of the p-shell are 
        0p1/2: 2.268, 0p3/2: 1.635, so to obtain the
        corresponding operator we would do::

            Operator.from_coupled(p_space, [2.268, 1.635])
         
        """
        total_orb = len(space.J_ar)
        sp_energies = []
        does_scale = True if scaling else False
        #scalings = []

        for i in range(total_orb ):
            sp_energies.append(float(sp[i]))

        ind = []
        coef = []
        scalings_ind = []
        temp_coeff = []
        counter = 0

        for i, j in enumerate(space.J_ar):
            for _ in range(int(2*j+1)):
                temp_coeff.append(sp_energies[i])
                #coef.append(sp_energies[i])
                ind.append((counter,counter))
                if does_scale:
                    scalings_ind.append(True)
                else:
                    scalings_ind.append(False)
                counter +=1

        for i,j  in enumerate(space.J_ar):
            for _ in range(int(2*j+1)):
                temp_coeff.append(sp_energies[i])
                #coef.append(sp_energies[i])
                ind.append((counter,counter))
                if does_scale:
                    scalings_ind.append(True)
                else:
                    scalings_ind.append(False)
                counter +=1

        for i in range(space.half_space*2):
            coef.append(temp_coeff[space.mapping[i]])

        #scalings = [1.0,1.0,1.0,0.0]

        return cls(coef, ind, scaling, scalings_ind, space)

    def apply_scaling(self):
        """Apply scaling and return scaled coefficients separaterly.
        
        .. warning::

            This method is missing documentation 

        Returns
        -------
        tuple[int, list, list]
            Returns number of coefficients, 
            the terms (tuples of indices), 
            and the scaled coefficients.
        """
        coeffs = []
        ops = []
        n_coeffs = 0
        for key in self.ops.keys():
            ops.append(key)
            if self.ops[key][1]:
                coeffs.append(self.func(self.ops[key][0]))
            else:
                coeffs.append(self.ops[key][0])
            n_coeffs +=1
        return n_coeffs, ops, coeffs

    def set_value(self,indices, value):
        """
        Sets the values of the uncoupled operators to a given value.

        indices : tuple
            tuple of indices representing the operator
        value : float
            value to assign to the operator
        """
        if isinstance(indices, list):
            indices = tuple(indices)
        if indices not in self.ops.keys():
            self.ops[indices] = value
            raise RuntimeWarning(f"Indices {indices} not in Hamiltonian, adding new operator")
        else:
            self.ops[indices] = value

    def get_scaled_terms(self, N_neutrons, N_protons):
        N = N_neutrons + N_protons
        scaling_ar = self.func
        terms = {indices: coeff[0]*(scaling_ar[1]/(scaling_ar[0]+N))**scaling_ar[2] if coeff[1] else coeff[0] for indices, coeff in self.ops.items()}
        return terms

    def get_fermionic(self, N_neutrons, N_protons, prune = True):
        # N = self.N_neutrons + self.N_protons
        # #terms = {indices: self._ham.func(coeff[0], N) if coeff[1] else coeff[0] for indices, coeff in self._ham.ops.items()}
        # scaling_ar = self._ham.func
        # terms = {indices: coeff[0]*(scaling_ar[1]/(scaling_ar[0]+N))**scaling_ar[2] if coeff[1] else coeff[0] for indices, coeff in self._ham.ops.items()}
        terms = self.get_scaled_terms(N_neutrons, N_protons)
        
        # reindex so only neutron states start with index 0, avoid wasting empty qubits
        if N_protons == 0:
            shift = self.space.half_space
        else:
            shift = 0

        if prune:
            # TODO: would be more optimal to check from Space properties, not Basis
            allowed_pairs = set()
            allowed_states = set()
            
            # if N_nucleons == 1:
            
            
            for states in self.get_basis().mb():
                for i in range(len(states)):
                    allowed_states.add(states[i]-shift)
                    for j in range(i+1, len(states)):
                        allowed_pairs.add((states[i]-shift, states[j]-shift))

            to_delete = []
            for indices in terms.keys():
                if not all(sp in allowed_states for sp in indices):
                    to_delete.append(indices)
                elif len(indices)==4 and (indices[:2] not in allowed_pairs or indices[2:] not in allowed_pairs):
                    to_delete.append(indices)

            for indices in to_delete:
                del terms[indices]
        
        return FermionicOperator.from_n_body_operator(terms) 

    def __add__(self, other):
        ## MAYBE IT IS MORE EFFICIENT TO REWRITE THE OPERATOR
        ## RESTRICT THE USE TO +=
        ## AND AVOID C = B + A

        # Initialize the new object

        scalings_A = self.func
        scalings_B = other.func

        new_scalings = None

        if scalings_A is None and scalings_B:
            new_scalings = scalings_B
        elif scalings_B is None and scalings_A:
            new_scalings = scalings_A
        elif scalings_A is None and scalings_B is None:
            new_scalings = None
        else:
            for i in range(3):
                if scalings_A[i] != scalings_B[i]:
                    raise RuntimeError(f"Trying to add two operators with different scalings," \
                    f"Operator A {scalings_A}, Operator B {scalings_B}")
                else:
                    new_scalings = scalings_A

        is_fermionic = True

        if self.is_fermionic == other.is_fermionic:
            is_fermionic = self.is_fermionic
        else:
            raise RuntimeError("Cannot sum fermionic and not fermionic ops")

        new = Operator([], [], new_scalings, [], is_fermionic=is_fermionic)
        
        # Create a hard copy of self.ops so 'new' is independent
        new.ops = copy.deepcopy(self.ops)

        # Iterate through other.ops using .items() for clarity
        for op_name, (coeff, scaling) in other.ops.items():
            if op_name not in new.ops:
                # If the operator isn't there, add it
                new.ops[op_name] = (coeff, scaling)
            else:
                # Check for scaling consistency
                new_coeff, new_scaling = new.ops[op_name]
                
                if new_scaling != scaling:
                    raise RuntimeError(
                        f'The scalings of the operator {op_name} are assigned '
                        f'differently: {new_scaling} vs {scaling}'
                    )

                # Update the coefficient (Addition)
                new.ops[op_name] = (new_coeff + coeff, scaling)
                
        return new
    
    def __mul__(self,other):
        if isinstance(other,(int,float)):

            new = Operator([], [], self.func, [], space=self.space, is_fermionic=self.is_fermionic)
            for op_name, (coeff, scaling) in self.ops.items():
                new.ops[op_name] = (other * coeff, scaling)
            return new
        return NotImplemented
    
    def __rmul__(self,other):
        return self.__mul__(other)